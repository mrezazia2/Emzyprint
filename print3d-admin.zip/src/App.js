﻿import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import useAuthStore from './store/authStore';
import { ChatProvider } from './context/ChatContext';
import Sidebar from './components/layout/Sidebar';
import api from './services/api';
import { subscribeWebPush } from './utils/webPush';
import './styles/global.css';

const Dashboard    = React.lazy(() => import('./pages/Dashboard/Dashboard'));
const Orders       = React.lazy(() => import('./pages/Orders/Orders'));
const NewOrder     = React.lazy(() => import('./pages/NewOrder/NewOrder'));
const Files        = React.lazy(() => import('./pages/Files/Files'));
const Employees    = React.lazy(() => import('./pages/Employees/Employees'));
const Settings     = React.lazy(() => import('./pages/Settings/Settings'));
const Modules      = React.lazy(() => import('./pages/Modules/Modules'));
const Logs         = React.lazy(() => import('./pages/Logs/Logs'));
const Customers    = React.lazy(() => import('./pages/Customers/Customers'));
const OrderStatuses= React.lazy(() => import('./pages/OrderStatuses/OrderStatuses'));
const CustomFields = React.lazy(() => import('./pages/CustomFields/CustomFields'));
const Wallet       = React.lazy(() => import('./pages/Wallet/Wallet'));
const Chats        = React.lazy(() => import('./pages/Chats/Chats'));
const Login        = React.lazy(() => import('./pages/Login/Login'));

const qc = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 30_000 } },
});

function AdminLayout({ children }) {
  return (
    <div className="admin-layout">
      <Sidebar />
      <main className="admin-main">
        <React.Suspense fallback={<div className="page-body text-muted">در حال بارگذاری...</div>}>
          {children}
        </React.Suspense>
      </main>
    </div>
  );
}

function ProtectedRoute({ children }) {
  const { token } = useAuthStore();
  if (!token) return <Navigate to="/login" replace />;
  return children;
}

export default function App() {
  const { init, token } = useAuthStore();
  useEffect(() => { init(); }, []);
  useEffect(() => {
    if (token) subscribeWebPush(api);
  }, [token]);

  return (
    <QueryClientProvider client={qc}>
      <BrowserRouter>
        <React.Suspense fallback={null}>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/*" element={
              <ProtectedRoute>
                <ChatProvider>
                  <AdminLayout>
                    <Routes>
                      <Route path="/"               element={<Dashboard />} />
                      <Route path="/orders"         element={<Orders />} />
                      <Route path="/orders/new"     element={<NewOrder />} />
                      <Route path="/employees"      element={<Employees />} />
                      <Route path="/customers"      element={<Customers />} />
                      <Route path="/order-statuses" element={<OrderStatuses />} />
                      <Route path="/custom-fields"  element={<CustomFields />} />
                      <Route path="/wallet"         element={<Wallet />} />
                      <Route path="/settings"       element={<Settings />} />
                      <Route path="/chats"          element={<Chats />} />
                      <Route path="/modules"        element={<Modules />} />
                      <Route path="/logs"           element={<Logs />} />
                      <Route path="/files"          element={<Files />} />
                      <Route path="/payments"       element={<div className="page-body"><div className="card" style={{padding:24,textAlign:'center'}}>💳 پرداخت‌ها — به زودی</div></div>} />
                      <Route path="/map"            element={<div className="page-body"><div className="card" style={{padding:24,textAlign:'center'}}>🗺️ نقشه — به زودی</div></div>} />
                      <Route path="/languages"      element={<div className="page-body"><div className="card" style={{padding:24,textAlign:'center'}}>🌐 زبان‌ها — به زودی</div></div>} />
                      <Route path="*"              element={<Navigate to="/" replace />} />
                    </Routes>
                  </AdminLayout>
                </ChatProvider>
              </ProtectedRoute>
            } />
          </Routes>
        </React.Suspense>
      </BrowserRouter>
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            background: 'var(--ink-3)',
            color: 'var(--text-1)',
            border: '1px solid var(--border-2)',
            fontFamily: 'Vazirmatn, sans-serif',
            fontSize: '0.875rem',
            direction: 'rtl',
          },
        }}
      />
    </QueryClientProvider>
  );
}
