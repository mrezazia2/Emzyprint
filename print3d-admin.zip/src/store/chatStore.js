import { create } from 'zustand';
import { io } from 'socket.io-client';
import api from '../services/api';

const SOCKET_URL = process.env.REACT_APP_API_URL?.replace('/api', '') || 'http://localhost:5000';

const useChatStore = create((set, get) => ({
  chats: [],
  totalUnread: 0,
  socket: null,

  initSocket: (token) => {
    if (get().socket) return;
    const socket = io(SOCKET_URL, {
      auth: { token },
      transports: ['websocket', 'polling'],
    });

    socket.on('message:new', ({ chatId, message }) => {
      const { chats } = get();
      const updatedChats = chats.map(c => {
        if (c._id === chatId) {
          const unread = (c.unreadCounts?.[message.sender?._id] !== undefined)
            ? c.unreadCounts
            : { ...(c.unreadCounts || {}), total: (c.unreadCounts?.total || 0) + 1 };
          return { ...c, lastMessage: message, _newMsg: true };
        }
        return c;
      });
      const total = updatedChats.reduce((sum, c) => sum + (c._newMsg ? 1 : 0), 0);
      set({ chats: updatedChats });
      get().loadUnreadCount();
    });

    set({ socket });
  },

  loadChats: async () => {
    try {
      const res = await api.get('/chat');
      set({ chats: res.data.chats || [] });
      get().loadUnreadCount();
    } catch {}
  },

  loadUnreadCount: async () => {
    try {
      const res = await api.get('/chat');
      const chats = res.data.chats || [];
      const token = localStorage.getItem('admin_token');
      // decode userId from token
      let userId = null;
      try {
        userId = JSON.parse(atob(token.split('.')[1]))?.userId;
      } catch {}
      const total = chats.reduce((sum, c) => {
        const count = userId ? (c.unreadCounts?.[userId] || 0) : 0;
        return sum + count;
      }, 0);
      set({ chats, totalUnread: total });
    } catch {}
  },

  disconnect: () => {
    get().socket?.disconnect();
    set({ socket: null });
  },
}));

export default useChatStore;
