import { create } from 'zustand';
import api from '../services/api';

const useAuthStore = create((set, get) => ({
  user: null,
  token: localStorage.getItem('admin_token'),
  isLoading: true,

  init: async () => {
    const token = localStorage.getItem('admin_token');
    if (!token) return set({ isLoading: false });
    try {
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      // Verify token is still valid
      const res = await api.get('/auth/me').catch(() => null);
      if (res?.data?.user) {
        set({ user: res.data.user, token });
      } else {
        localStorage.removeItem('admin_token');
        set({ user: null, token: null });
      }
    } catch {}
    set({ isLoading: false });
  },

  login: async (phone, otp) => {
    const res = await api.post('/auth/verify-otp', { phone, otp });
    const { accessToken, user } = res.data;
    if (!['admin', 'employee'].includes(user.role)) {
      throw new Error('دسترسی ادمین ندارید');
    }
    localStorage.setItem('admin_token', accessToken);
    api.defaults.headers.common['Authorization'] = `Bearer ${accessToken}`;
    set({ user, token: accessToken });
    return user;
  },

  logout: (navigate) => {
    localStorage.removeItem('admin_token');
    delete api.defaults.headers.common['Authorization'];
    set({ user: null, token: null });
    navigate?.('/login');
  },
}));

export default useAuthStore;
