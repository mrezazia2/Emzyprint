import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import useAuthStore from '../../store/authStore';
import './Topbar.css';

export default function Topbar({ title, subtitle, actions }) {
  const navigate = useNavigate();
  const { token } = useAuthStore();
  const [search, setSearch] = useState('');
  const [notifs, setNotifs] = useState([]);
  const [unread, setUnread] = useState(0);
  const [open, setOpen] = useState(false);
  const dropRef = useRef(null);

  const nowFa = new Intl.DateTimeFormat('fa-IR', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  }).format(new Date());

  const fetchNotifs = async () => {
    if (!token) return;
    try {
      const { data } = await api.get('/notifications');
      setNotifs(data.notifications || []);
      setUnread(data.unreadCount || 0);
    } catch {}
  };

  useEffect(() => {
    fetchNotifs();
    const interval = setInterval(fetchNotifs, 30000);
    return () => clearInterval(interval);
  }, [token]);

  useEffect(() => {
    const handleClick = (e) => {
      if (dropRef.current && !dropRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const markAllRead = async () => {
    try {
      await api.patch('/notifications/read-all');
      setUnread(0);
      setNotifs(prev => prev.map(n => ({ ...n, isRead: true })));
    } catch {}
  };

  const handleOpen = () => {
    setOpen(prev => !prev);
    if (!open && unread > 0) markAllRead();
  };

  const getIcon = (type) => {
    const icons = { new_order: '🖨️', status_changed: '📦', new_message: '💬', wallet_charged: '💰', payment_required: '💳' };
    return icons[type] || '🔔';
  };

  return (
    <header className="topbar">
      <div className="topbar-right">
        <div>
          <h2 className="topbar-title">{title}</h2>
          {subtitle && <p className="topbar-sub">{subtitle || nowFa}</p>}
        </div>
      </div>
      <div className="topbar-left">
        <div className="topbar-search">
          <span className="search-icon">⌕</span>
          <input
            className="search-input"
            placeholder="جستجو..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <kbd className="search-kbd">/</kbd>
        </div>
        {actions && <div className="topbar-actions">{actions}</div>}

        <div style={{ position: 'relative' }} ref={dropRef}>
          <button className="topbar-icon-btn" title="اعلان‌ها" onClick={handleOpen}>
            <span>◖</span>
            {unread > 0 && (
              <span className="topbar-notif-dot" style={{
                position: 'absolute', top: 4, right: 4,
                background: '#ef4444', color: '#fff',
                fontSize: '0.55rem', fontWeight: 700,
                borderRadius: '999px', minWidth: 16, height: 16,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                padding: '0 3px',
              }}>
                {unread > 99 ? '99+' : unread}
              </span>
            )}
          </button>

          {open && (
            <div style={{
              position: 'absolute', top: '110%', left: 0,
              width: 320, maxHeight: 420, overflowY: 'auto',
              background: 'var(--ink-3, #1e1e2e)',
              border: '1px solid var(--border-2, #2a2a3e)',
              borderRadius: 12, boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
              zIndex: 999,
            }}>
              <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-2, #2a2a3e)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontWeight: 700, fontSize: '.9rem' }}>اعلان‌ها</span>
                {unread > 0 && (
                  <button onClick={markAllRead} style={{ background: 'none', border: 'none', color: 'var(--brand, #534ab7)', fontSize: '.75rem', cursor: 'pointer' }}>
                    همه خوانده شد
                  </button>
                )}
              </div>
              {notifs.length === 0 ? (
                <div style={{ padding: 24, textAlign: 'center', color: 'var(--t3)', fontSize: '.85rem' }}>
                  اعلانی وجود ندارد
                </div>
              ) : (
                notifs.map(n => (
                  <div key={n._id} style={{
                    padding: '10px 16px', borderBottom: '1px solid var(--border-2, #2a2a3e)',
                    background: n.isRead ? 'transparent' : 'rgba(83,74,183,0.08)',
                    cursor: 'pointer', display: 'flex', gap: 10, alignItems: 'flex-start',
                  }}
                    onClick={() => {
                      if (n.data?.type === 'new_message') navigate('/chats');
                      else if (n.data?.orderNumber) navigate('/orders');
                      setOpen(false);
                    }}
                  >
                    <span style={{ fontSize: '1.2rem' }}>{getIcon(n.type)}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600, fontSize: '.82rem' }}>{n.title}</div>
                      <div style={{ fontSize: '.75rem', color: 'var(--t3)', marginTop: 2 }}>{n.body}</div>
                      <div style={{ fontSize: '.68rem', color: 'var(--t3)', marginTop: 4 }}>
                        {new Date(n.createdAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                    {!n.isRead && <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--brand, #534ab7)', flexShrink: 0, marginTop: 4 }} />}
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        <button className="topbar-icon-btn" onClick={() => window.location.reload()} title="رفرش">
          <span>↻</span>
        </button>
      </div>
    </header>
  );
}