﻿import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import useAuthStore from '../../store/authStore';
import { useChatContext } from '../../context/ChatContext';
import './Sidebar.css';

const NAV = [
  { section: 'اصلی' },
  { path: '/',           icon: '⬡',  label: 'داشبورد' },
  { path: '/orders',     icon: '◈',  label: 'سفارشات' },
  { path: '/payments',   icon: '◎',  label: 'پرداخت‌ها' },
  { path: '/files',      icon: '◰',  label: 'فایل‌ها' },
  { section: 'مدیریت' },
  { path: '/employees',  icon: '◑',  label: 'کارمندان' },
  { path: '/customers',  icon: '◐',  label: 'مشتریان' },
  { path: '/chats',      icon: '◬',  label: 'چت‌ها', badgeKey: 'chats' },
  { path: '/map',        icon: '◫',  label: 'نقشه' },
  { section: 'سیستم' },
  { path: '/settings',   icon: '◩',  label: 'سفارشی‌سازی' },
  { path: '/modules',    icon: '⬡',  label: 'ماژول‌ها' },
  { path: '/languages',  icon: '◈',  label: 'زبان‌ها' },
  { path: '/logs',       icon: '◎',  label: 'لاگ سیستم' },
];

export default function Sidebar() {
  const { user, logout } = useAuthStore();
  const { unreadCount, markAllRead } = useChatContext();
  const navigate = useNavigate();

  const initials = user?.name
    ? user.name.split(' ').map(w => w[0]).join('').slice(0, 2)
    : 'AD';

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div className="brand-logo"><span>🖨</span></div>
        <div>
          <div className="brand-name">پرینت ۳D</div>
          <div className="brand-sub">پنل مدیریت</div>
        </div>
      </div>
      <nav className="sidebar-nav">
        {NAV.map((item, i) => {
          if (item.section) {
            return <div key={i} className="nav-section">{item.section}</div>;
          }
          const badgeCount = item.badgeKey === 'chats' ? unreadCount : 0;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/'}
              className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`}
              onClick={item.badgeKey === 'chats' ? markAllRead : undefined}
            >
              <span className="nav-icon">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
              {badgeCount > 0 && (
                <span className="nav-badge">{badgeCount > 99 ? '99+' : badgeCount}</span>
              )}
            </NavLink>
          );
        })}
      </nav>
      <div className="sidebar-footer">
        <div className="user-row">
          <div className="user-avatar">{initials}</div>
          <div className="user-info">
            <div className="user-name">{user?.name || 'مدیر'}</div>
            <div className="user-role">
              {{ admin: 'ادمین', employee: 'کارمند' }[user?.role]}
            </div>
          </div>
          <button className="btn btn-icon btn-ghost" onClick={() => logout(navigate)} title="خروج">↩</button>
        </div>
      </div>
    </aside>
  );
}
