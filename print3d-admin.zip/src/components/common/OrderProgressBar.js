import React from 'react';

/**
 * OrderProgressBar
 * نوار پیشرفت سفارش — از قرمز (۰٪) به سبز (۱۰۰٪)
 * درصد از مدل OrderStatus.progressPercent می‌آید
 */
export default function OrderProgressBar({ percent = 0, statusLabel = '', statusColor = '#534AB7', animated = true }) {
  // محاسبه رنگ بر اساس درصد (قرمز → زرد → سبز)
  const getColor = (p) => {
    if (p <= 0)   return '#F0614E';  // قرمز
    if (p <= 25)  return '#EF7B3B';  // نارنجی
    if (p <= 50)  return '#F5A623';  // زرد
    if (p <= 75)  return '#8BC43F';  // زرد-سبز
    if (p < 100)  return '#3DD68C';  // سبز
    return '#22C55E';                // سبز تیره (تحویل)
  };

  const barColor = getColor(percent);
  const safePercent = Math.min(100, Math.max(0, percent));

  return (
    <div style={{ width: '100%', marginBottom: 10 }}>
      {/* برچسب بالای نوار */}
      <div style={{
        display: 'flex', justifyContent: 'space-between',
        alignItems: 'center', marginBottom: 5,
      }}>
        <span style={{ fontSize: '.72rem', color: 'var(--t2)' }}>پیشرفت سفارش</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{
            background: statusColor + '20', color: statusColor,
            fontSize: '.7rem', fontWeight: 600,
            borderRadius: 99, padding: '2px 8px',
          }}>
            {statusLabel}
          </span>
          <span style={{ fontSize: '.78rem', fontWeight: 700, color: barColor }}>
            {safePercent}٪
          </span>
        </div>
      </div>

      {/* نوار */}
      <div style={{
        width: '100%', height: 8,
        background: 'var(--surface)',
        borderRadius: 99, overflow: 'hidden',
      }}>
        <div style={{
          height: '100%',
          width: `${safePercent}%`,
          background: `linear-gradient(90deg, ${getColor(0)}, ${barColor})`,
          borderRadius: 99,
          transition: animated ? 'width .6s cubic-bezier(.4,0,.2,1), background .4s' : 'none',
          boxShadow: `0 0 8px ${barColor}60`,
        }} />
      </div>

      {/* نشانگرهای درصد */}
      <div style={{
        display: 'flex', justifyContent: 'space-between',
        marginTop: 3, paddingHorizontal: 2,
      }}>
        {[0, 25, 50, 75, 100].map(mark => (
          <span key={mark} style={{
            fontSize: '.58rem',
            color: safePercent >= mark ? barColor : 'var(--t3)',
            fontWeight: safePercent >= mark ? 600 : 400,
          }}>
            {mark}٪
          </span>
        ))}
      </div>
    </div>
  );
}
