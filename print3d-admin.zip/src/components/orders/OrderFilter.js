import React, { useState } from 'react';
import { fromJalali } from '../../utils/jalali';
import './OrderFilter.css';

export default function OrderFilter({ onFilter, statuses = [], employees = [] }) {
  const [open, setOpen] = useState(true);
  const [filters, setFilters] = useState({
    search:        '',
    status:        '',
    fileFormat:    '',
    fileStatus:    '',
    paymentStatus: '',
    employeeId:    '',
    dateFrom:      '',
    dateTo:        '',
    sortBy:        'createdAt',
    sortDir:       'desc',
  });

  const FILE_FORMATS = ['stl','obj','3mf','gcode','step','stp','zip'];

  const set = (key, val) => setFilters(f => ({ ...f, [key]: val }));

  const apply = () => {
    const params = {};
    Object.entries(filters).forEach(([k,v]) => { if (v) params[k] = v; });
    onFilter(params);
  };

  const reset = () => {
    const empty = Object.fromEntries(Object.keys(filters).map(k => [k,'']));
    empty.sortBy = 'createdAt'; empty.sortDir = 'desc';
    setFilters(empty);
    onFilter({});
  };

  return (
    <div className="order-filter card">
      <div className="filter-header" onClick={() => setOpen(o => !o)}>
        <div className="flex items-center gap-2">
          <span>🔍</span>
          <strong style={{fontSize:'.88rem'}}>فیلتر و جستجو</strong>
          {Object.values(filters).filter(v => v && v !== 'createdAt' && v !== 'desc').length > 0 && (
            <span className="badge b-brand" style={{fontSize:'.68rem'}}>
              {Object.values(filters).filter(v => v && v !== 'createdAt' && v !== 'desc').length} فیلتر فعال
            </span>
          )}
        </div>
        <span style={{color:'var(--t3)',fontSize:'.85rem',transition:'transform .15s',transform:open?'rotate(180deg)':''}}>▼</span>
      </div>

      {open && (
        <div className="filter-body animate-in">
          {/* Row 1 */}
          <div className="filter-row-grid">
            <div className="form-group">
              <label className="label">جستجو</label>
              <input
                className="input"
                placeholder="شماره سفارش، نام مشتری..."
                value={filters.search}
                onChange={e => set('search', e.target.value)}
              />
            </div>
            <div className="form-group">
              <label className="label">وضعیت</label>
              <select className="select" value={filters.status} onChange={e => set('status', e.target.value)}>
                <option value="">همه وضعیت‌ها</option>
                {statuses.map(s => (
                  <option key={s.key} value={s.key}>{s.label?.fa || s.key}</option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label className="label">فرمت فایل</label>
              <select className="select" value={filters.fileFormat} onChange={e => set('fileFormat', e.target.value)}>
                <option value="">همه فرمت‌ها</option>
                {FILE_FORMATS.map(f => <option key={f} value={f}>.{f.toUpperCase()}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="label">وضعیت فایل</label>
              <select className="select" value={filters.fileStatus} onChange={e => set('fileStatus', e.target.value)}>
                <option value="">همه</option>
                <option value="pending">در انتظار بررسی</option>
                <option value="approved">تایید شده</option>
                <option value="rejected">رد شده</option>
              </select>
            </div>
          </div>

          {/* Row 2 */}
          <div className="filter-row-grid">
            <div className="form-group">
              <label className="label">وضعیت پرداخت</label>
              <select className="select" value={filters.paymentStatus} onChange={e => set('paymentStatus', e.target.value)}>
                <option value="">همه</option>
                <option value="pending">در انتظار پرداخت</option>
                <option value="paid">پرداخت شده</option>
                <option value="refunded">برگشت داده شده</option>
                <option value="failed">ناموفق</option>
              </select>
            </div>
            <div className="form-group">
              <label className="label">کارمند مسئول</label>
              <select className="select" value={filters.employeeId} onChange={e => set('employeeId', e.target.value)}>
                <option value="">همه کارمندان</option>
                <option value="unassigned">تخصیص‌نشده</option>
                {employees.map(e => <option key={e._id} value={e._id}>{e.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="label">از تاریخ (شمسی)</label>
              <input
                className="input" placeholder="۱۴۰۳/۰۱/۰۱"
                value={filters.dateFrom}
                onChange={e => set('dateFrom', e.target.value)}
                dir="ltr"
              />
            </div>
            <div className="form-group">
              <label className="label">تا تاریخ (شمسی)</label>
              <input
                className="input" placeholder="۱۴۰۳/۱۲/۲۹"
                value={filters.dateTo}
                onChange={e => set('dateTo', e.target.value)}
                dir="ltr"
              />
            </div>
          </div>

          {/* Row 3 - Sort */}
          <div className="filter-row-grid" style={{gridTemplateColumns:'1fr 1fr auto auto'}}>
            <div className="form-group">
              <label className="label">مرتب‌سازی</label>
              <select className="select" value={filters.sortBy} onChange={e => set('sortBy', e.target.value)}>
                <option value="createdAt">تاریخ ثبت</option>
                <option value="updatedAt">آخرین تغییر</option>
                <option value="payment.amount">مبلغ</option>
                <option value="orderNumber">شماره سفارش</option>
              </select>
            </div>
            <div className="form-group">
              <label className="label">ترتیب</label>
              <select className="select" value={filters.sortDir} onChange={e => set('sortDir', e.target.value)}>
                <option value="desc">جدیدترین اول</option>
                <option value="asc">قدیمی‌ترین اول</option>
              </select>
            </div>
            <button className="btn btn-ghost" style={{alignSelf:'flex-end'}} onClick={reset}>
              پاک کردن
            </button>
            <button className="btn btn-primary" style={{alignSelf:'flex-end'}} onClick={apply}>
              اعمال فیلتر
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
