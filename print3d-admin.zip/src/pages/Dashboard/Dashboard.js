import React from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell,
} from 'recharts';
import { useNavigate } from 'react-router-dom';
import Topbar from '../../components/layout/Topbar';
import api from '../../services/api';
import './Dashboard.css';

const STATUS_CFG = {
  new:           { label: 'جدید',          cls: 'badge-brand' },
  reviewing:     { label: 'بررسی',         cls: 'badge-blue'  },
  printing:      { label: 'در حال چاپ',    cls: 'badge-amber' },
  quality_check: { label: 'کنترل کیفیت',  cls: 'badge-brand' },
  ready:         { label: 'آماده',         cls: 'badge-green' },
  delivered:     { label: 'تحویل',        cls: 'badge-gray'  },
  cancelled:     { label: 'لغو',          cls: 'badge-red'   },
};

const WEEK_DAYS = ['ش','۱ش','۲ش','۳ش','۴ش','۵ش','ج'];
const PIE_COLORS = ['#7C6AF5','#3DD68C','#F5A623','#F0614E','#4EA8F0'];

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="chart-tooltip">
      <p className="tooltip-label">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }} className="tooltip-val">
          {p.name}: {p.value?.toLocaleString('fa-IR')}
        </p>
      ))}
    </div>
  );
};

export default function DashboardPage() {
  const navigate = useNavigate();

  const { data: stats, isLoading } = useQuery({
    queryKey: ['admin-dashboard'],
    queryFn: () => api.get('/admin/dashboard').then(r => r.data),
    refetchInterval: 60_000,
  });

  const { data: ordersData } = useQuery({
    queryKey: ['recent-orders-dash'],
    queryFn: () => api.get('/orders?limit=8').then(r => r.data),
  });

  const { data: employees } = useQuery({
    queryKey: ['employees-dash'],
    queryFn: () => api.get('/employees').then(r => r.data.employees),
  });

  const weeklyData = WEEK_DAYS.map((day, i) => ({
    day,
    سفارشات: stats?.weeklyOrders?.find(w => w._id === i + 1)?.count || 0,
  }));

  const statusPie = [
    { name: 'چاپ', value: stats?.activeOrders || 0 },
    { name: 'بررسی', value: stats?.pendingFiles || 0 },
    { name: 'جدید', value: stats?.todayOrders || 0 },
  ];

  const now = new Intl.DateTimeFormat('fa-IR', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  }).format(new Date());

  return (
    <>
      <Topbar
        title="داشبورد"
        subtitle={now}
        actions={
          <button className="btn btn-primary btn-sm" onClick={() => navigate('/orders/new')}>
            + سفارش جدید
          </button>
        }
      />

      <div className="page-body animate-in">

        {/* ── KPI Cards ─────────────────────────────────────────────────────── */}
        <div className="kpi-grid">
          <KpiCard
            icon="◈" label="سفارشات امروز"
            value={stats?.todayOrders ?? '—'}
            delta="+18٪" deltaUp
            color="brand"
            loading={isLoading}
          />
          <KpiCard
            icon="◎" label="در حال چاپ"
            value={stats?.activeOrders ?? '—'}
            sub="روی ۳ دستگاه"
            color="green"
            loading={isLoading}
          />
          <KpiCard
            icon="◑" label="درآمد امروز"
            value={stats?.todayRevenue?.find(r => r._id === 'IRR')
              ? `${(stats.todayRevenue.find(r=>r._id==='IRR').total/1_000_000).toFixed(1)}M ت`
              : '—'}
            delta="+2.1M" deltaUp
            color="amber"
            loading={isLoading}
          />
          <KpiCard
            icon="⚠" label="نیاز بررسی"
            value={stats?.pendingFiles ?? '—'}
            sub="فایل در انتظار"
            color="red"
            loading={isLoading}
          />
        </div>

        {/* ── Charts Row ────────────────────────────────────────────────────── */}
        <div className="charts-row">
          <div className="card chart-card">
            <div className="flex justify-between items-center mb-4">
              <h4>سفارشات هفتگی</h4>
              <span className="badge badge-green text-xs">این هفته</span>
            </div>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={weeklyData} barSize={28}>
                <XAxis dataKey="day" tick={{ fill: 'var(--text-3)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
                <Bar dataKey="سفارشات" fill="var(--brand)" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="card chart-card chart-card-sm">
            <h4 className="mb-4">وضعیت کلی</h4>
            <ResponsiveContainer width="100%" height={130}>
              <PieChart>
                <Pie data={statusPie} cx="50%" cy="50%" innerRadius={38} outerRadius={58}
                  dataKey="value" stroke="none">
                  {statusPie.map((_, i) => <Cell key={i} fill={PIE_COLORS[i]} />)}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="pie-legend">
              {statusPie.map((item, i) => (
                <div key={i} className="pie-leg-item">
                  <span className="pie-dot" style={{ background: PIE_COLORS[i] }} />
                  <span className="text-xs text-muted">{item.name}</span>
                  <span className="text-xs" style={{ color: PIE_COLORS[i] }}>{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── Bottom Row ────────────────────────────────────────────────────── */}
        <div className="bottom-row">

          {/* Recent Orders */}
          <div className="card">
            <div className="flex justify-between items-center mb-4">
              <h4>آخرین سفارشات</h4>
              <button className="btn btn-ghost btn-sm" onClick={() => navigate('/orders')}>
                مشاهده همه →
              </button>
            </div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>شماره</th>
                    <th>مشتری</th>
                    <th>سرویس</th>
                    <th>کارمند</th>
                    <th>مبلغ</th>
                    <th>وضعیت</th>
                  </tr>
                </thead>
                <tbody>
                  {ordersData?.orders?.map(order => {
                    const s = STATUS_CFG[order.status] || STATUS_CFG.new;
                    return (
                      <tr key={order._id} className="row-clickable" onClick={() => navigate(`/orders/${order._id}`)}>
                        <td><span className="mono text-brand text-sm">{order.orderNumber}</span></td>
                        <td>
                          <div>{order.customer?.name || '—'}</div>
                          <div className="text-xs text-dim">{order.customer?.phone}</div>
                        </td>
                        <td className="text-sm text-muted">
                          {order.printSettings?.material} · ×{order.printSettings?.quantity}
                        </td>
                        <td>
                          {order.assignedEmployee
                            ? <div className="employee-chip">{order.assignedEmployee.name}</div>
                            : <span className="text-dim text-xs">تخصیص‌نشده</span>}
                        </td>
                        <td className="text-sm">
                          {order.payment?.amount
                            ? `${order.payment.amount.toLocaleString()} ${order.payment.currency === 'USD' ? '$' : 'ت'}`
                            : '—'}
                        </td>
                        <td><span className={`badge ${s.cls}`}>{s.label}</span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Employees */}
          <div className="card emp-card">
            <div className="flex justify-between items-center mb-4">
              <h4>کارمندان</h4>
              <button className="btn btn-ghost btn-sm" onClick={() => navigate('/employees')}>مدیریت →</button>
            </div>
            <div className="emp-list">
              {employees?.slice(0, 6).map(emp => (
                <div key={emp._id} className="emp-row">
                  <div className="emp-avatar">
                    {emp.name?.slice(0, 2) || 'U'}
                    <span className={`online-dot ${emp.employeeProfile?.isOnline ? 'online' : 'offline'}`} />
                  </div>
                  <div className="emp-info">
                    <div className="emp-name">{emp.name}</div>
                    <div className="emp-dept text-xs text-dim">{emp.employeeProfile?.department || 'عمومی'}</div>
                  </div>
                  <div className="emp-tasks text-xs text-dim">
                    {emp.employeeProfile?.assignedOrders?.length || 0} سفارش
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </>
  );
}

function KpiCard({ icon, label, value, delta, deltaUp, sub, color, loading }) {
  return (
    <div className={`card kpi-card kpi-${color}`}>
      <div className="flex justify-between items-center" style={{ marginBottom: 10 }}>
        <div className="kpi-icon">{icon}</div>
        {delta && (
          <span className={`badge text-xs ${deltaUp ? 'badge-green' : 'badge-red'}`}>
            {deltaUp ? '↑' : '↓'} {delta}
          </span>
        )}
      </div>
      {loading
        ? <div className="skeleton" style={{ height: 28, width: '60%', marginBottom: 4 }} />
        : <div className="kpi-value">{value}</div>}
      <div className="kpi-label">{sub || label}</div>
    </div>
  );
}
