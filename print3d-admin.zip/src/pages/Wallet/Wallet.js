import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import Topbar from '../../components/layout/Topbar';
import api from '../../services/api';
import './Wallet.css';

const CURRENCY_SOURCES = [
  { value: 'api_navasan',      label: 'navasan.io (بازار آزاد، خودکار)' },
  { value: 'api_exchangerate', label: 'exchangerate-api.com (خودکار)' },
  { value: 'api_bonbast',      label: 'bonbast.com (خودکار)' },
  { value: 'manual',           label: 'نرخ دستی' },
];

export default function WalletPage() {
  const qc = useQueryClient();
  const [settings, setSettings] = useState(null);
  const [liveRate, setLiveRate] = useState(null);

  const { data, isLoading } = useQuery({
    queryKey: ['wallet-settings'],
    queryFn: () => api.get('/wallet/settings').then(r => r.data.settings),
  });

  const { data: rateData, refetch: refetchRate } = useQuery({
    queryKey: ['live-rate'],
    queryFn: () => api.get('/wallet/rate').then(r => r.data),
    refetchInterval: 5 * 60 * 1000,
  });

  useEffect(() => {
    if (data) setSettings(JSON.parse(JSON.stringify(data)));
  }, [data]);

  useEffect(() => {
    if (rateData) setLiveRate(rateData.usdToIrr);
  }, [rateData]);

  const saveMut = useMutation({
    mutationFn: (d) => api.put('/wallet/settings', d),
    onSuccess: () => { qc.invalidateQueries(['wallet-settings']); toast.success('تنظیمات ذخیره شد'); },
    onError: err => toast.error(err.response?.data?.error || 'خطا'),
  });

  if (isLoading || !settings) return <div className="page-body text-muted">در حال بارگذاری...</div>;

  const updateResinRate = (key, field, val) => {
    setSettings(s => ({
      ...s,
      resinRates: s.resinRates.map(r => r.resinKey === key ? { ...r, [field]: val } : r),
    }));
  };

  return (
    <>
      <Topbar title="کیف پول و قیمت‌گذاری" subtitle="مدیریت نرخ رزین و تنظیمات پرداخت" />
      <div className="page-body animate-in">

        {/* Live Rate Banner */}
        <div className="rate-banner card mb-4">
          <div className="flex items-center gap-3 justify-between">
            <div className="flex items-center gap-3">
              <span style={{fontSize:'1.6rem'}}>💵</span>
              <div>
                <div style={{fontSize:'.85rem',fontWeight:600,color:'var(--t2)'}}>نرخ لحظه‌ای دلار</div>
                <div style={{fontSize:'1.4rem',fontWeight:700,color:'var(--amber)'}}>
                  {liveRate ? `${liveRate.toLocaleString()} ریال` : '—'}
                </div>
              </div>
            </div>
            <div style={{textAlign:'left'}}>
              <div className="text-xs text-dim">
                آخرین بروزرسانی: {rateData?.lastUpdate
                  ? new Date(rateData.lastUpdate).toLocaleTimeString('fa-IR')
                  : '—'}
              </div>
              <button className="btn btn-ghost btn-sm" style={{marginTop:4}} onClick={() => refetchRate()}>
                🔄 بروزرسانی
              </button>
            </div>
          </div>
        </div>

        <div className="grid-2 mb-4">

          {/* Resin Rates */}
          <div className="card">
            <div className="card-title">💎 نرخ هر گرم رزین (به دلار)</div>
            <div style={{display:'flex',flexDirection:'column',gap:10}}>
              {settings.resinRates?.map(resin => (
                <div key={resin.resinKey} className="resin-rate-row">
                  <div className="resin-color-label">
                    <div className="resin-dot" style={{background:
                      resin.resinKey==='wax'?'#3B82F6':
                      resin.resinKey==='dark'?'#1F2937':
                      resin.resinKey==='yellow'?'#EAB308':'#22C55E'
                    }}/>
                    <div>
                      <div style={{fontSize:'.85rem',fontWeight:600}}>{resin.resinName?.fa}</div>
                      <div className="text-xs text-dim">{resin.resinName?.en}</div>
                    </div>
                  </div>
                  <div className="resin-rate-input">
                    <div className="text-xs text-muted" style={{marginBottom:4}}>هر گرم (دلار)</div>
                    <div style={{display:'flex',alignItems:'center',gap:6}}>
                      <input
                        type="number" step="0.1" min="0.1"
                        className="input" style={{width:90}}
                        value={resin.rateUSD || ''}
                        onChange={e => updateResinRate(resin.resinKey, 'rateUSD', parseFloat(e.target.value))}
                      />
                      <span className="text-xs text-dim">$</span>
                    </div>
                    {liveRate && resin.rateUSD && (
                      <div className="text-xs text-muted" style={{marginTop:3}}>
                        ≈ {(resin.rateUSD * liveRate).toLocaleString()} ریال
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Currency + Payment Settings */}
          <div style={{display:'flex',flexDirection:'column',gap:12}}>
            <div className="card">
              <div className="card-title">🌐 منبع نرخ دلار</div>
              <select
                className="select"
                value={settings.currencyRateSource || 'api_navasan'}
                onChange={e => setSettings(s => ({ ...s, currencyRateSource: e.target.value }))}
              >
                {CURRENCY_SOURCES.map(s => (
                  <option key={s.value} value={s.value}>{s.label}</option>
                ))}
              </select>
              {settings.currencyRateSource === 'manual' && (
                <div className="form-group" style={{marginTop:10}}>
                  <label className="label">نرخ دستی (ریال)</label>
                  <input
                    type="number" className="input"
                    value={settings.manualUsdToIrr || ''}
                    onChange={e => setSettings(s => ({ ...s, manualUsdToIrr: parseInt(e.target.value) }))}
                    placeholder="600000"
                  />
                </div>
              )}
              {settings.currencyRateSource === 'api_navasan' && (
                <div className="form-group" style={{marginTop:10}}>
                  <label className="label">NAVASAN_API_KEY (در .env)</label>
                  <input className="input" value="*** از .env خوانده می‌شود ***" disabled style={{opacity:.5}} />
                </div>
              )}
            </div>

            <div className="card">
              <div className="card-title">💳 تنظیمات پرداخت</div>
              <div style={{display:'flex',flexDirection:'column',gap:10}}>
                <label className="toggle-wrap" style={{fontSize:'.85rem',cursor:'pointer'}}>
                  <div
                    className={`toggle-pill ${settings.requirePaymentBeforeDelivery ? '' : 'off'}`}
                    onClick={() => setSettings(s => ({ ...s, requirePaymentBeforeDelivery: !s.requirePaymentBeforeDelivery }))}
                  />
                  پرداخت اجباری قبل از تحویل
                </label>
                <div className="text-xs text-muted">
                  اگر فعال باشد، مشتری باید قبل از تحویل سفارش پرداخت کند.
                  می‌توان برای مشتریان خاص این قانون را تغییر داد.
                </div>
                <div className="grid-2" style={{gap:8,marginTop:4}}>
                  <div className="form-group">
                    <label className="label">حداقل شارژ (ریال)</label>
                    <input type="number" className="input" value={settings.minChargeIRR||''} onChange={e => setSettings(s => ({...s,minChargeIRR:+e.target.value}))} />
                  </div>
                  <div className="form-group">
                    <label className="label">حداقل شارژ (دلار)</label>
                    <input type="number" className="input" value={settings.minChargeUSD||''} onChange={e => setSettings(s => ({...s,minChargeUSD:+e.target.value}))} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Calc preview */}
        <div className="card mb-4">
          <div className="card-title">🧮 ماشین حساب (پیش‌نمایش)</div>
          <CalcPreview settings={settings} liveRate={liveRate} />
        </div>

        <div style={{display:'flex',justifyContent:'flex-end'}}>
          <button className="btn btn-primary" onClick={() => saveMut.mutate(settings)} disabled={saveMut.isPending}>
            {saveMut.isPending ? 'در حال ذخیره...' : 'ذخیره تمام تنظیمات'}
          </button>
        </div>
      </div>
    </>
  );
}

function CalcPreview({ settings, liveRate }) {
  const [amount, setAmount] = useState(20);
  const [currency, setCurrency] = useState('USD');
  const [resinKey, setResinKey] = useState('wax');

  const resin = settings?.resinRates?.find(r => r.resinKey === resinKey);
  const rate = resin?.rateUSD || 0;
  const usdAmount = currency === 'USD' ? amount : (liveRate ? amount / liveRate : 0);
  const grams = rate > 0 ? Math.floor((usdAmount / rate) * 100) / 100 : 0;

  return (
    <div style={{display:'flex',gap:14,alignItems:'flex-end',flexWrap:'wrap'}}>
      <div className="form-group" style={{marginBottom:0}}>
        <label className="label">مبلغ</label>
        <input type="number" className="input" style={{width:100}} value={amount} onChange={e => setAmount(+e.target.value)} />
      </div>
      <div className="form-group" style={{marginBottom:0}}>
        <label className="label">ارز</label>
        <select className="select" style={{width:100}} value={currency} onChange={e => setCurrency(e.target.value)}>
          <option value="USD">دلار</option>
          <option value="IRR">ریال</option>
        </select>
      </div>
      <div className="form-group" style={{marginBottom:0}}>
        <label className="label">نوع رزین</label>
        <select className="select" value={resinKey} onChange={e => setResinKey(e.target.value)}>
          {settings?.resinRates?.map(r => <option key={r.resinKey} value={r.resinKey}>{r.resinName?.fa}</option>)}
        </select>
      </div>
      <div className="calc-result">
        <div className="text-xs text-muted">نتیجه:</div>
        <div style={{fontSize:'1.3rem',fontWeight:700,color:'var(--green)'}}>
          {grams} <span style={{fontSize:'.85rem',color:'var(--t2)'}}>گرم رزین</span>
        </div>
        {liveRate && currency === 'USD' && (
          <div className="text-xs text-dim">
            معادل {(amount * liveRate).toLocaleString()} ریال
          </div>
        )}
      </div>
    </div>
  );
}
