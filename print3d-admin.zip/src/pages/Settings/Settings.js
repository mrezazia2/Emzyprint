import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import Topbar from '../../components/layout/Topbar';
import api from '../../services/api';
import './Settings.css';

const FONTS = ['Vazirmatn', 'IRANSans', 'Shabnam', 'Roboto', 'Poppins'];
const FORMATS_ALL = ['stl', 'obj', '3mf', 'gcode', 'step', 'stp', 'iges', 'igs', 'zip', 'pdf', 'jpg', 'png'];

export default function SettingsPage() {
  const { data: settings, isLoading } = useQuery({
    queryKey: ['app-settings'],
    queryFn: () => api.get('/admin/settings').then(r => r.data.settings),
  });

  const [theme, setTheme] = useState({});
  const [brand, setBrand] = useState({});
  const [upload, setUpload] = useState({});
  const [notifs, setNotifs] = useState({});
  const [activeTab, setActiveTab] = useState('theme');

  useEffect(() => {
    if (!settings) return;
    setTheme(settings.theme || {});
    setBrand(settings.brand || {});
    setUpload(settings.uploadSettings || {});
    setNotifs(settings.notifications || {});
  }, [settings]);

  const themeMut  = useMutation({ mutationFn: (d) => api.put('/admin/settings/theme', d),  onSuccess: () => toast.success('تم ذخیره شد') });
  const brandMut  = useMutation({ mutationFn: (d) => api.put('/admin/settings/brand', d),  onSuccess: () => toast.success('برند ذخیره شد') });
  const uploadMut = useMutation({ mutationFn: (d) => api.put('/admin/settings/upload', d), onSuccess: () => toast.success('تنظیمات آپلود ذخیره شد') });
  const notifMut  = useMutation({ mutationFn: (d) => api.put('/admin/settings/notifications', d), onSuccess: () => toast.success('اطلاع‌رسانی ذخیره شد') });

  const toggleFormat = (fmt) => {
    const curr = upload.allowedFormats || [];
    setUpload(u => ({
      ...u,
      allowedFormats: curr.includes(fmt)
        ? curr.filter(f => f !== fmt)
        : [...curr, fmt],
    }));
  };

  const TABS = [
    { id: 'theme',  label: '🎨 ظاهر' },
    { id: 'brand',  label: '🖼 برند' },
    { id: 'upload', label: '📁 آپلود' },
    { id: 'notif',  label: '🔔 اطلاع‌رسانی' },
    { id: 'lang',   label: '🌐 زبان' },
  ];

  if (isLoading) return <div className="page-body"><div className="text-muted">در حال بارگذاری...</div></div>;

  return (
    <>
      <Topbar title="سفارشی‌سازی اپ" subtitle="تنظیمات ظاهر، آپلود و اطلاع‌رسانی" />
      <div className="page-body animate-in">

        {/* ── Tabs ─────────────────────────────────────────────────────────── */}
        <div className="settings-tabs">
          {TABS.map(t => (
            <button
              key={t.id}
              className={`settings-tab${activeTab === t.id ? ' active' : ''}`}
              onClick={() => setActiveTab(t.id)}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* ── Theme ─────────────────────────────────────────────────────────── */}
        {activeTab === 'theme' && (
          <div className="settings-panel animate-in">
            <div className="grid-2">
              <div>
                <div className="form-group">
                  <label className="label">رنگ اصلی (Primary)</label>
                  <div className="color-row">
                    <input
                      type="color"
                      className="color-picker"
                      value={theme.primaryColor || '#7C6AF5'}
                      onChange={e => setTheme(t => ({ ...t, primaryColor: e.target.value }))}
                    />
                    <input
                      className="input"
                      value={theme.primaryColor || ''}
                      onChange={e => setTheme(t => ({ ...t, primaryColor: e.target.value }))}
                      placeholder="#7C6AF5"
                      dir="ltr"
                    />
                  </div>
                </div>
                <div className="form-group">
                  <label className="label">رنگ ثانوی (Secondary)</label>
                  <div className="color-row">
                    <input
                      type="color"
                      className="color-picker"
                      value={theme.secondaryColor || '#3DD68C'}
                      onChange={e => setTheme(t => ({ ...t, secondaryColor: e.target.value }))}
                    />
                    <input
                      className="input"
                      value={theme.secondaryColor || ''}
                      onChange={e => setTheme(t => ({ ...t, secondaryColor: e.target.value }))}
                      placeholder="#3DD68C"
                      dir="ltr"
                    />
                  </div>
                </div>
                <div className="form-group">
                  <label className="label">فونت برنامه</label>
                  <select
                    className="select"
                    value={theme.fontFamily || 'Vazirmatn'}
                    onChange={e => setTheme(t => ({ ...t, fontFamily: e.target.value }))}
                  >
                    {FONTS.map(f => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="label">اندازه متن</label>
                  <select
                    className="select"
                    value={theme.fontSize || 'medium'}
                    onChange={e => setTheme(t => ({ ...t, fontSize: e.target.value }))}
                  >
                    <option value="small">کوچک</option>
                    <option value="medium">متوسط</option>
                    <option value="large">بزرگ</option>
                  </select>
                </div>
              </div>

              {/* Live Preview */}
              <div className="theme-preview">
                <div className="preview-label">پیش‌نمایش</div>
                <div
                  className="preview-phone"
                  style={{ '--preview-brand': theme.primaryColor || '#7C6AF5' }}
                >
                  <div className="preview-header" style={{ background: '#1A1A2E' }}>
                    <div className="preview-title" style={{ fontFamily: theme.fontFamily }}>پرینت ۳D</div>
                  </div>
                  <div className="preview-content">
                    <div
                      className="preview-btn"
                      style={{ background: theme.primaryColor, fontFamily: theme.fontFamily }}
                    >
                      سفارش جدید
                    </div>
                    <div className="preview-card" style={{ borderColor: theme.primaryColor + '40' }}>
                      <div className="preview-badge" style={{ background: theme.primaryColor + '20', color: theme.primaryColor }}>
                        در حال چاپ
                      </div>
                      <div className="preview-text" style={{ fontFamily: theme.fontFamily }}>#PRT-2024-041</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="settings-save-row">
              <button className="btn btn-primary" onClick={() => themeMut.mutate(theme)} disabled={themeMut.isPending}>
                {themeMut.isPending ? 'در حال ذخیره...' : 'ذخیره تم'}
              </button>
            </div>
          </div>
        )}

        {/* ── Brand ─────────────────────────────────────────────────────────── */}
        {activeTab === 'brand' && (
          <div className="settings-panel animate-in">
            <div className="grid-2">
              <div>
                <div className="form-group">
                  <label className="label">نام اپ (فارسی)</label>
                  <input className="input" value={brand.appName?.fa || ''} onChange={e => setBrand(b => ({ ...b, appName: { ...b.appName, fa: e.target.value } }))} />
                </div>
                <div className="form-group">
                  <label className="label">نام اپ (انگلیسی)</label>
                  <input className="input" dir="ltr" value={brand.appName?.en || ''} onChange={e => setBrand(b => ({ ...b, appName: { ...b.appName, en: e.target.value } }))} />
                </div>
                <div className="form-group">
                  <label className="label">لوگو (URL)</label>
                  <input className="input" dir="ltr" value={brand.logoUrl || ''} onChange={e => setBrand(b => ({ ...b, logoUrl: e.target.value }))} placeholder="https://..." />
                </div>
                <div className="form-group">
                  <label className="label">تصویر Splash (URL)</label>
                  <input className="input" dir="ltr" value={brand.splashImageUrl || ''} onChange={e => setBrand(b => ({ ...b, splashImageUrl: e.target.value }))} placeholder="https://..." />
                </div>
              </div>
              <div className="brand-preview">
                <div className="preview-label">لوگو فعلی</div>
                {brand.logoUrl
                  ? <img src={brand.logoUrl} alt="logo" className="logo-preview" onError={e => e.target.style.display='none'} />
                  : <div className="logo-placeholder">🖨️</div>}
                <div className="app-name-preview" style={{ marginTop: 12 }}>
                  <div style={{ fontSize: '1.2rem', fontWeight: 700 }}>{brand.appName?.fa || 'پرینت ۳D'}</div>
                  <div style={{ fontSize: '0.85rem', color: 'var(--text-3)' }}>{brand.appName?.en || 'Print3D'}</div>
                </div>
              </div>
            </div>
            <div className="settings-save-row">
              <button className="btn btn-primary" onClick={() => brandMut.mutate(brand)} disabled={brandMut.isPending}>ذخیره برند</button>
            </div>
          </div>
        )}

        {/* ── Upload ────────────────────────────────────────────────────────── */}
        {activeTab === 'upload' && (
          <div className="settings-panel animate-in">
            <div className="grid-2">
              <div>
                <div className="form-group">
                  <label className="label">حداکثر حجم فایل (مگابایت)</label>
                  <div className="size-slider-row">
                    <input
                      type="range" min="5" max="500" step="5"
                      className="size-slider"
                      value={upload.maxFileSizeMB || 50}
                      onChange={e => setUpload(u => ({ ...u, maxFileSizeMB: +e.target.value }))}
                    />
                    <div className="size-badge">{upload.maxFileSizeMB || 50} MB</div>
                  </div>
                </div>
                <div className="form-group">
                  <label className="label">حداکثر تعداد فایل در هر سفارش</label>
                  <input
                    type="number" className="input" min="1" max="20"
                    value={upload.maxFilesPerOrder || 5}
                    onChange={e => setUpload(u => ({ ...u, maxFilesPerOrder: +e.target.value }))}
                  />
                </div>
                <div className="form-group">
                  <label className="label">نیاز به تایید دستی فایل</label>
                  <div className="toggle-wrap" onClick={() => setUpload(u => ({ ...u, requireApproval: !u.requireApproval }))}>
                    <div className={`toggle ${upload.requireApproval ? 'on' : ''}`} />
                    <span className="text-sm">{upload.requireApproval ? 'فعال — فایل‌ها باید تایید شوند' : 'غیرفعال — تایید خودکار'}</span>
                  </div>
                </div>
              </div>
              <div>
                <div className="form-group">
                  <label className="label">فرمت‌های مجاز</label>
                  <div className="formats-grid">
                    {FORMATS_ALL.map(fmt => {
                      const allowed = (upload.allowedFormats || []).includes(fmt);
                      return (
                        <button
                          key={fmt}
                          className={`format-btn${allowed ? ' allowed' : ' blocked'}`}
                          onClick={() => toggleFormat(fmt)}
                        >
                          .{fmt.toUpperCase()}
                          <span className="format-status">{allowed ? '✓' : '✕'}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
            <div className="settings-save-row">
              <button className="btn btn-primary" onClick={() => uploadMut.mutate(upload)} disabled={uploadMut.isPending}>ذخیره تنظیمات آپلود</button>
            </div>
          </div>
        )}

        {/* ── Notifications ─────────────────────────────────────────────────── */}
        {activeTab === 'notif' && (
          <div className="settings-panel animate-in">
            <div className="notif-rows">
              {[
                { key: 'smsEnabled',   icon: '📱', label: 'پیامک', sub: 'ارسال از طریق کاوه‌نگار' },
                { key: 'emailEnabled', icon: '📧', label: 'ایمیل', sub: 'ارسال از طریق SendGrid' },
              ].map(item => (
                <div key={item.key} className="notif-row">
                  <span className="notif-icon">{item.icon}</span>
                  <div className="notif-info">
                    <div className="notif-label">{item.label}</div>
                    <div className="text-xs text-dim">{item.sub}</div>
                  </div>
                  <div
                    className={`toggle ${notifs[item.key] ? 'on' : ''}`}
                    onClick={() => setNotifs(n => ({ ...n, [item.key]: !n[item.key] }))}
                  />
                </div>
              ))}
            </div>
            <div className="settings-save-row">
              <button className="btn btn-primary" onClick={() => notifMut.mutate(notifs)} disabled={notifMut.isPending}>ذخیره</button>
            </div>
          </div>
        )}

        {/* ── Language ──────────────────────────────────────────────────────── */}
        {activeTab === 'lang' && (
          <div className="settings-panel animate-in">
            <div className="lang-cards">
              {['fa', 'en'].map(lang => (
                <div
                  key={lang}
                  className={`lang-card${(settings?.defaultLanguage || 'fa') === lang ? ' active' : ''}`}
                  onClick={() => api.put('/admin/settings/upload', { defaultLanguage: lang }).then(() => toast.success('زبان پیش‌فرض تغییر کرد'))}
                >
                  <div className="lang-flag">{lang === 'fa' ? '🇮🇷' : '🇬🇧'}</div>
                  <div className="lang-name">{lang === 'fa' ? 'فارسی' : 'English'}</div>
                  {(settings?.defaultLanguage || 'fa') === lang && (
                    <span className="badge badge-green">پیش‌فرض</span>
                  )}
                </div>
              ))}
            </div>
            <p className="text-sm text-muted mt-4">کاربران می‌توانند زبان خود را از پروفایل تغییر دهند.</p>
          </div>
        )}

      </div>
    </>
  );
}
