import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import Topbar from '../../components/layout/Topbar';
import api from '../../services/api';
import './Modules.css';

const BUILTIN_MODULES = [
  { id: 'invoice-generator', name: { fa: 'فاکتور خودکار', en: 'Auto Invoice' }, icon: '🧾', desc: 'صدور PDF فاکتور پس از تکمیل پرداخت' },
  { id: 'delivery-tracking', name: { fa: 'پیک و ارسال', en: 'Delivery' }, icon: '🚚', desc: 'ردیابی پیک و مدیریت ارسال سفارشات' },
  { id: 'advanced-reports',  name: { fa: 'گزارش پیشرفته', en: 'Reports' }, icon: '📊', desc: 'آمار ماهانه، فصلی و مقایسه‌ای' },
  { id: 'discount-codes',    name: { fa: 'کد تخفیف', en: 'Discount' }, icon: '🏷️', desc: 'ایجاد و مدیریت کوپن‌های تخفیف' },
  { id: 'loyalty-points',    name: { fa: 'امتیاز وفاداری', en: 'Loyalty' }, icon: '⭐', desc: 'سیستم امتیازدهی به مشتریان' },
  { id: 'sms-marketing',     name: { fa: 'پیامک انبوه', en: 'SMS Marketing' }, icon: '📣', desc: 'ارسال پیامک به گروهی از مشتریان' },
  { id: 'material-inventory',name: { fa: 'انبار مواد', en: 'Inventory' }, icon: '🗄️', desc: 'مدیریت موجودی فیلامنت و رزین' },
  { id: 'custom-module',     name: { fa: 'ماژول سفارشی', en: 'Custom' }, icon: '🧩', desc: 'افزودن ماژول توسعه‌پذیر سفارشی' },
];

export default function ModulesPage() {
  const qc = useQueryClient();
  const [configuring, setConfiguring] = useState(null);

  const { data: settings } = useQuery({
    queryKey: ['app-settings'],
    queryFn: () => api.get('/admin/settings').then(r => r.data.settings),
  });

  const toggleMut = useMutation({
    mutationFn: ({ id, enabled }) => api.put(`/admin/modules/${id}`, { enabled }),
    onSuccess: (_, { enabled }) => {
      qc.invalidateQueries(['app-settings']);
      toast.success(enabled ? 'ماژول فعال شد' : 'ماژول غیرفعال شد');
    },
  });

  const isEnabled = (id) => settings?.modules?.find(m => m.id === id)?.enabled || false;

  return (
    <>
      <Topbar
        title="مدیریت ماژول‌ها"
        subtitle="فعال‌سازی و تنظیم قابلیت‌های افزونه‌ای"
      />
      <div className="page-body animate-in">

        <div className="modules-info card mb-4">
          <div className="flex gap-3 items-center">
            <span style={{ fontSize: '1.5rem' }}>🧩</span>
            <div>
              <div className="text-sm" style={{ fontWeight: 600, marginBottom: 2 }}>سیستم ماژولار</div>
              <div className="text-xs text-muted">هر ماژول را می‌توانید به صورت مستقل فعال یا غیرفعال کنید. ماژول‌های سفارشی با قرار دادن در پوشه <code className="mono" style={{fontSize:'0.75rem',background:'var(--ink-3)',padding:'1px 5px',borderRadius:3}}>/modules</code> اضافه می‌شوند.</div>
            </div>
          </div>
        </div>

        <div className="modules-grid">
          {BUILTIN_MODULES.map(mod => {
            const enabled = isEnabled(mod.id);
            const loading = toggleMut.isPending && toggleMut.variables?.id === mod.id;
            return (
              <div key={mod.id} className={`module-card card${enabled ? ' enabled' : ''}`}>
                <div className="module-header">
                  <div className="module-icon">{mod.icon}</div>
                  <div className="module-info">
                    <div className="module-name">{mod.name.fa}</div>
                    <div className="module-name-en text-xs text-dim">{mod.name.en}</div>
                  </div>
                  <div
                    className={`toggle ${enabled ? 'on' : ''}${loading ? ' loading' : ''}`}
                    onClick={() => !loading && toggleMut.mutate({ id: mod.id, enabled: !enabled })}
                  />
                </div>
                <p className="module-desc text-sm text-muted">{mod.desc}</p>
                <div className="module-footer">
                  <span className={`badge ${enabled ? 'badge-green' : 'badge-gray'}`}>
                    {enabled ? 'فعال' : 'غیرفعال'}
                  </span>
                  {enabled && (
                    <button
                      className="btn btn-ghost btn-sm"
                      onClick={() => setConfiguring(mod)}
                    >
                      ⚙ تنظیمات
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Config Modal */}
        {configuring && (
          <div className="modal-overlay" onClick={() => setConfiguring(null)}>
            <div className="modal" onClick={e => e.stopPropagation()}>
              <div className="modal-header">
                <h3>{configuring.icon} تنظیمات {configuring.name.fa}</h3>
                <button className="btn btn-icon btn-ghost" onClick={() => setConfiguring(null)}>✕</button>
              </div>
              <div className="modal-body">
                <p className="text-sm text-muted">تنظیمات اختصاصی این ماژول در نسخه بعدی اضافه می‌شود.</p>
                <div className="config-placeholder">
                  <span style={{ fontSize: '2rem' }}>{configuring.icon}</span>
                  <span className="text-muted text-sm">{configuring.name.fa}</span>
                  <span className="badge badge-green">فعال</span>
                </div>
              </div>
              <div className="modal-footer">
                <button className="btn btn-primary" onClick={() => setConfiguring(null)}>بستن</button>
              </div>
            </div>
          </div>
        )}

      </div>
    </>
  );
}
