import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import Topbar from '../../components/layout/Topbar';
import api from '../../services/api';
import './Files.css';

const FILE_ICONS = {
  stl:'🖨️', obj:'📦', '3mf':'🎯', gcode:'⚙️',
  step:'🔩', stp:'🔩', zip:'🗜️', pdf:'📄',
  jpg:'🖼️', png:'🖼️',
};

const STATUS_CFG = {
  pending:  { label:'در انتظار', cls:'b-amber' },
  approved: { label:'تایید شده', cls:'b-green' },
  rejected: { label:'رد شده',   cls:'b-red'   },
};

export default function FilesPage() {
  const qc = useQueryClient();
  const [statusFilter, setStatusFilter] = useState('pending');
  const [selectedFile, setSelectedFile] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [page, setPage] = useState(1);

  const { data, isLoading } = useQuery({
    queryKey: ['orders-with-files', statusFilter, page],
    queryFn: () => api.get('/orders', {
      params: {
        fileStatus: statusFilter || undefined,
        page, limit: 20,
      }
    }).then(r => r.data),
  });

  const approveMut = useMutation({
    mutationFn: ({ orderId, fileId, status, reason }) =>
      api.patch(`/orders/${orderId}/files/${fileId}/approve`, { status, reason }),
    onSuccess: (_, { status }) => {
      qc.invalidateQueries(['orders-with-files']);
      toast.success(status === 'approved' ? '✅ فایل تایید شد' : '❌ فایل رد شد');
      setSelectedFile(null);
      setRejectReason('');
    },
    onError: err => toast.error(err.response?.data?.error || 'خطا'),
  });

  // همه فایل‌ها رو از همه سفارشات جمع کن
  const allFiles = data?.orders?.flatMap(order =>
    (order.files || [])
      .filter(f => !statusFilter || f.status === statusFilter)
      .map(f => ({ ...f, order }))
  ) || [];

  return (
    <>
      <Topbar
        title="مدیریت فایل‌ها"
        subtitle={`${allFiles.length} فایل`}
      />
      <div className="page-body animate-in">

        {/* Filters */}
        <div className="card filters-bar" style={{ marginBottom:14 }}>
          <div className="flex gap-2 items-center flex-wrap">
            {[
              { id:'pending',  label:'در انتظار بررسی' },
              { id:'approved', label:'تایید شده' },
              { id:'rejected', label:'رد شده' },
              { id:'',         label:'همه' },
            ].map(s => (
              <button
                key={s.id}
                className={`status-tab${statusFilter === s.id ? ' active' : ''}`}
                onClick={() => { setStatusFilter(s.id); setPage(1); }}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Files Table */}
        <div className="card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>فایل</th>
                  <th>سفارش</th>
                  <th>مشتری</th>
                  <th>حجم</th>
                  <th>تاریخ آپلود</th>
                  <th>وضعیت</th>
                  <th>اقدام</th>
                </tr>
              </thead>
              <tbody>
                {isLoading
                  ? Array(8).fill(0).map((_,i) => (
                    <tr key={i}>
                      {Array(7).fill(0).map((_,j) => (
                        <td key={j}><div className="skeleton" style={{height:14}}/></td>
                      ))}
                    </tr>
                  ))
                  : allFiles.length === 0 ? (
                    <tr>
                      <td colSpan={7} style={{textAlign:'center',padding:32,color:'var(--t3)'}}>
                        فایلی یافت نشد
                      </td>
                    </tr>
                  )
                  : allFiles.map(file => {
                    const ext = file.format || file.name?.split('.').pop()?.toLowerCase() || '?';
                    const icon = FILE_ICONS[ext] || '📄';
                    const statusCfg = STATUS_CFG[file.status] || STATUS_CFG.pending;
                    const sizeLabel = file.size
                      ? file.size > 1024*1024
                        ? `${(file.size/1024/1024).toFixed(1)} MB`
                        : `${(file.size/1024).toFixed(0)} KB`
                      : '—';

                    return (
                      <tr key={file._id}>
                        <td>
                          <div style={{display:'flex',alignItems:'center',gap:8}}>
                            <span style={{fontSize:18}}>{icon}</span>
                            <div>
                              <div style={{fontSize:'.82rem',fontWeight:500}}>{file.name || '—'}</div>
                              <div style={{fontSize:'.68rem',color:'var(--t3)'}}>
                                .{ext.toUpperCase()}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td>
                          <span className="mono" style={{fontSize:'.75rem',color:'var(--brand)'}}>
                            {file.order.orderNumber}
                          </span>
                        </td>
                        <td>
                          <div style={{fontSize:'.8rem'}}>{file.order.customer?.name || '—'}</div>
                          <div className="mono" style={{fontSize:'.68rem',color:'var(--t3)'}}>
                            {file.order.customer?.phone}
                          </div>
                        </td>
                        <td style={{fontSize:'.78rem',color:'var(--t2)'}}>{sizeLabel}</td>
                        <td style={{fontSize:'.75rem',color:'var(--t2)'}}>
                          {file.uploadedAtJalali || new Date(file.uploadedAt).toLocaleDateString('fa-IR')}
                        </td>
                        <td>
                          <span className={`badge ${statusCfg.cls}`}>{statusCfg.label}</span>
                          {file.status === 'rejected' && file.rejectionReason && (
                            <div style={{fontSize:'.65rem',color:'var(--red)',marginTop:2}}>
                              {file.rejectionReason}
                            </div>
                          )}
                        </td>
                        <td>
                          <div style={{display:'flex',gap:5,flexWrap:'wrap'}}>
                            {/* دانلود */}
                            {file.url && (
                              <a
                                href={file.url}
                                download={file.name}
                                target="_blank"
                                rel="noreferrer"
                                className="btn btn-ghost btn-sm"
                                title="دانلود"
                              >
                                ⬇️
                              </a>
                            )}
                            {/* تایید */}
                            {file.status !== 'approved' && (
                              <button
                                className="btn btn-ghost btn-sm"
                                style={{color:'var(--green)'}}
                                onClick={() => approveMut.mutate({
                                  orderId: file.order._id,
                                  fileId: file._id,
                                  status: 'approved',
                                })}
                                disabled={approveMut.isPending}
                              >
                                ✅
                              </button>
                            )}
                            {/* رد */}
                            {file.status !== 'rejected' && (
                              <button
                                className="btn btn-danger btn-sm"
                                onClick={() => setSelectedFile(file)}
                              >
                                ❌
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {data?.pages > 1 && (
            <div className="pagination">
              <button className="btn btn-ghost btn-sm" disabled={page===1} onClick={() => setPage(p=>p-1)}>← قبلی</button>
              <span className="text-sm text-muted">صفحه {page} از {data.pages}</span>
              <button className="btn btn-ghost btn-sm" disabled={page>=data.pages} onClick={() => setPage(p=>p+1)}>بعدی →</button>
            </div>
          )}
        </div>

        {/* Modal رد فایل */}
        {selectedFile && (
          <div className="modal-overlay" onClick={() => setSelectedFile(null)}>
            <div className="modal" onClick={e => e.stopPropagation()}>
              <div className="modal-header">
                <h3>❌ رد فایل</h3>
                <button className="btn btn-icon btn-ghost" onClick={() => setSelectedFile(null)}>✕</button>
              </div>
              <div className="modal-body">
                <div style={{marginBottom:12}}>
                  <div style={{fontSize:'.85rem',fontWeight:600,marginBottom:4}}>{selectedFile.name}</div>
                  <div style={{fontSize:'.78rem',color:'var(--t2)'}}>سفارش: {selectedFile.order.orderNumber}</div>
                </div>
                <div className="form-group">
                  <label className="label">دلیل رد (اختیاری)</label>
                  <textarea
                    className="textarea"
                    rows={3}
                    placeholder="مثلاً: فرمت فایل مناسب نیست، کیفیت پایین..."
                    value={rejectReason}
                    onChange={e => setRejectReason(e.target.value)}
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button className="btn btn-ghost" onClick={() => setSelectedFile(null)}>لغو</button>
                <button
                  className="btn btn-danger"
                  onClick={() => approveMut.mutate({
                    orderId: selectedFile.order._id,
                    fileId: selectedFile._id,
                    status: 'rejected',
                    reason: rejectReason,
                  })}
                  disabled={approveMut.isPending}
                >
                  رد فایل
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </>
  );
}
