import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import Topbar from '../../components/layout/Topbar';
import api from '../../services/api';
import './Orders.css';

const STATUSES = [
  { id: '', label: 'همه' },
  { id: 'new', label: 'جدید', cls: 'badge-brand' },
  { id: 'reviewing', label: 'بررسی', cls: 'badge-blue' },
  { id: 'printing', label: 'چاپ', cls: 'badge-amber' },
  { id: 'quality_check', label: 'کنترل', cls: 'badge-brand' },
  { id: 'ready', label: 'آماده', cls: 'badge-green' },
  { id: 'delivered', label: 'تحویل', cls: 'badge-gray' },
  { id: 'cancelled', label: 'لغو', cls: 'badge-red' },
];

const NEXT_STATUS = {
  new: 'reviewing', reviewing: 'printing',
  printing: 'quality_check', quality_check: 'ready', ready: 'delivered',
};

export default function OrdersPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [statusFilter, setStatusFilter] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [selectedOrder, setSelectedOrder] = useState(null);

  const { data, isLoading } = useQuery({
    queryKey: ['admin-orders', statusFilter, search, page],
    queryFn: () => api.get('/orders', {
      params: { status: statusFilter || undefined, search: search || undefined, page, limit: 25 },
    }).then(r => r.data),
    keepPreviousData: true,
  });

  const { data: empData } = useQuery({
    queryKey: ['employees-list'],
    queryFn: () => api.get('/employees').then(r => r.data.employees),
  });

  const statusMutation = useMutation({
    mutationFn: ({ id, status, note }) => api.patch(`/orders/${id}/status`, { status, note }),
    onSuccess: () => { qc.invalidateQueries(['admin-orders']); setSelectedOrder(null); },
  });

  const assignMutation = useMutation({
    mutationFn: ({ id, employeeId }) => api.post(`/orders/${id}/assign`, { employeeId }),
    onSuccess: () => qc.invalidateQueries(['admin-orders']),
  });

  const approveFileMutation = useMutation({
    mutationFn: ({ orderId, fileId, status, reason }) =>
      api.patch(`/orders/${orderId}/files/${fileId}/approve`, { status, reason }),
    onSuccess: () => qc.invalidateQueries(['admin-orders']),
  });

  return (
    <>
      <Topbar
        title="مدیریت سفارشات"
        subtitle={`${data?.total ?? 0} سفارش`}
        actions={
          <button className="btn btn-primary btn-sm" onClick={() => navigate('/orders/new')}>
            + سفارش جدید
          </button>
        }
      />

      <div className="page-body animate-in">

        {/* ── Filters ─────────────────────────────────────────────────────── */}
        <div className="card filters-bar">
          <div className="flex gap-2 items-center">
            <input
              className="input" style={{ maxWidth: 220 }}
              placeholder="جستجوی شماره / مشتری..."
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }}
            />
            <div className="status-tabs">
              {STATUSES.map(s => (
                <button
                  key={s.id}
                  className={`status-tab${statusFilter === s.id ? ' active' : ''}`}
                  onClick={() => { setStatusFilter(s.id); setPage(1); }}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* ── Table ───────────────────────────────────────────────────────── */}
        <div className="card mt-4">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>شماره سفارش</th>
                  <th>مشتری</th>
                  <th>تنظیمات چاپ</th>
                  <th>فایل‌ها</th>
                  <th>کارمند</th>
                  <th>مبلغ / پرداخت</th>
                  <th>وضعیت</th>
                  <th>اقدام</th>
                </tr>
              </thead>
              <tbody>
                {isLoading
                  ? Array(8).fill(0).map((_, i) => (
                    <tr key={i}>
                      {Array(8).fill(0).map((__, j) => (
                        <td key={j}><div className="skeleton" style={{ height: 16, borderRadius: 4 }} /></td>
                      ))}
                    </tr>
                  ))
                  : data?.orders?.map(order => {
                    const s = STATUSES.find(x => x.id === order.status) || STATUSES[1];
                    const pendingFiles = order.files?.filter(f => f.status === 'pending').length || 0;
                    return (
                      <tr key={order._id}>
                        <td>
                          <button
                            className="order-num-btn"
                            onClick={() => navigate(`/orders/${order._id}`)}
                          >
                            {order.orderNumber}
                          </button>
                          <div className="text-xs text-dim">
                            {new Date(order.createdAt).toLocaleDateString('fa-IR')}
                          </div>
                        </td>
                        <td>
                          <div className="text-sm">{order.customer?.name || '—'}</div>
                          <div className="text-xs text-dim mono">{order.customer?.phone}</div>
                        </td>
                        <td className="text-sm text-muted">
                          {order.printSettings?.material} · {order.printSettings?.quality === 'high' ? 'دقیق' : order.printSettings?.quality === 'draft' ? 'سریع' : 'استاندارد'}
                          <br />
                          <span className="text-xs text-dim">×{order.printSettings?.quantity}</span>
                        </td>
                        <td>
                          <div className="files-summary">
                            <span className="text-xs">{order.files?.length || 0} فایل</span>
                            {pendingFiles > 0 && (
                              <span className="badge badge-amber text-xs">{pendingFiles} در انتظار</span>
                            )}
                          </div>
                        </td>
                        <td>
                          <select
                            className="select select-sm"
                            value={order.assignedEmployee?._id || ''}
                            onChange={e => assignMutation.mutate({ id: order._id, employeeId: e.target.value })}
                          >
                            <option value="">تخصیص‌نشده</option>
                            {empData?.map(emp => (
                              <option key={emp._id} value={emp._id}>{emp.name}</option>
                            ))}
                          </select>
                        </td>
                        <td>
                          <div className="text-sm">
                            {order.payment?.amount
                              ? `${order.payment.amount.toLocaleString()} ${order.payment.currency === 'USD' ? '$' : 'ت'}`
                              : '—'}
                          </div>
                          <span className={`badge text-xs ${order.payment?.status === 'paid' ? 'badge-green' : 'badge-amber'}`}>
                            {order.payment?.status === 'paid' ? 'پرداخت شده' : 'در انتظار'}
                          </span>
                        </td>
                        <td><span className={`badge ${s.cls}`}>{s.label}</span></td>
                        <td>
                          <div className="action-btns">
                            {NEXT_STATUS[order.status] && (
                              <button
                                className="btn btn-ghost btn-sm"
                                onClick={() => statusMutation.mutate({
                                  id: order._id,
                                  status: NEXT_STATUS[order.status],
                                })}
                              >
                                →
                              </button>
                            )}
                            <button
                              className="btn btn-ghost btn-sm"
                              onClick={() => navigate('/chats', { state: { chatId: order.chat } })}
                            >
                              💬
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {data?.pages > 1 && (
            <div className="pagination">
              <button
                className="btn btn-ghost btn-sm"
                disabled={page === 1}
                onClick={() => setPage(p => p - 1)}
              >← قبلی</button>
              <span className="text-sm text-muted">صفحه {page} از {data.pages}</span>
              <button
                className="btn btn-ghost btn-sm"
                disabled={page >= data.pages}
                onClick={() => setPage(p => p + 1)}
              >بعدی →</button>
            </div>
          )}
        </div>

      </div>
    </>
  );
}
