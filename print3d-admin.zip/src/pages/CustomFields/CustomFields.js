import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm, useFieldArray } from 'react-hook-form';
import toast from 'react-hot-toast';
import Topbar from '../../components/layout/Topbar';
import api from '../../services/api';
import './CustomFields.css';

const FIELD_TYPES = [
  { value: 'text',        label: 'متن کوتاه' },
  { value: 'textarea',    label: 'متن بلند' },
  { value: 'number',      label: 'عدد' },
  { value: 'select',      label: 'انتخاب تکی' },
  { value: 'multiselect', label: 'انتخاب چندگانه' },
  { value: 'boolean',     label: 'بله / خیر' },
  { value: 'date',        label: 'تاریخ' },
  { value: 'file',        label: 'فایل' },
];

const SECTIONS = [
  { value: 'basic',          label: 'اطلاعات پایه' },
  { value: 'print_settings', label: 'تنظیمات چاپ' },
  { value: 'material',       label: 'مواد و رزین' },
  { value: 'extra',          label: 'سایر' },
];

export default function CustomFieldsPage() {
  const qc = useQueryClient();
  const [editing, setEditing] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['custom-fields-all'],
    queryFn: () => api.get('/admin/custom-fields/all').then(r => r.data.fields),
  });

  const { register, handleSubmit, reset, watch, control, formState: { errors } } = useForm({
    defaultValues: { options: [] }
  });

  const { fields: optionFields, append: addOption, remove: removeOption } = useFieldArray({
    control, name: 'options',
  });

  const fieldType = watch('type');

  const saveMut = useMutation({
    mutationFn: (d) => editing
      ? api.put(`/admin/custom-fields/${editing._id}`, d)
      : api.post('/admin/custom-fields', d),
    onSuccess: () => {
      qc.invalidateQueries(['custom-fields-all']);
      toast.success('ذخیره شد');
      closeModal();
    },
    onError: err => toast.error(err.response?.data?.error || 'خطا'),
  });

  const toggleActiveMut = useMutation({
    mutationFn: ({ id, isActive }) => api.put(`/admin/custom-fields/${id}`, { isActive }),
    onSuccess: () => qc.invalidateQueries(['custom-fields-all']),
  });

  const openEdit = (field) => {
    setEditing(field);
    reset({
      key:              field.key,
      'label.fa':       field.label.fa,
      'label.en':       field.label.en,
      type:             field.type,
      section:          field.section,
      required:         field.required,
      order:            field.order,
      'placeholder.fa': field.placeholder?.fa || '',
      'placeholder.en': field.placeholder?.en || '',
      'helpText.fa':    field.helpText?.fa || '',
      options:          field.options || [],
    });
    setShowModal(true);
  };

  const openNew = () => {
    setEditing(null);
    reset({ options: [], required: false, order: (data?.length || 0) + 1 });
    setShowModal(true);
  };

  const closeModal = () => { setShowModal(false); setEditing(null); reset({ options: [] }); };

  return (
    <>
      <Topbar
        title="فیلدهای سفارشی"
        subtitle="مدیریت فرم ثبت سفارش"
        actions={<button className="btn btn-primary btn-sm" onClick={openNew}>+ فیلد جدید</button>}
      />
      <div className="page-body animate-in">

        <div className="card" style={{marginBottom:14,padding:'12px 16px'}}>
          <div className="flex gap-3 items-center">
            <span style={{fontSize:'1.4rem'}}>🧩</span>
            <div>
              <div style={{fontSize:'.88rem',fontWeight:600,marginBottom:2}}>فیلدهای داینامیک فرم سفارش</div>
              <div className="text-xs text-muted">
                هر فیلدی که اینجا اضافه کنید در فرم ثبت سفارش مشتریان نمایش داده می‌شود.
                فیلد رزین از پیش تعریف شده و اجباری است.
              </div>
            </div>
          </div>
        </div>

        <div className="fields-grid">
          {isLoading
            ? Array(4).fill(0).map((_,i) => <div key={i} className="card"><div className="skeleton" style={{height:80}}/></div>)
            : data?.map(field => (
              <div key={field._id} className={`card field-card${!field.isActive ? ' inactive' : ''}`}>
                <div className="field-header">
                  <div className="field-type-badge">{FIELD_TYPES.find(t=>t.value===field.type)?.label || field.type}</div>
                  <div style={{marginRight:'auto',display:'flex',gap:6}}>
                    {field.required && <span className="badge b-red" style={{fontSize:'.65rem'}}>اجباری</span>}
                    {!field.isActive && <span className="badge b-gray" style={{fontSize:'.65rem'}}>غیرفعال</span>}
                  </div>
                  <span style={{fontSize:'.7rem',color:'var(--t3)'}}>#{field.order}</span>
                </div>
                <div className="field-name">{field.label.fa}</div>
                <div className="text-xs text-dim" style={{marginBottom:6}}>{field.label.en}</div>
                <code className="mono" style={{fontSize:'.68rem',color:'var(--brand)',display:'block',marginBottom:8}}>{field.key}</code>

                {field.options?.length > 0 && (
                  <div className="field-options">
                    {field.options.slice(0,4).map(opt => (
                      <span key={opt.value} className="opt-chip" style={opt.color ? {borderColor:opt.color+'60',color:opt.color} : {}}>
                        {opt.color && <span style={{width:7,height:7,borderRadius:'50%',background:opt.color,display:'inline-block',marginLeft:4}}/>}
                        {opt.label.fa}
                      </span>
                    ))}
                    {field.options.length > 4 && <span className="opt-chip text-dim">+{field.options.length-4}</span>}
                  </div>
                )}

                <div className="field-actions">
                  <button className="btn btn-ghost btn-sm" onClick={() => openEdit(field)}>ویرایش</button>
                  <button
                    className={`btn btn-sm ${field.isActive ? 'btn-danger' : 'btn-ghost'}`}
                    onClick={() => toggleActiveMut.mutate({ id: field._id, isActive: !field.isActive })}
                  >
                    {field.isActive ? 'غیرفعال' : 'فعال‌سازی'}
                  </button>
                </div>
              </div>
            ))}
        </div>

        {/* Modal */}
        {showModal && (
          <div className="modal-overlay" onClick={closeModal}>
            <div className="modal modal-lg" onClick={e => e.stopPropagation()}>
              <div className="modal-header">
                <h3>{editing ? `ویرایش: ${editing.label?.fa}` : 'فیلد جدید'}</h3>
                <button className="btn btn-icon btn-ghost" onClick={closeModal}>✕</button>
              </div>
              <form onSubmit={handleSubmit(d => saveMut.mutate(d))}>
                <div className="modal-body">
                  <div className="grid-2">
                    <div>
                      <div className="form-group">
                        <label className="label">نوع فیلد</label>
                        <select className="select" {...register('type', {required:true})}>
                          {FIELD_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                        </select>
                      </div>
                      <div className="form-group">
                        <label className="label">نام فارسی</label>
                        <input className="input" {...register('label.fa', {required:true})} placeholder="مثال: نوع رزین" />
                      </div>
                      <div className="form-group">
                        <label className="label">نام انگلیسی</label>
                        <input className="input" {...register('label.en', {required:true})} placeholder="e.g. Resin Type" dir="ltr" />
                      </div>
                      {!editing && (
                        <div className="form-group">
                          <label className="label">کلید (انگلیسی، بدون فاصله)</label>
                          <input className="input" {...register('key', {required:true})} placeholder="resin_type" dir="ltr" />
                        </div>
                      )}
                      <div className="grid-2">
                        <div className="form-group">
                          <label className="label">بخش فرم</label>
                          <select className="select" {...register('section')}>
                            {SECTIONS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                          </select>
                        </div>
                        <div className="form-group">
                          <label className="label">ترتیب</label>
                          <input className="input" type="number" {...register('order')} />
                        </div>
                      </div>
                      <div className="form-group">
                        <label className="label">راهنما (فارسی)</label>
                        <input className="input" {...register('helpText.fa')} placeholder="توضیح برای مشتری" />
                      </div>
                      <label style={{display:'flex',alignItems:'center',gap:8,cursor:'pointer',fontSize:'.82rem',color:'var(--t1)'}}>
                        <input type="checkbox" {...register('required')} style={{accentColor:'var(--brand)',width:15,height:15}} />
                        این فیلد اجباری است
                      </label>
                    </div>

                    {/* Options for select types */}
                    {(fieldType === 'select' || fieldType === 'multiselect') && (
                      <div>
                        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:10}}>
                          <strong style={{fontSize:'.85rem'}}>گزینه‌ها</strong>
                          <button
                            type="button" className="btn btn-ghost btn-sm"
                            onClick={() => addOption({ value:'', 'label.fa':'', 'label.en':'', color:'' })}
                          >+ افزودن گزینه</button>
                        </div>
                        <div style={{display:'flex',flexDirection:'column',gap:8,maxHeight:320,overflowY:'auto'}}>
                          {optionFields.map((opt, i) => (
                            <div key={opt.id} className="option-row">
                              <input className="input" {...register(`options.${i}.value`)} placeholder="value" dir="ltr" style={{flex:1}} />
                              <input className="input" {...register(`options.${i}.label.fa`)} placeholder="نام فارسی" style={{flex:1.5}} />
                              <input
                                type="color" {...register(`options.${i}.color`)}
                                style={{width:32,height:32,borderRadius:6,border:'1px solid var(--border)',padding:2,cursor:'pointer',background:'var(--ink3)'}}
                              />
                              <button type="button" className="btn btn-icon btn-danger" onClick={() => removeOption(i)}>✕</button>
                            </div>
                          ))}
                          {optionFields.length === 0 && (
                            <div className="text-xs text-dim" style={{textAlign:'center',padding:16}}>
                              هنوز گزینه‌ای اضافه نشده
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-ghost" onClick={closeModal}>لغو</button>
                  <button type="submit" className="btn btn-primary" disabled={saveMut.isPending}>
                    {saveMut.isPending ? 'ذخیره...' : 'ذخیره فیلد'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
