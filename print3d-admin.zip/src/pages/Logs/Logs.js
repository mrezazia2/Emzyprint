import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import Topbar from '../../components/layout/Topbar';
import api from '../../services/api';
import './Logs.css';

const CATEGORIES = [
  { id: '', label: 'همه' },
  { id: 'auth', label: '🔐 احراز هویت' },
  { id: 'order', label: '📋 سفارش' },
  { id: 'payment', label: '💳 پرداخت' },
  { id: 'file', label: '📁 فایل' },
  { id: 'settings', label: '⚙️ تنظیمات' },
  { id: 'employee', label: '👷 کارمند' },
  { id: 'chat', label: '💬 چت' },
  { id: 'module', label: '🧩 ماژول' },
];

const SEVERITY_CFG = {
  info:    { cls: 'badge-brand', label: 'اطلاع', dot: '#7C6AF5' },
  warning: { cls: 'badge-amber', label: 'هشدار', dot: '#F5A623' },
  error:   { cls: 'badge-red',   label: 'خطا',   dot: '#F0614E' },
};

const ACTION_ICON = {
  login: '🔓', send_otp: '📱', order_created: '📝', order_status_changed: '🔄',
  order_assigned: '👷', file_reviewed: '📁', payment_verified: '✅',
  settings_theme_updated: '🎨', upload_settings_updated: '⚙️',
  employee_created: '👤', employee_removed: '🗑️', module_updated: '🧩',
  message_sent: '💬', stripe_payment_success: '💵',
};

export default function LogsPage() {
  const [category, setCategory] = useState('');
  const [severity, setSeverity] = useState('');
  const [page, setPage] = useState(1);

  const { data, isLoading } = useQuery({
    queryKey: ['logs', category, severity, page],
    queryFn: () => api.get('/admin/logs', {
      params: { category: category || undefined, severity: severity || undefined, page, limit: 40 },
    }).then(r => r.data),
    keepPreviousData: true,
    refetchInterval: 30_000,
  });

  const formatTime = (dt) => {
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
    }).format(new Date(dt));
  };

  return (
    <>
      <Topbar title="لاگ سیستم" subtitle="ثبت کامل همه رویدادها" />
      <div className="page-body animate-in">

        {/* Filters */}
        <div className="card filters-bar flex gap-2 items-center flex-wrap">
          <div className="status-tabs">
            {CATEGORIES.map(c => (
              <button
                key={c.id}
                className={`status-tab${category === c.id ? ' active' : ''}`}
                onClick={() => { setCategory(c.id); setPage(1); }}
              >
                {c.label}
              </button>
            ))}
          </div>
          <select
            className="select" style={{ width: 120 }}
            value={severity}
            onChange={e => { setSeverity(e.target.value); setPage(1); }}
          >
            <option value="">همه شدت‌ها</option>
            <option value="info">اطلاع</option>
            <option value="warning">هشدار</option>
            <option value="error">خطا</option>
          </select>
          <div className="text-xs text-dim" style={{ marginRight: 'auto' }}>
            {data?.total ?? 0} رویداد
          </div>
        </div>

        {/* Log Table */}
        <div className="card mt-4 logs-card">
          <div className="table-wrap">
            <table className="logs-table">
              <thead>
                <tr>
                  <th style={{ width: 160 }}>زمان</th>
                  <th style={{ width: 100 }}>دسته</th>
                  <th style={{ width: 80 }}>شدت</th>
                  <th>رویداد</th>
                  <th>کاربر</th>
                  <th>جزئیات</th>
                  <th>IP</th>
                </tr>
              </thead>
              <tbody>
                {isLoading
                  ? Array(15).fill(0).map((_, i) => (
                    <tr key={i}>
                      {Array(7).fill(0).map((__, j) => (
                        <td key={j}><div className="skeleton" style={{ height: 14, borderRadius: 3 }} /></td>
                      ))}
                    </tr>
                  ))
                  : data?.logs?.map(log => {
                    const sev = SEVERITY_CFG[log.severity] || SEVERITY_CFG.info;
                    const icon = ACTION_ICON[log.action] || '◉';
                    return (
                      <tr key={log._id} className={`log-row log-${log.severity}`}>
                        <td>
                          <span className="mono text-xs text-dim">{formatTime(log.createdAt)}</span>
                        </td>
                        <td>
                          <span className="badge badge-gray text-xs">{log.category || '—'}</span>
                        </td>
                        <td>
                          <span className={`badge ${sev.cls} text-xs`}>
                            <span className="sev-dot" style={{ background: sev.dot }} />
                            {sev.label}
                          </span>
                        </td>
                        <td>
                          <div className="action-cell">
                            <span className="action-icon">{icon}</span>
                            <span className="mono text-xs">{log.action}</span>
                          </div>
                        </td>
                        <td>
                          {log.actor
                            ? <div>
                                <div className="text-sm">{log.actor.name || '—'}</div>
                                <div className="text-xs text-dim">{log.actorRole}</div>
                              </div>
                            : <span className="text-dim text-xs">سیستم</span>}
                        </td>
                        <td>
                          {log.details
                            ? <details className="log-details">
                                <summary className="text-xs text-brand">نمایش</summary>
                                <pre className="log-json mono text-xs">
                                  {JSON.stringify(log.details, null, 2)}
                                </pre>
                              </details>
                            : <span className="text-dim text-xs">—</span>}
                        </td>
                        <td><span className="mono text-xs text-dim">{log.ip || '—'}</span></td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
          {data?.total > 40 && (
            <div className="pagination">
              <button className="btn btn-ghost btn-sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>← قبلی</button>
              <span className="text-sm text-muted">صفحه {page}</span>
              <button className="btn btn-ghost btn-sm" onClick={() => setPage(p => p + 1)}>بعدی →</button>
            </div>
          )}
        </div>

      </div>
    </>
  );
}
