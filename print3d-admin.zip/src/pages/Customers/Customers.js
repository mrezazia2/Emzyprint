import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import Topbar from '../../components/layout/Topbar';
import api from '../../services/api';

export default function CustomersPage() {
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState(null);

  const { data, isLoading } = useQuery({
    queryKey: ['customers', search, page],
    queryFn: () => api.get('/admin/users', {
      params: { role: 'customer', search: search || undefined, page, limit: 20 }
    }).then(r => r.data),
  });

  const { register, handleSubmit, reset, formState: { errors } } = useForm();

  const addMut = useMutation({
    mutationFn: (d) => api.post('/admin/users/create', d),
    onSuccess: () => { qc.invalidateQueries(['customers']); toast.success('مشتری اضافه شد'); setShowAddModal(false); reset(); },
    onError: err => toast.error(err.response?.data?.error || 'خطا'),
  });

  const editMut = useMutation({
    mutationFn: ({ id, data }) => api.patch(`/admin/users/${id}`, data),
    onSuccess: () => { qc.invalidateQueries(['customers']); toast.success('ویرایش شد'); setEditingCustomer(null); reset(); },
    onError: err => toast.error(err.response?.data?.error || 'خطا'),
  });

  const deleteMut = useMutation({
    mutationFn: (id) => api.delete(`/admin/users/${id}`),
    onSuccess: () => { qc.invalidateQueries(['customers']); toast.success('حذف شد'); },
    onError: err => toast.error(err.response?.data?.error || 'خطا'),
  });

  const approveMut = useMutation({
    mutationFn: ({ id, action }) => api.patch(`/admin/users/${id}/approve`, { action }),
    onSuccess: (_, { action }) => { qc.invalidateQueries(['customers']); toast.success(action === 'approve' ? 'تایید شد' : 'رد شد'); },
    onError: err => toast.error(err.response?.data?.error || 'خطا'),
  });

  const openEdit = (customer) => {
    setEditingCustomer(customer);
    reset({ name: customer.name, phone: customer.phone, email: customer.email || '' });
  };

  const onSubmit = (data) => {
    if (editingCustomer) {
      editMut.mutate({ id: editingCustomer._id, data });
    } else {
      addMut.mutate(data);
    }
  };

  const closeModal = () => { setShowAddModal(false); setEditingCustomer(null); reset(); };

  return (
    <>
      <Topbar
        title="مشتریان"
        subtitle={`${data?.total ?? 0} مشتری`}
        actions={
          <button className="btn btn-primary btn-sm" onClick={() => setShowAddModal(true)}>
            + مشتری جدید
          </button>
        }
      />
      <div className="page-body animate-in">
        <div className="card" style={{ marginBottom: 14, padding: '10px 14px' }}>
          <input
            className="input"
            placeholder="جستجوی نام یا شماره..."
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(1); }}
          />
        </div>

        <div className="card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>نام</th>
                  <th>شماره</th>
                  <th>ایمیل</th>
                  <th>وضعیت</th>
                  <th>تاریخ عضویت</th>
                  <th>اقدام</th>
                </tr>
              </thead>
              <tbody>
                {isLoading
                  ? Array(8).fill(0).map((_,i) => (
                    <tr key={i}>{Array(6).fill(0).map((_,j) => <td key={j}><div className="skeleton" style={{height:14}}/></td>)}</tr>
                  ))
                  : data?.users?.map(user => (
                    <tr key={user._id}>
                      <td>
                        <div style={{display:'flex',alignItems:'center',gap:8}}>
                          <div style={{width:28,height:28,borderRadius:'50%',background:'var(--brand-dim)',color:'var(--brand)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'.72rem',fontWeight:700,flexShrink:0}}>
                            {user.name?.slice(0,1) || '?'}
                          </div>
                          <span style={{fontSize:'.85rem'}}>{user.name || <span className="text-dim">بدون نام</span>}</span>
                        </div>
                      </td>
                      <td><span className="mono" style={{fontSize:'.78rem'}}>{user.phone}</span></td>
                      <td style={{fontSize:'.78rem',color:'var(--t2)'}}>{user.email || '—'}</td>
                      <td>
                        <span className={`badge ${user.approvalStatus === 'approved' ? 'b-green' : user.approvalStatus === 'rejected' ? 'b-red' : 'b-amber'}`}>
                          {user.approvalStatus === 'approved' ? 'تایید' : user.approvalStatus === 'rejected' ? 'رد' : 'در انتظار'}
                        </span>
                      </td>
                      <td style={{fontSize:'.75rem',color:'var(--t2)'}}>{new Date(user.createdAt).toLocaleDateString('fa-IR')}</td>
                      <td>
                        <div style={{display:'flex',gap:5}}>
                          <button className="btn btn-ghost btn-sm" onClick={() => openEdit(user)}>✏️</button>
                          {user.approvalStatus !== 'approved' && (
                            <button className="btn btn-ghost btn-sm" style={{color:'var(--green)'}} onClick={() => approveMut.mutate({ id: user._id, action: 'approve' })}>✅</button>
                          )}
                          {user.approvalStatus !== 'rejected' && (
                            <button className="btn btn-danger btn-sm" onClick={() => approveMut.mutate({ id: user._id, action: 'reject' })}>🚫</button>
                          )}
                          <button className="btn btn-danger btn-sm" onClick={() => window.confirm('حذف شود؟') && deleteMut.mutate(user._id)}>🗑️</button>
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>

          {data?.total > 20 && (
            <div className="pagination">
              <button className="btn btn-ghost btn-sm" disabled={page===1} onClick={() => setPage(p=>p-1)}>← قبلی</button>
              <span className="text-sm text-muted">صفحه {page}</span>
              <button className="btn btn-ghost btn-sm" onClick={() => setPage(p=>p+1)}>بعدی →</button>
            </div>
          )}
        </div>

        {/* Modal افزودن/ویرایش */}
        {(showAddModal || editingCustomer) && (
          <div className="modal-overlay" onClick={closeModal}>
            <div className="modal" onClick={e => e.stopPropagation()}>
              <div className="modal-header">
                <h3>{editingCustomer ? 'ویرایش مشتری' : '+ مشتری جدید'}</h3>
                <button className="btn btn-icon btn-ghost" onClick={closeModal}>✕</button>
              </div>
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="modal-body">
                  <div className="form-group">
                    <label className="label">نام و نام خانوادگی <span style={{color:'var(--red)'}}>*</span></label>
                    <input className="input" {...register('name', { required: 'نام اجباری است' })} placeholder="علی رضایی" />
                    {errors.name && <div className="text-xs text-red" style={{marginTop:4}}>{errors.name.message}</div>}
                  </div>
                  <div className="form-group">
                    <label className="label">شماره موبایل <span style={{color:'var(--red)'}}>*</span></label>
                    <input className="input" {...register('phone', { required: 'شماره اجباری است', pattern: { value: /^09\d{9}$/, message: 'شماره نامعتبر' } })} placeholder="09..." dir="ltr" disabled={!!editingCustomer} />
                    {errors.phone && <div className="text-xs text-red" style={{marginTop:4}}>{errors.phone.message}</div>}
                  </div>
                  <div className="form-group">
                    <label className="label">ایمیل (اختیاری)</label>
                    <input className="input" {...register('email')} placeholder="email@example.com" dir="ltr" />
                  </div>
                  {!editingCustomer && (
                    <div className="form-group">
                      <label className="label">وضعیت تایید</label>
                      <select className="select" {...register('approvalStatus')}>
                        <option value="approved">تایید شده</option>
                        <option value="pending">در انتظار</option>
                      </select>
                    </div>
                  )}
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-ghost" onClick={closeModal}>لغو</button>
                  <button type="submit" className="btn btn-primary" disabled={addMut.isPending || editMut.isPending}>
                    {addMut.isPending || editMut.isPending ? 'در حال ذخیره...' : 'ذخیره'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
