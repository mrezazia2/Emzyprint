import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import Topbar from '../../components/layout/Topbar';
import api from '../../services/api';
import './NewOrder.css';

const RESIN_COLORS = {
  wax:     '#3B82F6',
  dark:    '#374151',
  yellow:  '#EAB308',
  vintage: '#22C55E',
};

export default function NewOrderPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [orderId, setOrderId] = useState(null);
  const [customFieldValues, setCustomFieldValues] = useState({});
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState({});

  const { register, handleSubmit, watch, formState: { errors } } = useForm({
    defaultValues: { material:'Resin', quality:'standard', quantity:1 }
  });

  // لیست مشتریان برای انتخاب
  const { data: customersData } = useQuery({
    queryKey: ['customers-list'],
    queryFn: () => api.get('/admin/users', { params: { role:'customer', limit:100 } }).then(r => r.data),
  });

  // فیلدهای سفارشی
  const { data: customFields } = useQuery({
    queryKey: ['custom-fields'],
    queryFn: () => api.get('/admin/custom-fields').then(r => r.data.fields),
  });

  // کارمندان برای تخصیص
  const { data: employees } = useQuery({
    queryKey: ['employees-list'],
    queryFn: () => api.get('/employees').then(r => r.data.employees),
  });

  // اعتبارسنجی فیلدهای اجباری
  const validateCustomFields = () => {
    const required = customFields?.filter(f => f.required && f.isActive) || [];
    const missing = required.filter(f => !customFieldValues[f.key] && customFieldValues[f.key] !== 0);
    if (missing.length > 0) {
      toast.error(`فیلدهای اجباری: ${missing.map(f => f.label.fa).join('، ')}`);
      return false;
    }
    return true;
  };

  // ثبت سفارش
  const createMut = useMutation({
    mutationFn: (data) => api.post('/orders', {
      customer: data.customerId,
      printSettings: {
        material: data.material,
        quality:  data.quality,
        quantity: parseInt(data.quantity),
        notes:    data.notes,
      },
      customFields: customFieldValues,
      assignedEmployee: data.employeeId || undefined,
    }),
    onSuccess: (res) => {
      setOrderId(res.data.order._id);
      toast.success('سفارش ثبت شد');
      setStep(2);
    },
    onError: err => toast.error(err.response?.data?.error || 'خطا در ثبت سفارش'),
  });

  const onSubmit = (data) => {
    if (!validateCustomFields()) return;
    createMut.mutate(data);
  };

  // آپلود فایل
  const handleFileChange = (e) => {
    const selected = Array.from(e.target.files);
    setFiles(prev => [...prev, ...selected]);
  };

  const uploadFiles = async () => {
    if (!orderId || files.length === 0) { navigate('/orders'); return; }
    setUploading(true);
    for (const file of files) {
      const formData = new FormData();
      formData.append('files', file);
      try {
        await api.post(`/files/upload/${orderId}`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
          onUploadProgress: (e) => {
            setUploadProgress(p => ({ ...p, [file.name]: Math.round((e.loaded*100)/e.total) }));
          },
        });
        setUploadProgress(p => ({ ...p, [file.name]: 100 }));
      } catch {
        toast.error(`خطا در آپلود ${file.name}`);
      }
    }
    setUploading(false);
    toast.success('آپلود کامل شد');
    navigate(`/orders`);
  };

  const renderCustomField = (field) => {
    const val = customFieldValues[field.key];
    const set = (v) => setCustomFieldValues(prev => ({ ...prev, [field.key]: v }));

    switch (field.type) {
      case 'select':
        return (
          <div key={field._id} className="form-group">
            <label className="label">
              {field.label.fa}
              {field.required && <span style={{color:'var(--red)',marginRight:4}}>*</span>}
            </label>
            {field.key === 'resin_type' ? (
              <div className="resin-grid">
                {field.options.map(opt => (
                  <div
                    key={opt.value}
                    className={`resin-opt${val === opt.value ? ' active' : ''}`}
                    style={{ '--rc': opt.color || '#534AB7' }}
                    onClick={() => set(opt.value)}
                  >
                    <div className="resin-dot" style={{ background: opt.color || '#534AB7' }} />
                    <div className="resin-name">{opt.label.fa}</div>
                    {val === opt.value && <div className="resin-check">✓</div>}
                  </div>
                ))}
              </div>
            ) : (
              <select className="select" value={val||''} onChange={e => set(e.target.value)}>
                <option value="">انتخاب کنید</option>
                {field.options.map(opt => (
                  <option key={opt.value} value={opt.value}>{opt.label.fa}</option>
                ))}
              </select>
            )}
            {field.helpText?.fa && <div className="text-xs text-dim" style={{marginTop:4}}>{field.helpText.fa}</div>}
          </div>
        );

      case 'text':
        return (
          <div key={field._id} className="form-group">
            <label className="label">{field.label.fa}{field.required && <span style={{color:'var(--red)',marginRight:4}}>*</span>}</label>
            <input className="input" value={val||''} onChange={e=>set(e.target.value)} placeholder={field.placeholder?.fa||''} />
          </div>
        );

      case 'number':
        return (
          <div key={field._id} className="form-group">
            <label className="label">{field.label.fa}{field.required && <span style={{color:'var(--red)',marginRight:4}}>*</span>}</label>
            <input className="input" type="number" value={val||''} onChange={e=>set(e.target.value)} placeholder={field.placeholder?.fa||''} />
          </div>
        );

      case 'textarea':
        return (
          <div key={field._id} className="form-group">
            <label className="label">{field.label.fa}{field.required && <span style={{color:'var(--red)',marginRight:4}}>*</span>}</label>
            <textarea className="textarea" rows={3} value={val||''} onChange={e=>set(e.target.value)} placeholder={field.placeholder?.fa||''} />
          </div>
        );

      case 'boolean':
        return (
          <div key={field._id} className="form-group">
            <label className="toggle-wrap" style={{cursor:'pointer'}}>
              <div className={`toggle ${val ? 'on' : ''}`} onClick={() => set(!val)} />
              <span className="text-sm">{field.label.fa}</span>
            </label>
          </div>
        );

      default: return null;
    }
  };

  return (
    <>
      <Topbar
        title="ثبت سفارش جدید"
        subtitle={`مرحله ${step} از ۲`}
        actions={
          <button className="btn btn-ghost btn-sm" onClick={() => navigate('/orders')}>
            انصراف
          </button>
        }
      />
      <div className="page-body animate-in">

        {/* Step indicator */}
        <div className="step-bar">
          <div className={`step-item ${step >= 1 ? 'active' : ''}`}>
            <div className="step-circle">۱</div>
            <div className="step-label">اطلاعات سفارش</div>
          </div>
          <div className={`step-line ${step >= 2 ? 'done' : ''}`} />
          <div className={`step-item ${step >= 2 ? 'active' : ''}`}>
            <div className="step-circle">۲</div>
            <div className="step-label">آپلود فایل</div>
          </div>
        </div>

        {/* ── STEP 1 ── */}
        {step === 1 && (
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="order-grid">

              {/* مشتری */}
              <div className="card">
                <h4 style={{marginBottom:14}}>👤 اطلاعات مشتری</h4>
                <div className="form-group">
                  <label className="label">انتخاب مشتری <span style={{color:'var(--red)'}}>*</span></label>
                  <select className="select" {...register('customerId', {required:true})}>
                    <option value="">مشتری را انتخاب کنید</option>
                    {customersData?.users?.map(u => (
                      <option key={u._id} value={u._id}>{u.name || u.phone} — {u.phone}</option>
                    ))}
                  </select>
                  {errors.customerId && <div className="text-xs text-red" style={{marginTop:4}}>انتخاب مشتری اجباری است</div>}
                </div>
                <div className="form-group">
                  <label className="label">تخصیص به کارمند</label>
                  <select className="select" {...register('employeeId')}>
                    <option value="">تخصیص نشده</option>
                    {employees?.map(e => (
                      <option key={e._id} value={e._id}>{e.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* تنظیمات چاپ */}
              <div className="card">
                <h4 style={{marginBottom:14}}>🖨️ تنظیمات چاپ</h4>
                <div className="grid-2">
                  <div className="form-group">
                    <label className="label">کیفیت</label>
                    <select className="select" {...register('quality')}>
                      <option value="draft">سریع</option>
                      <option value="standard">استاندارد</option>
                      <option value="high">دقیق</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="label">تعداد</label>
                    <input className="input" type="number" min="1" {...register('quantity')} />
                  </div>
                </div>
                <div className="form-group">
                  <label className="label">توضیحات</label>
                  <textarea className="textarea" rows={2} placeholder="توضیحات خاص..." {...register('notes')} />
                </div>
              </div>

              {/* فیلدهای سفارشی */}
              <div className="card">
                <h4 style={{marginBottom:14}}>🧩 مشخصات سفارش</h4>
                {customFields
                  ?.filter(f => f.isActive)
                  .sort((a,b) => a.order - b.order)
                  .map(renderCustomField)}
              </div>

            </div>

            <div style={{display:'flex',justifyContent:'flex-end',marginTop:16}}>
              <button type="submit" className="btn btn-primary" style={{minWidth:160}} disabled={createMut.isPending}>
                {createMut.isPending ? 'در حال ثبت...' : 'ثبت سفارش و آپلود فایل →'}
              </button>
            </div>
          </form>
        )}

        {/* ── STEP 2 ── */}
        {step === 2 && (
          <div className="card" style={{maxWidth:600}}>
            <h4 style={{marginBottom:16}}>📁 آپلود فایل‌های ۳D</h4>

            <div className="upload-zone" onClick={() => document.getElementById('adminFileInput').click()}>
              <div style={{fontSize:'2rem',marginBottom:8}}>☁️</div>
              <div style={{fontWeight:600,color:'var(--brand)',marginBottom:4}}>فایل را انتخاب کنید</div>
              <div className="text-xs text-dim">STL · OBJ · 3MF · GCODE · STEP · ZIP</div>
              <input
                id="adminFileInput"
                type="file" multiple
                accept=".stl,.obj,.3mf,.gcode,.step,.stp,.zip"
                style={{display:'none'}}
                onChange={handleFileChange}
              />
            </div>

            {files.length > 0 && (
              <div style={{marginTop:14,display:'flex',flexDirection:'column',gap:8}}>
                {files.map(f => (
                  <div key={f.name} className="file-upload-row">
                    <div className="file-ext">.{f.name.split('.').pop().toUpperCase()}</div>
                    <div style={{flex:1}}>
                      <div style={{fontSize:'.82rem',fontWeight:500}}>{f.name}</div>
                      <div style={{fontSize:'.7rem',color:'var(--t2)'}}>
                        {(f.size/1024/1024).toFixed(1)} MB
                      </div>
                      {uploadProgress[f.name] !== undefined && (
                        <div style={{height:4,background:'var(--surface)',borderRadius:99,marginTop:4,overflow:'hidden'}}>
                          <div style={{height:'100%',borderRadius:99,background:uploadProgress[f.name]===100?'var(--green)':'var(--brand)',width:`${uploadProgress[f.name]}%`,transition:'width .3s'}}/>
                        </div>
                      )}
                    </div>
                    <span style={{fontSize:'.72rem',fontWeight:600,color:uploadProgress[f.name]===100?'var(--green)':'var(--t2)'}}>
                      {uploadProgress[f.name] !== undefined ? `${uploadProgress[f.name]}٪` : '—'}
                    </span>
                  </div>
                ))}
              </div>
            )}

            <div style={{display:'flex',gap:10,marginTop:20}}>
              <button
                className="btn btn-ghost"
                onClick={() => navigate('/orders')}
                disabled={uploading}
              >
                بدون فایل ادامه بده
              </button>
              <button
                className="btn btn-primary"
                style={{flex:1}}
                onClick={uploadFiles}
                disabled={uploading || files.length === 0}
              >
                {uploading ? 'در حال آپلود...' : `آپلود ${files.length} فایل`}
              </button>
            </div>
          </div>
        )}

      </div>
    </>
  );
}
