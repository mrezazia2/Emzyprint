﻿import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import Topbar from '../../components/layout/Topbar';
import api from '../../services/api';
import './OrderStatuses.css';

const TEMPLATE_VARS = [
  { var: '{orderNumber}',  desc: 'ط´ظ…ط§ط±ظ‡ ط³ظپط§ط±ط´' },
  { var: '{customerName}', desc: 'ظ†ط§ظ… ظ…ط´طھط±غŒ' },
  { var: '{statusLabel}',  desc: 'ظ†ط§ظ… ظˆط¶ط¹غŒطھ' },
  { var: '{note}',         desc: 'غŒط§ط¯ط¯ط§ط´طھ' },
];

export default function OrderStatusesPage() {
  const qc = useQueryClient();
  const [editing, setEditing] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['order-statuses'],
    queryFn: () => api.get('/admin/statuses').then(r => r.data.statuses),
  });

  const { register, handleSubmit, reset, watch, setValue, formState: { errors } } = useForm();

  const saveMut = useMutation({
    mutationFn: (d) => editing
      ? api.put(`/admin/statuses/${editing.key}`, d)
      : api.post('/admin/statuses', d),
    onSuccess: () => {
      qc.invalidateQueries(['order-statuses']);
      toast.success(editing ? 'ظˆط¶ط¹غŒطھ ط¨ط±ظˆط²ط±ط³ط§ظ†غŒ ط´ط¯' : 'ظˆط¶ط¹غŒطھ ط§ط¶ط§ظپظ‡ ط´ط¯');
      closeModal();
    },
    onError: err => toast.error(err.response?.data?.error || 'ط®ط·ط§'),
  });

  const deleteMut = useMutation({
    mutationFn: (key) => api.delete(`/admin/statuses/${key}`),
    onSuccess: () => { qc.invalidateQueries(['order-statuses']); toast.success('ط­ط°ظپ ط´ط¯'); },
    onError: err => toast.error(err.response?.data?.error || 'ظ†ظ…غŒâ€Œطھظˆط§ظ† ط­ط°ظپ ع©ط±ط¯'),
  });

  const openEdit = (status) => {
    setEditing(status);
    reset({
      'label.fa':          status.label.fa,
      'label.en':          status.label.en,
      color:               status.color,
      bgColor:             status.bgColor,
      icon:                status.icon,
      order:               status.order,
      notifSms:            status.notifSms,
      notifEmail:          status.notifEmail,
      'smsTemplate.fa':    status.smsTemplate?.fa || '',
      'smsTemplate.en':    status.smsTemplate?.en || '',
      canCancel:           status.canCancel,
      isFinal:             status.isFinal,
      isActive:            status.isActive,
    });
    setShowModal(true);
  };

  const openNew = () => {
    setEditing(null);
    reset({ notifSms: true, isActive: true, order: (data?.length || 0) + 1 });
    setShowModal(true);
  };

  const closeModal = () => { setShowModal(false); setEditing(null); reset({}); };

  const insertVar = (field, varText) => {
    const current = watch(field) || '';
    setValue(field, current + varText);
  };

  return (
    <>
      <Topbar
        title="ظˆط¶ط¹غŒطھâ€Œظ‡ط§غŒ ط³ظپط§ط±ط´"
        subtitle="ظ…ط¯غŒط±غŒطھ ظˆ ط³ظپط§ط±ط´غŒâ€Œط³ط§ط²غŒ ظˆط¶ط¹غŒطھâ€Œظ‡ط§ + ظ‚ط§ظ„ط¨ ظ¾غŒط§ظ…ع©"
        actions={<button className="btn btn-primary btn-sm" onClick={openNew}>+ ظˆط¶ط¹غŒطھ ط¬ط¯غŒط¯</button>}
      />
      <div className="page-body animate-in">
        <div className="card">
          <p className="text-sm text-muted" style={{ marginBottom: 14 }}>
            طھط±طھغŒط¨ ظˆط¶ط¹غŒطھâ€Œظ‡ط§ ط±ط§ ط¨ط§ ط¹ط¯ط¯ آ«طھط±طھغŒط¨آ» طھظ†ط¸غŒظ… ع©ظ†غŒط¯. ظˆط¶ط¹غŒطھâ€Œظ‡ط§غŒغŒ ع©ظ‡ ط³ظپط§ط±ط´ ط¯ط§ط±ظ†ط¯ ظ‚ط§ط¨ظ„ ط­ط°ظپ ظ†غŒط³طھظ†ط¯.
          </p>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>طھط±طھغŒط¨</th>
                  <th>ظˆط¶ط¹غŒطھ</th>
                  <th>ع©ظ„غŒط¯ ط³غŒط³طھظ…غŒ</th>
                  <th>ظ¾غŒط§ظ…ع©</th>
                  <th>ظ‚ط§ظ„ط¨ ظ¾غŒط§ظ…ع© FA</th>
                  <th>ظˆغŒعکع¯غŒ</th>
                  <th>ط§ظ‚ط¯ط§ظ…</th>
                </tr>
              </thead>
              <tbody>
                {isLoading
                  ? Array(6).fill(0).map((_,i) => (
                    <tr key={i}>{Array(7).fill(0).map((_,j) => <td key={j}><div className="skeleton" style={{height:14}}/></td>)}</tr>
                  ))
                  : data?.map(s => (
                    <tr key={s.key}>
                      <td style={{width:60}}><span className="text-dim mono">{s.order}</span></td>
                      <td>
                        <div style={{display:'flex',alignItems:'center',gap:8}}>
                          <span style={{fontSize:16}}>{s.icon}</span>
                          <span className="badge" style={{background:s.bgColor,color:s.color}}>{s.label.fa}</span>
                        </div>
                        <div className="text-xs text-dim" style={{marginTop:2}}>{s.label.en}</div>
                      </td>
                      <td><code className="mono" style={{fontSize:'.72rem',color:'var(--brand)'}}>{s.key}</code></td>
                      <td>
                        <span className={`badge ${s.notifSms ? 'b-green' : 'b-gray'}`}>
                          {s.notifSms ? 'ًں“± ظپط¹ط§ظ„' : 'ط؛غŒط±ظپط¹ط§ظ„'}
                        </span>
                      </td>
                      <td>
                        <div className="text-xs text-muted template-preview">
                          {s.smsTemplate?.fa || <span className="text-dim">â€”</span>}
                        </div>
                      </td>
                      <td>
                        <div style={{display:'flex',gap:4,flexWrap:'wrap'}}>
                          {s.isDefault && <span className="badge b-brand">ظ¾غŒط´â€Œظپط±ط¶</span>}
                          {s.isFinal   && <span className="badge b-gray">ظ¾ط§غŒط§ظ†غŒ</span>}
                          {s.canCancel && <span className="badge b-amber">ظ‚ط§ط¨ظ„ ظ„ط؛ظˆ</span>}
                          {!s.isActive && <span className="badge b-red">ط؛غŒط±ظپط¹ط§ظ„</span>}
                        </div>
                      </td>
                      <td>
                        <div style={{display:'flex',gap:6}}>
                          <button className="btn btn-ghost btn-sm" onClick={() => openEdit(s)}>ظˆغŒط±ط§غŒط´</button>
                          {!s.isDefault && !s.isFinal && (
                            <button
                              className="btn btn-danger btn-sm"
                              onClick={() => window.confirm('ط­ط°ظپ ط´ظˆط¯طں') && deleteMut.mutate(s.key)}
                            >ط­ط°ظپ</button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal */}
        {showModal && (
          <div className="modal-overlay" onClick={closeModal}>
            <div className="modal modal-lg" onClick={e => e.stopPropagation()}>
              <div className="modal-header">
                <h3>{editing ? `ظˆغŒط±ط§غŒط´: ${editing.label?.fa}` : 'ظˆط¶ط¹غŒطھ ط¬ط¯غŒط¯'}</h3>
                <button className="btn btn-icon btn-ghost" onClick={closeModal}>âœ•</button>
              </div>
              <form onSubmit={handleSubmit(d => saveMut.mutate(d))}>
                <div className="modal-body">
                  <div className="grid-2">
                    <div>
                      <div className="form-group">
                        <label className="label">ظ†ط§ظ… ظپط§ط±ط³غŒ</label>
                        <input className="input" {...register('label.fa', {required:true})} placeholder="ظ…ط«ط§ظ„: ط¯ط± ط­ط§ظ„ ط¢ظ…ط§ط¯ظ‡â€Œط³ط§ط²غŒ" />
                      </div>
                      <div className="form-group">
                        <label className="label">ظ†ط§ظ… ط§ظ†ع¯ظ„غŒط³غŒ</label>
                        <input className="input" {...register('label.en', {required:true})} placeholder="e.g. Preparing" dir="ltr" />
                      </div>
                      <div className="grid-2">
                        <div className="form-group">
                          <label className="label">ط±ظ†ع¯ ظ…طھظ†</label>
                          <div style={{display:'flex',gap:6}}>
                            <input type="color" {...register('color')} style={{width:36,height:32,borderRadius:6,border:'1px solid var(--border)',cursor:'pointer',padding:2,background:'var(--ink3)'}} />
                            <input className="input" {...register('color')} dir="ltr" placeholder="#534AB7" />
                          </div>
                        </div>
                        <div className="form-group">
                          <label className="label">ط±ظ†ع¯ ظ¾ط³â€Œط²ظ…غŒظ†ظ‡</label>
                          <div style={{display:'flex',gap:6}}>
                            <input type="color" {...register('bgColor')} style={{width:36,height:32,borderRadius:6,border:'1px solid var(--border)',cursor:'pointer',padding:2,background:'var(--ink3)'}} />
                            <input className="input" {...register('bgColor')} dir="ltr" placeholder="#EEEDFE" />
                          </div>
                        </div>
                      </div>
                      <div className="grid-2">
                        <div className="form-group">
                          <label className="label">ط¢غŒع©ظˆظ† (ط§غŒظ…ظˆط¬غŒ)</label>
                          <input className="input" {...register('icon')} placeholder="ًں–¨ï¸ڈ" />
                        </div>
                        <div className="form-group">
                          <label className="label">طھط±طھغŒط¨ ظ†ظ…ط§غŒط´</label>
                          <input className="input" type="number" {...register('order')} />
                        </div>
                      </div>
                      {!editing && (
                        <div className="form-group">
                          <label className="label">ع©ظ„غŒط¯ ط³غŒط³طھظ…غŒ (ط§ظ†ع¯ظ„غŒط³غŒطŒ ط¨ط¯ظˆظ† ظپط§طµظ„ظ‡)</label>
                          <input className="input" {...register('key', {required:true})} placeholder="preparing" dir="ltr" />
                        </div>
                      )}
                      {/* ع¯ط²غŒظ†ظ‡â€Œظ‡ط§ */}
                      <div style={{display:'flex',flexDirection:'column',gap:8,marginTop:4}}>
                        {[
                          {name:'notifSms',   label:'ط§ط±ط³ط§ظ„ ظ¾غŒط§ظ…ع© ط¯ط± ط§غŒظ† ظˆط¶ط¹غŒطھ'},
                          {name:'notifEmail', label:'ط§ط±ط³ط§ظ„ ط§غŒظ…غŒظ„ ط¯ط± ط§غŒظ† ظˆط¶ط¹غŒطھ'},
                          {name:'canCancel',  label:'ظ‚ط§ط¨ظ„ ظ„ط؛ظˆ ط§ط² ط§غŒظ† ظˆط¶ط¹غŒطھ'},
                          {name:'isFinal',    label:'ظˆط¶ط¹غŒطھ ظ¾ط§غŒط§ظ†غŒ (ط¢ط®ط± ظ…ط³غŒط±)'},
                          {name:'isActive',   label:'ظپط¹ط§ظ„'},
                        ].map(opt => (
                          <label key={opt.name} style={{display:'flex',alignItems:'center',gap:8,cursor:'pointer',fontSize:'.82rem',color:'var(--t1)'}}>
                            <input type="checkbox" {...register(opt.name)} style={{accentColor:'var(--brand)',width:15,height:15}} />
                            {opt.label}
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* SMS Templates */}
                    <div>
                      <div className="sms-template-section">
                        <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:10}}>
                          <span style={{fontSize:18}}>ًں“±</span>
                          <strong style={{fontSize:'.88rem'}}>ظ‚ط§ظ„ط¨ ظ¾غŒط§ظ…ع©</strong>
                        </div>
                        <div className="template-vars">
                          <div className="text-xs text-muted" style={{marginBottom:6}}>ظ…طھط؛غŒط±ظ‡ط§غŒ ظ‚ط§ط¨ظ„ ط§ط³طھظپط§ط¯ظ‡:</div>
                          <div style={{display:'flex',flexWrap:'wrap',gap:5}}>
                            {TEMPLATE_VARS.map(v => (
                              <button
                                key={v.var} type="button"
                                className="var-chip"
                                onClick={() => insertVar('smsTemplate.fa', v.var)}
                                title={v.desc}
                              >
                                {v.var}
                              </button>
                            ))}
                          </div>
                        </div>
                        <div className="form-group" style={{marginTop:10}}>
                          <label className="label">ظ‚ط§ظ„ط¨ ظپط§ط±ط³غŒ</label>
                          <textarea
                            className="textarea"
                            rows={4}
                            {...register('smsTemplate.fa')}
                            placeholder="ط³ظپط§ط±ط´ {orderNumber} ظˆط§ط±ط¯ ظ…ط±ط­ظ„ظ‡ ط¬ط¯غŒط¯ ط´ط¯. {note}"
                          />
                          <div className="text-xs text-dim" style={{marginTop:4}}>
                            ظ¾غŒط´â€Œظ†ظ…ط§غŒط´: {(watch('smsTemplate.fa')||'').replace('{orderNumber}','PRT-001').replace('{customerName}','ط¹ظ„غŒ').replace('{statusLabel}', watch('label.fa')||'').replace('{note}','طھظˆط¶غŒط­')}
                          </div>
                        </div>
                        <div className="form-group">
                          <label className="label">ظ‚ط§ظ„ط¨ ط§ظ†ع¯ظ„غŒط³غŒ</label>
                          <textarea
                            className="textarea"
                            rows={3}
                            {...register('smsTemplate.en')}
                            placeholder="Order {orderNumber} status updated."
                            dir="ltr"
                          />
                        </div>

                        {/* SMS Provider */}
                        <div style={{background:'var(--ink3)',borderRadius:'var(--r-md)',padding:10,marginTop:8}}>
                          <div className="text-xs text-muted" style={{marginBottom:6}}>ط³ط§ظ…ط§ظ†ظ‡ ظ¾غŒط§ظ…ع© ظپط¹ط§ظ„:</div>
                          <div style={{display:'flex',gap:8}}>
                            {['kavenegar','melipayamak','ippanel'].map(p => (
                              <span key={p} className={`badge ${p === 'kavenegar' ? 'b-green' : 'b-gray'}`} style={{fontSize:'.7rem'}}>
                                {p}
                              </span>
                            ))}
                          </div>
                          <div className="text-xs text-dim" style={{marginTop:5}}>
                            ط¨ط±ط§غŒ طھط؛غŒغŒط± ط³ط±ظˆغŒط³: ظ…طھط؛غŒط± SMS_PROVIDER ط¯ط± .env
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-ghost" onClick={closeModal}>ظ„ط؛ظˆ</button>
                  <button type="submit" className="btn btn-primary" disabled={saveMut.isPending}>
                    {saveMut.isPending ? 'ط¯ط± ط­ط§ظ„ ط°ط®غŒط±ظ‡...' : 'ط°ط®غŒط±ظ‡'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
