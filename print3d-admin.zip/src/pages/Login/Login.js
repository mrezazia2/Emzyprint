import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import useAuthStore from '../../store/authStore';
import api from '../../services/api';
import './Login.css';

export default function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuthStore();
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState('phone');
  const [loading, setLoading] = useState(false);
  const [countdown, setCountdown] = useState(0);

  React.useEffect(() => {
    if (countdown > 0) {
      const t = setTimeout(() => setCountdown(c => c - 1), 1000);
      return () => clearTimeout(t);
    }
  }, [countdown]);

  const sendOTP = async () => {
    if (!/^09\d{9}$/.test(phone)) return toast.error('شماره موبایل نامعتبر است');
    setLoading(true);
    try {
      await api.post('/auth/send-otp', { phone });
      setStep('otp');
      setCountdown(120);
      toast.success('کد تایید ارسال شد');
    } catch (err) {
      toast.error(err.response?.data?.error || 'خطا در ارسال پیامک');
    } finally {
      setLoading(false);
    }
  };

  const verifyOTP = async () => {
    setLoading(true);
    try {
      const user = await login(phone, otp);
      toast.success(`خوش آمدید، ${user.name || 'مدیر'}`);
      navigate('/');
    } catch (err) {
      toast.error(err.message || err.response?.data?.error || 'خطا');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-bg" />
      <div className="login-card">
        <div className="login-logo">
          <span>🖨️</span>
        </div>
        <h1 className="login-title">پرینت ۳D</h1>
        <p className="login-sub">ورود به پنل مدیریت</p>

        {step === 'phone' ? (
          <>
            <div className="form-group">
              <label className="label">شماره موبایل ادمین</label>
              <input
                className="input"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="09..."
                dir="ltr"
                onKeyDown={e => e.key === 'Enter' && sendOTP()}
              />
            </div>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={sendOTP} disabled={loading}>
              {loading ? 'در حال ارسال...' : 'ارسال کد تایید'}
            </button>
          </>
        ) : (
          <>
            <div className="otp-info">کد ارسال شده به {phone}</div>
            <div className="form-group">
              <label className="label">کد ۶ رقمی</label>
              <input
                className="input"
                value={otp}
                onChange={e => setOtp(e.target.value)}
                placeholder="_ _ _ _ _ _"
                dir="ltr"
                maxLength={6}
                style={{ textAlign: 'center', letterSpacing: '0.3em', fontSize: '1.2rem' }}
                autoFocus
                onKeyDown={e => e.key === 'Enter' && verifyOTP()}
              />
            </div>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={verifyOTP} disabled={loading}>
              {loading ? 'در حال بررسی...' : 'ورود'}
            </button>
            <button
              className="btn btn-ghost" style={{ width: '100%', marginTop: 8 }}
              onClick={countdown === 0 ? sendOTP : undefined}
              disabled={countdown > 0}
            >
              {countdown > 0 ? `ارسال مجدد (${countdown}s)` : 'ارسال مجدد کد'}
            </button>
            <button className="btn btn-ghost" style={{ width: '100%', marginTop: 4 }} onClick={() => setStep('phone')}>
              تغییر شماره
            </button>
          </>
        )}
      </div>
    </div>
  );
}
