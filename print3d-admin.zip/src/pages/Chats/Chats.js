﻿import React, { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { io } from 'socket.io-client';
import { useLocation } from 'react-router-dom';
import toast from 'react-hot-toast';
import Topbar from '../../components/layout/Topbar';
import api from '../../services/api';
import useAuthStore from '../../store/authStore';
import './Chats.css';

const SOCKET_URL = 'http://emzyprint.ir';

export default function ChatsPage() {
  const { token, user } = useAuthStore();
  const location = useLocation();
  const [activeChat, setActiveChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [isTyping, setIsTyping] = useState({});
  const [recording, setRecording] = useState(false);
  const socketRef = useRef(null);
  const activeChatRef = useRef(null);
  const messagesEndRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const typingTimeoutRef = useRef(null);
  const fileInputRef = useRef(null);

  const { data: chatsData, refetch } = useQuery({
    queryKey: ['admin-chats'],
    queryFn: () => api.get('/chat').then(r => r.data.chats),
    refetchInterval: 30000,
  });

  useEffect(() => {
    socketRef.current = io(SOCKET_URL, {
      auth: { token },
      transports: ['websocket', 'polling'],
    });

    socketRef.current.on('connect', () => {
      console.log('Socket connected!');
      chatsData?.forEach(c => {
        socketRef.current.emit('chat:join', { chatId: c._id });
      });
    });

    socketRef.current.on('message:new', ({ chatId, message }) => {
      console.log('message:new received', chatId);
      setMessages(prev => {
        if (activeChatRef.current?._id === chatId) {
          return [...prev, message];
        }
        return prev;
      });
      refetch();
    });

    socketRef.current.on('connect_error', (e) => console.log('Socket error:', e.message));

    return () => socketRef.current?.disconnect();
  }, [token]);

  useEffect(() => {
    if (!location.state?.chatId || !chatsData) return;
    const chat = chatsData.find(c => c._id === location.state.chatId);
    if (chat) {
      activeChatRef.current = chat;
      setActiveChat(chat);
      api.get(`/chat/${chat._id}/messages`).then(({ data }) => {
        setMessages(data.messages || []);
        setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
        socketRef.current?.emit('chat:join', { chatId: chat._id });
        socketRef.current?.emit('message:read', { chatId: chat._id });
      }).catch(() => {});
    }
  }, [location.state?.chatId, chatsData]); // eslint-disable-line

  const loadMessages = async (chat) => {
    activeChatRef.current = chat;
    setActiveChat(chat);
    setMessages([]);
    try {
      const { data } = await api.get(`/chat/${chat._id}/messages`);
      setMessages(data.messages || []);
      setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior:'smooth' }), 100);
      socketRef.current?.emit('chat:join', { chatId: chat._id });
      socketRef.current?.emit('message:read', { chatId: chat._id });
    } catch {}
  };

  const sendMessage = () => {
    if (!text.trim() || !activeChat) return;
    socketRef.current?.emit('message:send', { chatId: activeChat._id, type: 'text', content: text.trim() });
    setText('');
  };

  const handleTyping = (val) => {
    setText(val);
    if (!activeChat) return;
    socketRef.current?.emit('typing:start', { chatId: activeChat._id });
    clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      socketRef.current?.emit('typing:stop', { chatId: activeChat._id });
    }, 1500);
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file || !activeChat) return;
    const formData = new FormData();
    formData.append('file', file);
    try {
      await api.post(`/chat/${activeChat._id}/upload`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      toast.success('فایل ارسال شد');
    } catch { toast.error('خطا در ارسال فایل'); }
    e.target.value = '';
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      audioChunksRef.current = [];
      mediaRecorderRef.current.ondataavailable = e => audioChunksRef.current.push(e.data);
      mediaRecorderRef.current.onstop = async () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const formData = new FormData();
        formData.append('file', blob, 'voice.webm');
        try {
          await api.post(`/chat/${activeChat._id}/upload`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
        } catch { toast.error('خطا در ارسال صدا'); }
        stream.getTracks().forEach(t => t.stop());
      };
      mediaRecorderRef.current.start();
      setRecording(true);
    } catch { toast.error('دسترسی به میکروفون رد شد'); }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setRecording(false);
  };

  const typingUsers = Object.values(isTyping).filter(Boolean);

  return (
    <>
      <Topbar title="چتهای پشتیبانی" subtitle={`${chatsData?.length || 0} مکالمه`} />
      <div className="page-body animate-in chats-layout">
        <div className="chat-list">
          <div className="chat-list-header">
            <input className="input" placeholder="جستجو..." style={{fontSize:'.8rem'}} />
          </div>
          <div style={{overflowY:'auto',flex:1}}>
            {chatsData?.map(chat => {
              const other = chat.participants?.find(p => p._id !== user?._id);
              const unread = chat.unreadCounts?.[user?._id] || 0;
              const isActive = activeChat?._id === chat._id;
              return (
                <div key={chat._id} className={`chat-item${isActive?' active':''}`} onClick={() => loadMessages(chat)}>
                  <div className="chat-avatar">
                    {other?.name?.slice(0,2) || '??'}
                    {other?.employeeProfile?.isOnline && <span className="online-dot"/>}
                  </div>
                  <div className="chat-info">
                    <div className="chat-name">{other?.name || other?.phone || 'کاربر'}</div>
                    {chat.order && <div className="chat-order mono">{chat.order.orderNumber}</div>}
                    <div className="chat-last">{chat.lastMessage?.content || 'بدون پیام'}</div>
                  </div>
                  {unread > 0 && <span className="chat-unread">{unread}</span>}
                </div>
              );
            })}
          </div>
        </div>

        {activeChat ? (
          <div className="chat-window">
            <div className="chat-window-header">
              <div className="chat-avatar">
                {activeChat.participants?.find(p=>p._id!==user?._id)?.name?.slice(0,2) || '??'}
              </div>
              <div>
                <div style={{fontWeight:600,fontSize:'.9rem'}}>
                  {activeChat.participants?.find(p=>p._id!==user?._id)?.name || 'کاربر'}
                </div>
                {activeChat.order && (
                  <div className="mono" style={{fontSize:'.72rem',color:'var(--brand)'}}>
                    {activeChat.order.orderNumber}
                  </div>
                )}
              </div>
              <span className={`badge ${activeChat.type==='order_support'?'b-brand':'b-blue'}`} style={{marginRight:'auto',fontSize:'.68rem'}}>
                {activeChat.type==='order_support'?'پشتیبانی سفارش':'داخلی'}
              </span>
            </div>

            <div className="chat-messages">
              {messages.map((msg, i) => {
                const isMine = msg.sender?._id === user?._id || msg.sender === user?._id;
                return (
                  <div key={msg._id||i} className={`msg-row ${isMine?'mine':'theirs'}`}>
                    {!isMine && <div className="msg-avatar">{msg.sender?.name?.slice(0,1)||'?'}</div>}
                    <div className="msg-bubble-wrap">
                      {!isMine && <div className="msg-sender-name">{msg.sender?.name}</div>}
                      <div className={`msg-bubble ${isMine?'mine':'theirs'}`}>
                        {msg.type==='text' && <span>{msg.content}</span>}
                        {msg.type==='image' && <img src={msg.fileUrl} alt="تصویر" style={{maxWidth:200,borderRadius:8,display:'block'}}/>}
                        {msg.type==='voice' && <audio controls src={msg.fileUrl} style={{height:32,maxWidth:200}}/>}
                        {msg.type==='file' && <a href={msg.fileUrl} download={msg.fileName} style={{color:'inherit',display:'flex',alignItems:'center',gap:6}}><span></span>{msg.fileName}</a>}
                        <div className="msg-time">{new Date(msg.createdAt).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'})}</div>
                      </div>
                    </div>
                  </div>
                );
              })}
              {typingUsers.length > 0 && (
                <div style={{fontSize:'.72rem',color:'var(--t3)',padding:'4px 12px'}}>{typingUsers.join(' ')} در حال تایپ...</div>
              )}
              <div ref={messagesEndRef}/>
            </div>

            <div className="chat-input-bar">
              <button className="btn btn-icon btn-ghost" onClick={() => fileInputRef.current?.click()} title="ارسال فایل"></button>
              <input ref={fileInputRef} type="file" accept="image/*,audio/*,.pdf,.stl,.obj,.3mf,.zip" style={{display:'none'}} onChange={handleFileUpload}/>
              <button className={`btn btn-icon ${recording?'btn-danger':'btn-ghost'}`} onMouseDown={startRecording} onMouseUp={stopRecording} onTouchStart={startRecording} onTouchEnd={stopRecording} title="نگه دار برای ضبط">
                {recording?'':''}
              </button>
              <input className="input" style={{flex:1,fontSize:'.85rem'}} placeholder="پیام بنویسید..." value={text} onChange={e=>handleTyping(e.target.value)} onKeyDown={e=>e.key==='Enter'&&!e.shiftKey&&sendMessage()}/>
              <button className="btn btn-primary btn-sm" onClick={sendMessage} disabled={!text.trim()}>ارسال</button>
            </div>
          </div>
        ) : (
          <div className="chat-empty">
            <div style={{fontSize:'3rem',marginBottom:12}}></div>
            <div style={{fontWeight:600,marginBottom:6}}>یک چت انتخاب کنید</div>
            <div className="text-sm text-muted">از لیست سمت راست یک مکالمه را باز کنید</div>
          </div>
        )}
      </div>
    </>
  );
}