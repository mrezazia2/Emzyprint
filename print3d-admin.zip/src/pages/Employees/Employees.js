import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import Topbar from '../../components/layout/Topbar';
import api from '../../services/api';
import './Employees.css';

const ALL_PERMS = [
  { id: 'orders.view',     label: 'مشاهده سفارشات' },
  { id: 'orders.edit',     label: 'ویرایش وضعیت' },
  { id: 'orders.assign',   label: 'تخصیص سفارش' },
  { id: 'files.approve',   label: 'تایید/رد فایل' },
  { id: 'chat.support',    label: 'چت پشتیبانی' },
  { id: 'employees.manage',label: 'مدیریت کارمندان' },
  { id: 'settings.edit',   label: 'ویرایش تنظیمات' },
  { id: 'reports.view',    label: 'گزارشات' },
];

export default function EmployeesPage() {
  const qc = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [editingEmp, setEditingEmp] = useState(null);
  const [selectedPerms, setSelectedPerms] = useState([]);

  const { data: employees, isLoading } = useQuery({
    queryKey: ['employees'],
    queryFn: () => api.get('/employees').then(r => r.data.employees),
  });

  const { register, handleSubmit, reset, formState: { errors } } = useForm();

  const createMutation = useMutation({
    mutationFn: (data) => api.post('/employees', { ...data, permissions: selectedPerms }),
    onSuccess: () => {
      qc.invalidateQueries(['employees']);
      toast.success('کارمند اضافه شد');
      setShowModal(false); reset(); setSelectedPerms([]);
    },
    onError: (err) => toast.error(err.response?.data?.error || 'خطا'),
  });

  const updatePermsMutation = useMutation({
    mutationFn: ({ id, permissions, department }) =>
      api.patch(`/employees/${id}/permissions`, { permissions, department }),
    onSuccess: () => { qc.invalidateQueries(['employees']); toast.success('دسترسی‌ها بروزرسانی شد'); setEditingEmp(null); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => api.delete(`/employees/${id}`),
    onSuccess: () => { qc.invalidateQueries(['employees']); toast.success('کارمند حذف شد'); },
  });

  const openEdit = (emp) => {
    setEditingEmp(emp);
    setSelectedPerms(emp.employeeProfile?.permissions || []);
  };

  const togglePerm = (id) => setSelectedPerms(prev =>
    prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]
  );

  return (
    <>
      <Topbar
        title="مدیریت کارمندان"
        subtitle={`${employees?.length ?? 0} نفر`}
        actions={
          <button className="btn btn-primary btn-sm" onClick={() => setShowModal(true)}>
            + کارمند جدید
          </button>
        }
      />

      <div className="page-body animate-in">

        {/* ── Employee Cards Grid ────────────────────────────────────────── */}
        <div className="emp-grid">
          {isLoading
            ? Array(6).fill(0).map((_, i) => (
              <div key={i} className="card emp-card-item">
                <div className="skeleton" style={{ height: 80 }} />
              </div>
            ))
            : employees?.map(emp => (
              <div key={emp._id} className="card emp-card-item">
                <div className="emp-header">
                  <div className="emp-av-lg">
                    {emp.name?.slice(0, 2)}
                    <span className={`status-dot ${emp.employeeProfile?.isOnline ? 'online' : 'offline'}`} />
                  </div>
                  <div className="emp-head-info">
                    <div className="emp-nm">{emp.name}</div>
                    <div className="emp-ph mono text-xs text-dim">{emp.phone}</div>
                    <div className="emp-dept text-xs text-muted">{emp.employeeProfile?.department || '—'}</div>
                  </div>
                </div>

                <div className="emp-perms">
                  {(emp.employeeProfile?.permissions || []).slice(0, 4).map(p => {
                    const perm = ALL_PERMS.find(x => x.id === p);
                    return perm ? (
                      <span key={p} className="badge badge-brand text-xs">{perm.label}</span>
                    ) : null;
                  })}
                  {(emp.employeeProfile?.permissions || []).length > 4 && (
                    <span className="badge badge-gray text-xs">
                      +{emp.employeeProfile.permissions.length - 4}
                    </span>
                  )}
                  {!(emp.employeeProfile?.permissions?.length) && (
                    <span className="text-xs text-dim">بدون دسترسی خاص</span>
                  )}
                </div>

                <div className="emp-stats-row">
                  <div className="emp-stat-item">
                    <span className="emp-stat-num">
                      {emp.employeeProfile?.assignedOrders?.length || 0}
                    </span>
                    <span className="text-xs text-dim">سفارش</span>
                  </div>
                  <div className="emp-stat-item">
                    <span className="emp-stat-num">
                      {emp.lastLogin
                        ? new Date(emp.lastLogin).toLocaleDateString('fa-IR', { month: 'short', day: 'numeric' })
                        : '—'}
                    </span>
                    <span className="text-xs text-dim">آخرین ورود</span>
                  </div>
                </div>

                <div className="emp-actions">
                  <button className="btn btn-ghost btn-sm" onClick={() => openEdit(emp)}>
                    ویرایش دسترسی
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => {
                      if (window.confirm('آیا مطمئنید؟')) deleteMutation.mutate(emp._id);
                    }}
                  >
                    حذف
                  </button>
                </div>
              </div>
            ))}
        </div>

        {/* ── Add Employee Modal ─────────────────────────────────────────── */}
        {showModal && (
          <div className="modal-overlay" onClick={() => setShowModal(false)}>
            <div className="modal" onClick={e => e.stopPropagation()}>
              <div className="modal-header">
                <h3>کارمند جدید</h3>
                <button className="btn btn-icon btn-ghost" onClick={() => setShowModal(false)}>✕</button>
              </div>
              <form onSubmit={handleSubmit(data => createMutation.mutate(data))}>
                <div className="modal-body">
                  <div className="form-group">
                    <label className="label">نام و نام خانوادگی</label>
                    <input className="input" {...register('name', { required: true })} placeholder="مثلاً: رضا احمدی" />
                  </div>
                  <div className="form-group">
                    <label className="label">شماره موبایل</label>
                    <input className="input" {...register('phone', { required: true })} placeholder="09..." dir="ltr" />
                  </div>
                  <div className="form-group">
                    <label className="label">دپارتمان</label>
                    <input className="input" {...register('department')} placeholder="مثلاً: چاپ، پشتیبانی، طراحی" />
                  </div>
                  <div className="form-group">
                    <label className="label">دسترسی‌ها</label>
                    <div className="perms-grid">
                      {ALL_PERMS.map(p => (
                        <label key={p.id} className="perm-item">
                          <input
                            type="checkbox"
                            checked={selectedPerms.includes(p.id)}
                            onChange={() => togglePerm(p.id)}
                          />
                          <span>{p.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-ghost" onClick={() => setShowModal(false)}>لغو</button>
                  <button type="submit" className="btn btn-primary" disabled={createMutation.isPending}>
                    {createMutation.isPending ? 'در حال ذخیره...' : 'ذخیره'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ── Edit Permissions Modal ─────────────────────────────────────── */}
        {editingEmp && (
          <div className="modal-overlay" onClick={() => setEditingEmp(null)}>
            <div className="modal" onClick={e => e.stopPropagation()}>
              <div className="modal-header">
                <h3>دسترسی‌های {editingEmp.name}</h3>
                <button className="btn btn-icon btn-ghost" onClick={() => setEditingEmp(null)}>✕</button>
              </div>
              <div className="modal-body">
                <div className="perms-grid">
                  {ALL_PERMS.map(p => (
                    <label key={p.id} className="perm-item">
                      <input
                        type="checkbox"
                        checked={selectedPerms.includes(p.id)}
                        onChange={() => togglePerm(p.id)}
                      />
                      <span>{p.label}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="modal-footer">
                <button className="btn btn-ghost" onClick={() => setEditingEmp(null)}>لغو</button>
                <button
                  className="btn btn-primary"
                  onClick={() => updatePermsMutation.mutate({
                    id: editingEmp._id,
                    permissions: selectedPerms,
                    department: editingEmp.employeeProfile?.department,
                  })}
                  disabled={updatePermsMutation.isPending}
                >
                  ذخیره دسترسی‌ها
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </>
  );
}
