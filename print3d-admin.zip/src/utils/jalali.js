/**
 * jalali.js — تبدیل تاریخ میلادی به شمسی در فرانت‌اند
 * بدون وابستگی به سرور خارجی — لوکال کامل
 */

// الگوریتم تبدیل بدون وابستگی به کتابخانه خارجی
const toJalali = (gy, gm, gd) => {
  const g_d_no = [0,31,59,90,120,151,181,212,243,273,304,334];
  let jy = 0, jm = 0, jd = 0;
  let gy2 = gm > 2 ? gy + 1 : gy;
  let g = 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100)
        + Math.floor((gy2 + 399) / 400) - 80 + gd + g_d_no[gm - 1];
  jy = -1595;
  let j = 365 * jy + Math.floor(jy / 33) * 8 + Math.floor(((jy % 33) + 3) / 4) + 78;
  jy += 33 * Math.floor((g - j) / 12053);
  j %= 12053;
  jy += Math.floor(j / 365);
  j %= 365;
  const tmp = j + Math.floor(j / 11);
  jm = tmp < 186 ? 1 + Math.floor(tmp / 31) : 7 + Math.floor((tmp - 186) / 30);
  jd = 1 + (tmp < 186 ? (tmp % 31) : (tmp - 186) % 30);
  return { jy, jm, jd };
};

const pad = n => String(n).padStart(2,'0');

const MONTHS = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
const DAYS   = ['یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه','شنبه'];

/**
 * ۱۴۰۳/۰۸/۰۱ ۱۰:۲۲
 */
export const formatFull = (date) => {
  const d = new Date(date);
  const { jy,jm,jd } = toJalali(d.getFullYear(), d.getMonth()+1, d.getDate());
  return `${jy}/${pad(jm)}/${pad(jd)}  ${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

/**
 * ۱ آبان ۱۴۰۳
 */
export const formatShort = (date) => {
  const d = new Date(date);
  const { jy,jm,jd } = toJalali(d.getFullYear(), d.getMonth()+1, d.getDate());
  return `${jd} ${MONTHS[jm-1]} ${jy}`;
};

/**
 * شنبه ۱ آبان ۱۴۰۳
 */
export const formatWithDay = (date) => {
  const d = new Date(date);
  return `${DAYS[d.getDay()]} ${formatShort(date)}`;
};

/**
 * ۱۰:۲۲
 */
export const formatTime = (date) => {
  const d = new Date(date);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

/**
 * نمایش نسبی
 */
export const formatRelative = (date) => {
  const diffMs  = Date.now() - new Date(date).getTime();
  const diffMin = Math.floor(diffMs / 60_000);
  const diffH   = Math.floor(diffMs / 3_600_000);
  const diffD   = Math.floor(diffMs / 86_400_000);
  if (diffMin < 1)  return 'همین الان';
  if (diffMin < 60) return `${diffMin} دقیقه پیش`;
  if (diffH < 24)   return `${diffH} ساعت پیش`;
  if (diffD === 1)  return 'دیروز';
  if (diffD < 7)    return `${diffD} روز پیش`;
  return formatShort(date);
};

/**
 * اعداد فارسی
 */
export const toPersian = (num) =>
  String(num).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);

export const MONTHS_FA = MONTHS;

/**
 * تبدیل رشته شمسی به میلادی برای فیلتر API
 * input: "1403/08/01"
 */
export const fromJalali = (str) => {
  if (!str) return null;
  const [jy,jm,jd] = str.replace(/[۰-۹]/g, d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).split('/').map(Number);
  // تبدیل ساده
  const gy = jy + 621;
  return new Date(gy, jm-1, jd);
};
