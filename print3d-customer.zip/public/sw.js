self.addEventListener('push', function(event) {
  const data = event.data ? event.data.json() : {};
  const title = data.title || 'پرینت ۳D';
  const options = {
    body: data.body || '',
    icon: '/icon-192x192.png',
    badge: '/icon-96x96.png',
    data: data.data || {},
    dir: 'rtl',
    lang: 'fa',
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  const data = event.notification.data;
  let url = '/';
  if (data?.type === 'new_message') url = '/chats';
  else if (data?.type === 'status_changed' || data?.type === 'new_order') url = '/orders';
  event.waitUntil(clients.openWindow(url));
});