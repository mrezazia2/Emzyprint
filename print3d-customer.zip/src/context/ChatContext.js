﻿import React, { createContext, useContext, useEffect, useRef, useState, useCallback } from 'react';
import { io } from 'socket.io-client';
import useAuthStore from '../store/authStore';
import api from '../services/api';

const ChatContext = createContext(null);
const SOCKET_URL = 'http://app.emzyprint.ir';

export function ChatProvider({ children }) {
  const { token, user } = useAuthStore();
  const [unreadCount, setUnreadCount] = useState(0);
  const socketRef = useRef(null);

  const fetchUnread = useCallback(async () => {
    if (!token) return;
    try {
      const { data } = await api.get('/chat');
      const chats = data.chats || [];
      const total = chats.reduce((sum, chat) => {
        return sum + (chat.unreadCounts?.[user?._id] || 0);
      }, 0);
      console.log('[ChatContext] fetchUnread total:', total);
      setUnreadCount(total);
    } catch(e) {
      console.log('[ChatContext] fetchUnread error:', e.message);
    }
  }, [token, user?._id]);

  useEffect(() => {
    console.log('[ChatContext] useEffect token:', !!token, 'user:', user?._id);
    if (!token) return;

    fetchUnread();

    const socket = io(SOCKET_URL, {
      auth: { token },
      transports: ['websocket', 'polling'],
    });
    socketRef.current = socket;

    socket.on('connect', () => {
      console.log('[ChatContext] socket connected:', socket.id);
      api.get('/chat').then(({ data }) => {
        console.log('[ChatContext] joining', data.chats?.length, 'chats');
        data.chats?.forEach(c => {
          socket.emit('chat:join', { chatId: c._id });
          console.log('[ChatContext] joined:', c._id);
        });
      }).catch(e => console.log('[ChatContext] join error:', e.message));
    });

    socket.on('message:new', ({ chatId, message }) => {
      console.log('[ChatContext] message:new from:', message?.sender?._id, 'me:', user?._id);
      if (message?.sender?._id !== user?._id && message?.sender !== user?._id) {
        console.log('[ChatContext] incrementing unread!');
        setUnreadCount(prev => prev + 1);
      } else {
        console.log('[ChatContext] message is mine, skipping');
      }
    });

    socket.on('connect_error', e => console.log('[ChatContext] connect_error:', e.message));

    return () => { socket.disconnect(); };
  }, [token, user?._id]);

  const markAllRead = useCallback(async () => {
    setUnreadCount(0);
    try {
      const { data } = await api.get('/chat');
      data.chats?.forEach(c => {
        socketRef.current?.emit('message:read', { chatId: c._id });
      });
    } catch {}
  }, []);

  const refreshUnread = useCallback(() => { fetchUnread(); }, [fetchUnread]);

  return (
    <ChatContext.Provider value={{ unreadCount, markAllRead, refreshUnread, socket: socketRef }}>
      {children}
    </ChatContext.Provider>
  );
}

export function useChatContext() {
  const ctx = useContext(ChatContext);
  if (!ctx) throw new Error('useChatContext must be used inside ChatProvider');
  return ctx;
}