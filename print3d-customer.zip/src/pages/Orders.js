import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import api from '../services/api';

const STATUS_TABS = [
  { id:'', label:'همه' },
  { id:'new', label:'جدید' },
  { id:'printing', label:'چاپ' },
  { id:'ready', label:'آماده' },
  { id:'delivered', label:'تحویل' },
];

const getProgressColor = (p) => {
  if (p <= 0)  return '#F0614E';
  if (p <= 40) return '#F5A623';
  if (p < 100) return '#3DD68C';
  return '#22C55E';
};

export default function OrdersPage() {
  const [statusFilter, setStatusFilter] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['my-orders', statusFilter],
    queryFn: () => api.get('/orders', { params: { status: statusFilter || undefined, limit: 30 } }).then(r => r.data),
  });

  const { data: statuses } = useQuery({
    queryKey: ['order-statuses'],
    queryFn: () => api.get('/admin/statuses').then(r => r.data.statuses),
  });

  const getStatus = (key) => statuses?.find(s => s.key === key) || { label: { fa: key }, color: '#534AB7', bgColor: '#EEEDFE', progressPercent: 0 };

  return (
    <div className="page page-with-header animate-up">
      {/* Header */}
      <div className="topbar topbar-white">
        <div className="tb-row">
          <div className="tb-title" style={{ color:'var(--t1)' }}>سفارشات من</div>
          <Link to="/new-order" style={{ background:'var(--brand)', color:'#fff', borderRadius:10, padding:'6px 14px', textDecoration:'none', fontSize:'.8rem', fontWeight:700 }}>+ جدید</Link>
        </div>
      </div>

      {/* Status tabs */}
      <div style={{ padding:'10px 14px 0', overflowX:'auto', display:'flex', gap:6 }}>
        {STATUS_TABS.map(tab => (
          <button
            key={tab.id}
            style={{ padding:'5px 14px', borderRadius:99, border:'1.5px solid', whiteSpace:'nowrap', fontFamily:'Vazirmatn', fontSize:'.75rem', cursor:'pointer', transition:'all .15s',
              borderColor: statusFilter === tab.id ? 'var(--brand)' : 'var(--border)',
              background: statusFilter === tab.id ? 'var(--brand-d)' : 'transparent',
              color: statusFilter === tab.id ? 'var(--brand)' : 'var(--t2)',
              fontWeight: statusFilter === tab.id ? 700 : 400,
            }}
            onClick={() => setStatusFilter(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="section" style={{ paddingTop:12 }}>
        {isLoading ? (
          Array(4).fill(0).map((_,i) => (
            <div key={i} style={{ height:90, background:'var(--bg2)', borderRadius:12, marginBottom:8, animation:'pulse 1.5s infinite' }} />
          ))
        ) : data?.orders?.length === 0 ? (
          <div style={{ textAlign:'center', padding:'40px 0', color:'var(--t2)' }}>
            <div style={{ fontSize:'2.5rem', marginBottom:8 }}>📋</div>
            <div>سفارشی یافت نشد</div>
          </div>
        ) : data?.orders?.map(order => {
          const s = getStatus(order.status);
          const progress = s.progressPercent || 0;
          const barColor = getProgressColor(progress);
          return (
            <Link key={order._id} to={`/orders/${order._id}`} style={{ textDecoration:'none', display:'block', marginBottom:8 }}>
              <div className="card" style={{ gap:10, display:'flex', flexDirection:'column' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
                  <div>
                    <div style={{ fontFamily:'monospace', fontSize:'.82rem', fontWeight:700, color:'var(--brand)' }}>{order.orderNumber}</div>
                    <div style={{ fontSize:'.7rem', color:'var(--t2)', marginTop:2 }}>
                      {order.printSettings?.material} · ×{order.printSettings?.quantity}
                    </div>
                  </div>
                  <div style={{ textAlign:'left' }}>
                    <span style={{ background:s.bgColor, color:s.color, fontSize:'.68rem', fontWeight:600, borderRadius:99, padding:'3px 9px' }}>
                      {s.label?.fa || s.label}
                    </span>
                    <div style={{ fontSize:'.65rem', color:'var(--t3)', marginTop:3, textAlign:'left' }}>
                      {order.createdAtJalali?.split(' ')[0]}
                    </div>
                  </div>
                </div>
                {/* Progress */}
                <div>
                  <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                    <span style={{ fontSize:'.62rem', color:'var(--t3)' }}>پیشرفت سفارش</span>
                    <span style={{ fontSize:'.65rem', fontWeight:700, color:barColor }}>{progress}٪</span>
                  </div>
                  <div className="progress-track">
                    <div className="progress-fill" style={{ width:`${progress}%`, background:`linear-gradient(90deg, #F0614E, ${barColor})` }} />
                  </div>
                </div>
                {/* Payment */}
                {order.payment?.amount && (
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                    <span style={{ fontSize:'.75rem', color:'var(--t2)' }}>
                      {order.payment.amount.toLocaleString()} {order.payment.currency === 'USD' ? '$' : 'ت'}
                    </span>
                    <span style={{ fontSize:'.68rem', fontWeight:600, borderRadius:99, padding:'2px 8px',
                      background: order.payment.status==='paid' ? 'rgba(29,158,117,.12)' : 'rgba(239,159,39,.12)',
                      color: order.payment.status==='paid' ? '#1D9E75' : '#7A4F00',
                    }}>
                      {order.payment.status === 'paid' ? '✅ پرداخت شده' : '⏳ در انتظار'}
                    </span>
                  </div>
                )}
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
