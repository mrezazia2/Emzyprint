import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { io } from 'socket.io-client';
import api from '../services/api';
import useAuthStore from '../store/authStore';

const SOCKET_URL = process.env.REACT_APP_API_URL?.replace('/api', '') || 'http://localhost:5000';

export default function ChatPage() {
  const navigate = useNavigate();
  const { user, token } = useAuthStore();

  const [chats, setChats] = useState([]);
  const [activeChat, setActiveChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [typing, setTyping] = useState(false);
  const [typingUsers, setTypingUsers] = useState([]);
  const [uploading, setUploading] = useState(false);

  const activeChatRef = useRef(null);
  const socketRef = useRef(null);
  const messagesEndRef = useRef(null);
  const typingTimerRef = useRef(null);
  const fileInputRef = useRef();
  const setActiveChatWithRef = (chat) => {
  activeChatRef.current = chat;
  setActiveChat(chat);
};

  // اتصال socket
  useEffect(() => {
    if (!token) return;
    const socket = io(SOCKET_URL, {
      auth: { token },
      transports: ['websocket', 'polling'],
    });
    socketRef.current = socket;

    socket.on('message:new', ({ chatId, message }) => {
      setMessages(prev => {
        // فقط اگه این چت فعاله اضافه کن
        if (activeChatRef.current?._id === chatId) {
          socket.emit('message:read', { chatId });
          return [...prev, message];
        }
        return prev;
      });
      setChats(prev => prev.map(c =>
        c._id === chatId
          ? { ...c, lastMessage: message, unreadCounts: { ...c.unreadCounts, [user?._id]: 0 } }
          : c
      ));
    });

    socket.on('typing:update', ({ chatId, userId, name, isTyping }) => {
      if (activeChat?._id === chatId && userId !== user?._id) {
        setTypingUsers(prev =>
          isTyping ? [...prev.filter(u => u.id !== userId), { id: userId, name }]
                   : prev.filter(u => u.id !== userId)
        );
      }
    });

    return () => socket.disconnect();
  }, [token]);

  // بارگذاری چت‌ها
  useEffect(() => {
    loadChats();
  }, []);

  // اسکرول به پایین
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // وقتی چت عوض شد
  useEffect(() => {
    if (!activeChat) return;
    loadMessages(activeChat._id);
    socketRef.current?.emit('chat:join', { chatId: activeChat._id });
    socketRef.current?.emit('message:read', { chatId: activeChat._id });
    setTypingUsers([]);
  }, [activeChat?._id]);

  const loadChats = async () => {
    try {
      const res = await api.get('/chat');
      setChats(res.data.chats || []);
      if (res.data.chats?.length > 0 && !activeChat) {
        setActiveChatWithRef(res.data.chats[0]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const loadMessages = async (chatId) => {
    try {
      const res = await api.get(`/chat/${chatId}/messages`);
      setMessages(res.data.messages || []);
    } catch (err) {
      console.error(err);
    }
  };

  const sendMessage = async () => {
    if (!text.trim() || !activeChat || sending) return;
    const content = text.trim();
    setText('');
    setSending(true);
    socketRef.current?.emit('typing:stop', { chatId: activeChat._id });

    socketRef.current?.emit('message:send', {
      chatId: activeChat._id,
      type: 'text',
      content,
    });
    setSending(false);
  };

  const handleTyping = (val) => {
    setText(val);
    if (!activeChat) return;
    if (!typing) {
      setTyping(true);
      socketRef.current?.emit('typing:start', { chatId: activeChat._id });
    }
    clearTimeout(typingTimerRef.current);
    typingTimerRef.current = setTimeout(() => {
      setTyping(false);
      socketRef.current?.emit('typing:stop', { chatId: activeChat._id });
    }, 1500);
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file || !activeChat) return;
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      const res = await api.post(`/chat/${activeChat._id}/upload`, formData);
      const isImage = file.type.startsWith('image/');
      setMessages(prev => [...prev, res.data.message]);
    } catch (err) {
      console.error(err);
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const getOtherParticipant = (chat) => {
    return chat.participants?.find(p => p._id !== user?._id) || chat.participants?.[0];
  };

  const formatTime = (date) => {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (date) => {
    if (!date) return '';
    return new Date(date).toLocaleDateString('fa-IR');
  };

  if (loading) return (
    <div style={{ display:'flex', justifyContent:'center', alignItems:'center', height:'100vh' }}>
      <div className="spinner" />
    </div>
  );

  return (
    <div style={{ display:'flex', flexDirection:'column', height:'100vh', paddingTop:60, boxSizing:'border-box', background:'var(--bg)' }}>
      {/* هدر */}
      <div className="topbar topbar-white">
        <div className="tb-row">
          {activeChat ? (
            <>
              <button onClick={() => setActiveChatWithRef(null)} style={{ background:'none', border:'none', fontSize:'1.2rem', cursor:'pointer', padding:4 }}>‹</button>
              <div style={{ flex:1, fontWeight:700, textAlign:'center', fontSize:'.9rem' }}>
                {getOtherParticipant(activeChat)?.name || 'پشتیبانی'}
              </div>
              <div style={{ width:28 }} />
            </>
          ) : (
            <div style={{ fontWeight:700 }}>پشتیبانی</div>
          )}
        </div>
      </div>

      {/* لیست چت‌ها یا داخل چت */}
      {!activeChat ? (
        <div style={{ flex:1, overflowY:'auto', padding:'8px 0' }}>
          {chats.length === 0 ? (
            <div style={{ textAlign:'center', padding:40, color:'var(--t2)' }}>
              <div style={{ fontSize:3+'rem', marginBottom:12 }}>💬</div>
              <div style={{ fontSize:'.9rem' }}>هنوز چتی ندارید</div>
              <div style={{ fontSize:'.78rem', marginTop:6, color:'var(--t3)' }}>چت‌های پشتیبانی سفارش‌ها اینجا نمایش داده می‌شود</div>
            </div>
          ) : (
            chats.map(chat => {
              const other = getOtherParticipant(chat);
              const unread = chat.unreadCounts?.[user?._id] || 0;
              return (
                <div
                  key={chat._id}
                  onClick={() => setActiveChatWithRef(chat)}
                  style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderBottom:'1px solid var(--border)', cursor:'pointer', background: unread > 0 ? 'rgba(83,74,183,.04)' : 'transparent' }}
                >
                  <div style={{ width:44, height:44, borderRadius:'50%', background:'var(--brand)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:700, fontSize:'1rem', flexShrink:0 }}>
                    {other?.name?.slice(0,1) || '?'}
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                      <div style={{ fontWeight:600, fontSize:'.88rem' }}>{other?.name || 'پشتیبانی'}</div>
                      <div style={{ fontSize:'.7rem', color:'var(--t3)' }}>{formatTime(chat.lastMessage?.at)}</div>
                    </div>
                    <div style={{ fontSize:'.78rem', color:'var(--t2)', marginTop:2, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                      {chat.lastMessage?.content || 'شروع مکالمه'}
                    </div>
                    {chat.order && (
                      <div style={{ fontSize:'.7rem', color:'var(--brand)', marginTop:2 }}>
                        سفارش #{chat.order?.orderNumber}
                      </div>
                    )}
                  </div>
                  {unread > 0 && (
                    <div style={{ background:'var(--brand)', color:'#fff', borderRadius:99, width:20, height:20, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'.7rem', fontWeight:700, flexShrink:0 }}>
                      {unread}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      ) : (
        <>
          {/* پیام‌ها */}
          <div style={{ flex:1, overflowY:'auto', padding:'12px 16px', paddingBottom:'80px', display:'flex', flexDirection:'column', gap:8 }}>
            {messages.map((msg, i) => {
              const isMe = msg.sender?._id === user?._id || msg.sender === user?._id;
              const showDate = i === 0 || formatDate(messages[i-1]?.createdAt) !== formatDate(msg.createdAt);
              return (
                <React.Fragment key={msg._id || i}>
                  {showDate && (
                    <div style={{ textAlign:'center', fontSize:'.7rem', color:'var(--t3)', margin:'8px 0' }}>
                      {formatDate(msg.createdAt)}
                    </div>
                  )}
                  <div style={{ display:'flex', justifyContent: isMe ? 'flex-start' : 'flex-end' }}>
                    <div style={{
                      maxWidth:'75%',
                      background: isMe ? 'var(--brand)' : '#f0f0f0',
                      color: isMe ? '#fff' : '#1a1a2e',
                      borderRadius: isMe ? '18px 18px 18px 4px' : '18px 18px 4px 18px',
                      padding:'10px 14px',
                      fontSize:'.85rem',
                      lineHeight:1.5,
                    }}>
                      {msg.type === 'image' && msg.fileUrl && (
                        <img src={msg.fileUrl} alt="تصویر" style={{ maxWidth:'100%', borderRadius:8, marginBottom:4 }} onClick={() => window.open(msg.fileUrl)} />
                      )}
                      {msg.type === 'file' && (
                        <a href={msg.fileUrl} target="_blank" rel="noreferrer" style={{ color: isMe ? '#fff' : 'var(--brand)', display:'flex', alignItems:'center', gap:6 }}>
                          <span>📎</span> {msg.fileName}
                        </a>
                      )}
                      {(msg.type === 'text' || !msg.type) && msg.content}
                      <div style={{ fontSize:'.65rem', opacity:.7, marginTop:4, textAlign:'left' }}>
                        {formatTime(msg.createdAt)}
                      </div>
                    </div>
                  </div>
                </React.Fragment>
              );
            })}
            {typingUsers.length > 0 && (
              <div style={{ display:'flex', justifyContent:'flex-end' }}>
                <div style={{ background:'#f0f0f0', borderRadius:'18px 18px 4px 18px', padding:'10px 14px', fontSize:'.8rem', color:'var(--t2)' }}>
                  {typingUsers[0].name} در حال تایپ...
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* input ارسال */}
          <div style={{ padding:'8px 12px', borderTop:'1px solid var(--border)', background:'#fff', display:'flex', gap:8, alignItems:'center', paddingBottom:'70px', flexShrink:0 }}>
            <input
              ref={fileInputRef}
              type="file"
              style={{ display:'none' }}
              accept="image/*,.pdf,.zip,.rar"
              onChange={handleFileUpload}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              style={{ background:'none', border:'none', fontSize:'1.4rem', cursor:'pointer', padding:4, color:'var(--t2)', flexShrink:0 }}
            >
              {uploading ? '⏳' : '📎'}
            </button>
            <input
              style={{ flex:1, border:'1.5px solid var(--border)', borderRadius:20, padding:'10px 14px', fontFamily:'Vazirmatn', fontSize:'.88rem', outline:'none', background:'var(--bg2)' }}
              value={text}
              onChange={e => handleTyping(e.target.value)}
              placeholder="پیام بنویسید..."
              onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
            />
            <button
              onClick={sendMessage}
              disabled={!text.trim() || sending}
              style={{ background: text.trim() ? 'var(--brand)' : 'var(--border)', border:'none', borderRadius:'50%', width:40, height:40, display:'flex', alignItems:'center', justifyContent:'center', cursor: text.trim() ? 'pointer' : 'default', flexShrink:0, transition:'background .2s' }}
            >
              <span style={{ color:'#fff', fontSize:'1rem' }}>➤</span>
            </button>
          </div>
        </>
      )}
    </div>
  );
}
