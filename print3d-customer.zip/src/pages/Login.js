import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import useAuthStore from '../store/authStore';
import api from '../services/api';

export default function LoginPage() {
  const navigate = useNavigate();
  const { login, token, submitName } = useAuthStore();
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [name, setName] = useState('');
  const [step, setStep] = useState('phone'); // 'phone' | 'otp' | 'name'
  const [loading, setLoading] = useState(false);
  const [countdown, setCountdown] = useState(0);

  useEffect(() => { if (token) navigate('/'); }, [token]);

  useEffect(() => {
    if (countdown > 0) {
      const t = setTimeout(() => setCountdown(c => c - 1), 1000);
      return () => clearTimeout(t);
    }
  }, [countdown]);

  const sendOTP = async () => {
    if (!/^09\d{9}$/.test(phone)) return toast.error('شماره موبایل معتبر نیست');
    setLoading(true);
    try {
      await api.post('/auth/send-otp', { phone });
      setStep('otp');
      setCountdown(120);
      toast.success('کد تایید ارسال شد');
    } catch (err) {
      toast.error(err.response?.data?.error || 'خطا در ارسال پیامک');
    } finally { setLoading(false); }
  };

  const verifyOTP = async () => {
    if (otp.length !== 6) return toast.error('کد ۶ رقمی وارد کنید');
    setLoading(true);
    try {
      const res = await login(phone, otp);
      if (res.requireName) {
        setStep('name');
      } else {
        navigate('/');
      }
    } catch (err) {
      toast.error(err.response?.data?.error || 'کد اشتباه است');
    } finally { setLoading(false); }
  };

  const handleSubmitName = async () => {
    if (!name.trim() || name.trim().length < 2) return toast.error('لطفاً نام خود را وارد کنید');
    setLoading(true);
    try {
      await submitName(name.trim());
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.error || 'خطا در ثبت نام');
    } finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight:'100vh', background:'#1A1A2E', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:20 }}>
      {/* Logo */}
		<img src="/logo.gif" alt="logo" style={{ width:80, height:80, objectFit:'contain', marginBottom:24, transform:'scale(4.5)', transformOrigin:'center' }} />
		<div style={{ fontSize:'1.3rem', fontWeight:700, color:'#fff', marginBottom:4 }}>ماشینکاری و چاپ سه بعدی ام زی</div>
      <div style={{ fontSize:'.82rem', color:'rgba(255,255,255,.5)', marginBottom:28 }}>
        {step === 'name' ? 'تکمیل اطلاعات حساب' : 'ورود به حساب کاربری'}
      </div>

      <div style={{ width:'100%', maxWidth:360, background:'#242938', borderRadius:20, padding:24, border:'1px solid rgba(255,255,255,.08)' }}>

        {/* ─── STEP: phone ─── */}
        {step === 'phone' && (
          <>
            <div style={{ marginBottom:16 }}>
              <label style={{ fontSize:'.78rem', color:'rgba(255,255,255,.5)', display:'block', marginBottom:6 }}>شماره موبایل</label>
              <input
                style={{ width:'100%', padding:'12px 14px', background:'rgba(255,255,255,.07)', border:'1.5px solid rgba(255,255,255,.1)', borderRadius:12, color:'#fff', fontFamily:'Vazirmatn', fontSize:'.95rem', outline:'none', direction:'ltr', textAlign:'center', letterSpacing:'.05em', boxSizing:'border-box' }}
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="09..."
                maxLength={11}
                onKeyDown={e => e.key === 'Enter' && sendOTP()}
              />
            </div>
            <button
              style={{ width:'100%', padding:13, background: loading ? 'rgba(83,74,183,.5)' : '#534AB7', border:'none', borderRadius:12, color:'#fff', fontFamily:'Vazirmatn', fontSize:'.95rem', fontWeight:700, cursor:'pointer' }}
              onClick={sendOTP}
              disabled={loading}
            >
              {loading ? 'در حال ارسال...' : 'ارسال کد تایید'}
            </button>
          </>
        )}

        {/* ─── STEP: otp ─── */}
        {step === 'otp' && (
          <>
            <div style={{ textAlign:'center', marginBottom:16 }}>
              <div style={{ fontSize:'.8rem', color:'rgba(255,255,255,.5)' }}>کد ارسال شده به</div>
              <div style={{ fontSize:'.95rem', color:'#AFA9EC', fontWeight:600, direction:'ltr', marginTop:4 }}>{phone}</div>
            </div>
            <div style={{ display:'flex', gap:8, justifyContent:'center', marginBottom:20 }}>
              {[0,1,2,3,4,5].map(i => (
                <div key={i} style={{ width:40, height:48, background: otp[i] ? 'rgba(83,74,183,.3)' : 'rgba(255,255,255,.07)', border:`1.5px solid ${otp[i] ? '#534AB7' : 'rgba(255,255,255,.1)'}`, borderRadius:10, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.2rem', fontWeight:700, color:'#fff' }}>
                  {otp[i] || ''}
                </div>
              ))}
            </div>
            <input
              style={{ width:'100%', padding:'12px', background:'rgba(255,255,255,.07)', border:'1.5px solid rgba(255,255,255,.1)', borderRadius:12, color:'#fff', fontFamily:'Vazirmatn', fontSize:'1.2rem', fontWeight:700, outline:'none', textAlign:'center', letterSpacing:'.3em', marginBottom:14, boxSizing:'border-box' }}
              value={otp}
              onChange={e => setOtp(e.target.value.replace(/\D/g,''))}
              placeholder="_ _ _ _ _ _"
              maxLength={6}
              autoFocus
			  autoComplete="one-time-code"
			  inputMode="numeric"
              onKeyDown={e => e.key === 'Enter' && verifyOTP()}
            />
            <button
              style={{ width:'100%', padding:13, background: loading ? 'rgba(83,74,183,.5)' : '#534AB7', border:'none', borderRadius:12, color:'#fff', fontFamily:'Vazirmatn', fontSize:'.95rem', fontWeight:700, cursor:'pointer', marginBottom:10 }}
              onClick={verifyOTP}
              disabled={loading}
            >
              {loading ? 'در حال بررسی...' : 'ورود'}
            </button>
            <button
              style={{ width:'100%', padding:10, background:'transparent', border:'1px solid rgba(255,255,255,.15)', borderRadius:12, color: countdown > 0 ? 'rgba(255,255,255,.3)' : 'rgba(255,255,255,.6)', fontFamily:'Vazirmatn', fontSize:'.82rem', cursor: countdown > 0 ? 'default' : 'pointer' }}
              onClick={countdown === 0 ? sendOTP : undefined}
              disabled={countdown > 0}
            >
              {countdown > 0 ? `ارسال مجدد (${countdown}s)` : 'ارسال مجدد کد'}
            </button>
            <button
              style={{ width:'100%', marginTop:8, padding:8, background:'transparent', border:'none', color:'rgba(255,255,255,.4)', fontFamily:'Vazirmatn', fontSize:'.78rem', cursor:'pointer' }}
              onClick={() => { setStep('phone'); setOtp(''); }}
            >
              تغییر شماره
            </button>
          </>
        )}

        {/* ─── STEP: name ─── */}
        {step === 'name' && (
          <>
            <div style={{ textAlign:'center', marginBottom:20 }}>
              <div style={{ fontSize:'2rem', marginBottom:8 }}>👋</div>
              <div style={{ fontSize:'.88rem', color:'rgba(255,255,255,.6)', lineHeight:1.6 }}>
                خوش آمدید!<br/>لطفاً نام و نام خانوادگی خود را وارد کنید
              </div>
            </div>
            <div style={{ marginBottom:16 }}>
              <label style={{ fontSize:'.78rem', color:'rgba(255,255,255,.5)', display:'block', marginBottom:6 }}>نام و نام خانوادگی</label>
              <input
                style={{ width:'100%', padding:'12px 14px', background:'rgba(255,255,255,.07)', border:'1.5px solid rgba(255,255,255,.1)', borderRadius:12, color:'#fff', fontFamily:'Vazirmatn', fontSize:'.95rem', outline:'none', textAlign:'right', boxSizing:'border-box' }}
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="مثلاً: علی محمدی"
                autoFocus
                onKeyDown={e => e.key === 'Enter' && handleSubmitName()}
              />
            </div>
            <button
              style={{ width:'100%', padding:13, background: (loading || !name.trim()) ? 'rgba(83,74,183,.5)' : '#534AB7', border:'none', borderRadius:12, color:'#fff', fontFamily:'Vazirmatn', fontSize:'.95rem', fontWeight:700, cursor: (loading || !name.trim()) ? 'default' : 'pointer' }}
              onClick={handleSubmitName}
              disabled={loading || !name.trim()}
            >
              {loading ? 'در حال ثبت...' : 'ثبت و ورود'}
            </button>
          </>
        )}

      </div>
    </div>
  );
}
