import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import useAuthStore from '../store/authStore';
import api from '../services/api';

const STATUS_CFG = {
  new:           { label:'جدید',         color:'#534AB7', bg:'#EEEDFE' },
  reviewing:     { label:'بررسی',        color:'#0C447C', bg:'#E6F1FB' },
  printing:      { label:'در حال چاپ',   color:'#633806', bg:'#FAEEDA' },
  quality_check: { label:'کنترل کیفیت', color:'#4A5E08', bg:'#F0F7DC' },
  ready:         { label:'آماده تحویل',  color:'#27500A', bg:'#EAF3DE' },
  delivered:     { label:'تحویل شد',    color:'#444441', bg:'#F1EFE8' },
  cancelled:     { label:'لغو شده',     color:'#791F1F', bg:'#FCEBEB' },
};

const getProgressColor = (p) => {
  if (p <= 0)  return '#F0614E';
  if (p <= 40) return '#F5A623';
  if (p < 100) return '#3DD68C';
  return '#22C55E';
};

function NotifBell() {
  const [notifs, setNotifs] = useState([]);
  const [unread, setUnread] = useState(0);
  const [open, setOpen] = useState(false);
  const dropRef = useRef(null);
  const navigate = useNavigate();

  const fetchNotifs = async () => {
    try {
      const { data } = await api.get('/notifications');
      setNotifs(data.notifications || []);
      setUnread(data.unreadCount || 0);
    } catch {}
  };

useEffect(() => {
    fetchNotifs();
    const interval = setInterval(fetchNotifs, 30000);

    // socket برای real-time notification
    const token = localStorage.getItem('customer_token');
    if (token) {
      import('socket.io-client').then(({ io }) => {
        const socket = io('http://app.emzyprint.ir', {
          auth: { token },
          transports: ['websocket', 'polling'],
        });
        socket.on('notification:new', (notif) => {
          setUnread(prev => prev + 1);
          setNotifs(prev => [{ ...notif, _id: Date.now(), isRead: false, createdAt: new Date() }, ...prev]);
        });
        return () => socket.disconnect();
      });
    }

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleClick = (e) => {
      if (dropRef.current && !dropRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const markAllRead = async () => {
    try {
      await api.patch('/notifications/read-all');
      setUnread(0);
      setNotifs(prev => prev.map(n => ({ ...n, isRead: true })));
    } catch {}
  };

  const handleOpen = () => {
    setOpen(prev => !prev);
    if (!open && unread > 0) markAllRead();
  };

  const getIcon = (type) => ({
    new_order: '🖨️', status_changed: '📦', new_message: '💬',
    wallet_charged: '💰', payment_required: '💳'
  }[type] || '🔔');

  return (
    <div style={{ position: 'relative' }} ref={dropRef}>
      <button
        onClick={handleOpen}
        style={{ background: 'none', border: 'none', color: '#fff', fontSize: '1.4rem', cursor: 'pointer', position: 'relative', padding: 4 }}
      >
        🔔
        {unread > 0 && (
          <span style={{
            position: 'absolute', top: 0, right: 0,
            background: '#ef4444', color: '#fff',
            fontSize: '0.55rem', fontWeight: 700,
            borderRadius: '999px', minWidth: 15, height: 15,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            padding: '0 3px', lineHeight: 1,
          }}>
            {unread > 99 ? '99+' : unread}
          </span>
        )}
      </button>
      {open && (
        <div style={{
          position: 'absolute', top: '110%', left: 0,
          width: 300, maxHeight: 400, overflowY: 'auto',
          background: '#fff', borderRadius: 12,
          boxShadow: '0 8px 32px rgba(0,0,0,0.15)',
          zIndex: 999,
        }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid #f0f0f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 700, fontSize: '.9rem', color: '#1a1a2e' }}>اعلان‌ها</span>
            {unread > 0 && (
              <button onClick={markAllRead} style={{ background: 'none', border: 'none', color: '#534AB7', fontSize: '.75rem', cursor: 'pointer' }}>
                همه خوانده شد
              </button>
            )}
          </div>
          {notifs.length === 0 ? (
            <div style={{ padding: 24, textAlign: 'center', color: '#999', fontSize: '.85rem' }}>
              اعلانی وجود ندارد
            </div>
          ) : (
            notifs.map(n => (
              <div key={n._id}
                style={{
                  padding: '10px 16px', borderBottom: '1px solid #f0f0f0',
                  background: n.isRead ? 'transparent' : 'rgba(83,74,183,0.06)',
                  cursor: 'pointer', display: 'flex', gap: 10, alignItems: 'flex-start',
                }}
                onClick={() => {
                  if (n.data?.type === 'new_message') navigate('/chats');
                  else if (n.data?.type === 'status_changed') navigate('/orders');
                  setOpen(false);
                }}
              >
                <span style={{ fontSize: '1.2rem' }}>{getIcon(n.type)}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: '.82rem', color: '#1a1a2e' }}>{n.title}</div>
                  <div style={{ fontSize: '.75rem', color: '#888', marginTop: 2 }}>{n.body}</div>
                  <div style={{ fontSize: '.68rem', color: '#bbb', marginTop: 4 }}>
                    {new Date(n.createdAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
                {!n.isRead && <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#534AB7', flexShrink: 0, marginTop: 4 }} />}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

export default function HomePage() {
  const { user } = useAuthStore();

  const { data: ordersData } = useQuery({
    queryKey: ['my-orders'],
    queryFn: () => api.get('/orders?limit=5').then(r => r.data),
  });

  const { data: walletData } = useQuery({
    queryKey: ['my-wallet'],
    queryFn: () => api.get('/wallet').then(r => r.data),
  });

  const { data: statusesData } = useQuery({
    queryKey: ['order-statuses'],
    queryFn: () => api.get('/admin/statuses').then(r => r.data.statuses),
  });

  const getStatus = (key) => {
    const s = statusesData?.find(x => x.key === key);
    return s || STATUS_CFG[key] || STATUS_CFG.new;
  };

  const activeOrders = ordersData?.orders?.filter(o => !['delivered','cancelled'].includes(o.status)) || [];

  return (
    <div className="page page-with-header animate-up">
      <div className="topbar">
        <div className="tb-row">
          <div>
            <div style={{ fontSize:'.78rem', color:'rgba(255,255,255,.6)' }}>سلام،</div>
            <div className="tb-title">{user?.name || 'کاربر عزیز'} 👋</div>
          </div>
          <NotifBell />
        </div>
      </div>

      <div className="section">
        <div style={{ background:'linear-gradient(135deg,#534AB7,#7C6AF5)', borderRadius:16, padding:16, color:'#fff', position:'relative', overflow:'hidden' }}>
          <div style={{ position:'absolute', top:-20, left:-20, width:80, height:80, background:'rgba(255,255,255,.1)', borderRadius:'50%' }}/>
          <div style={{ fontSize:'.78rem', opacity:.7, marginBottom:4 }}>موجودی کیف پول</div>
          <div style={{ fontSize:'2rem', fontWeight:700 }}>{walletData?.wallet?.grams?.toFixed(2) || '0'}<span style={{ fontSize:'.85rem', opacity:.8, marginRight:5 }}>گرم رزین</span></div>
          <div style={{ display:'flex', gap:16, marginTop:10 }}>
            <div style={{ fontSize:'.72rem', opacity:.7 }}>شارژ شده: {walletData?.wallet?.totalCharged?.toFixed(1) || 0}g</div>
            <div style={{ fontSize:'.72rem', opacity:.7 }}>مصرف شده: {walletData?.wallet?.totalUsed?.toFixed(1) || 0}g</div>
          </div>
          <Link to="/wallet" style={{ position:'absolute', left:16, top:'50%', transform:'translateY(-50%)', background:'rgba(255,255,255,.2)', border:'none', borderRadius:10, padding:'7px 14px', color:'#fff', fontFamily:'Vazirmatn', fontSize:'.78rem', fontWeight:600, cursor:'pointer', textDecoration:'none' }}>
            شارژ کیف پول
          </Link>
        </div>
      </div>

      <div className="section" style={{ paddingTop:0 }}>
        <div className="section-title">دسترسی سریع</div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8 }}>
          {[
            { icon:'📋', label:'سفارشاتم', to:'/orders' },
            { icon:'💬', label:'پشتیبانی', to:'/chats' },
            { icon:'💰', label:'کیف پول', to:'/wallet' },
            { icon:'📍', label:'آدرس ما', to:'/map' },
          ].map(item => (
            <Link key={item.to} to={item.to} style={{ background:'var(--bg)', borderRadius:12, padding:'12px 8px', textAlign:'center', textDecoration:'none', border:'1px solid var(--border)' }}>
              <div style={{ fontSize:'1.4rem', marginBottom:4 }}>{item.icon}</div>
              <div style={{ fontSize:'.65rem', color:'var(--t2)', fontWeight:500 }}>{item.label}</div>
            </Link>
          ))}
        </div>
      </div>

      {activeOrders.length > 0 && (
        <div className="section" style={{ paddingTop:0 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
            <div className="section-title" style={{ margin:0 }}>سفارشات فعال</div>
            <Link to="/orders" style={{ fontSize:'.75rem', color:'var(--brand)', textDecoration:'none' }}>همه ←</Link>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {activeOrders.slice(0,3).map(order => {
              const s = getStatus(order.status);
              const progress = s.progressPercent || 0;
              const barColor = getProgressColor(progress);
              return (
                <Link key={order._id} to={`/orders/${order._id}`} style={{ textDecoration:'none' }}>
                  <div className="card-sm" style={{ display:'flex', flexDirection:'column', gap:8 }}>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                      <div>
                        <div style={{ fontSize:'.82rem', fontWeight:600, color:'var(--t1)', fontFamily:'monospace' }}>{order.orderNumber}</div>
                        <div style={{ fontSize:'.7rem', color:'var(--t2)', marginTop:2 }}>{order.createdAtJalali?.split(' ')[0] || ''}</div>
                      </div>
                      <span style={{ background:s.bgColor||'#EEEDFE', color:s.color||'#534AB7', fontSize:'.68rem', fontWeight:600, borderRadius:99, padding:'3px 9px' }}>
                        {s.label?.fa || s.label}
                      </span>
                    </div>
                    <div>
                      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                        <span style={{ fontSize:'.62rem', color:'var(--t3)' }}>پیشرفت</span>
                        <span style={{ fontSize:'.65rem', fontWeight:700, color:barColor }}>{progress}٪</span>
                      </div>
                      <div className="progress-track">
                        <div className="progress-fill" style={{ width:`${progress}%`, background:barColor }} />
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      )}

      {activeOrders.length === 0 && (
        <div className="section" style={{ textAlign:'center', paddingTop:24 }}>
          <div style={{ fontSize:3+'rem', marginBottom:12 }}>🖨️</div>
          <div style={{ fontWeight:700, marginBottom:6 }}>هنوز سفارشی ندارید</div>
          <div style={{ fontSize:'.82rem', color:'var(--t2)', marginBottom:20 }}>اولین سفارش چاپ ۳D خود را ثبت کنید</div>
          <Link to="/new-order" style={{ display:'inline-block', padding:'12px 28px', background:'var(--brand)', color:'#fff', borderRadius:12, textDecoration:'none', fontWeight:700, fontSize:'.9rem' }}>
            + سفارش جدید
          </Link>
        </div>
      )}
    </div>
  );
}