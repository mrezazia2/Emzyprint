import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import useAuthStore from '../store/authStore';
import api from '../services/api';

export default function ProfilePage() {
  const navigate = useNavigate();
  const { user, logout, updateUser } = useAuthStore();

  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user?.name || '');
  const [saving, setSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const fileInputRef = useRef();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleSaveName = async () => {
    if (!name.trim() || name.trim().length < 2) return toast.error('نام باید حداقل ۲ حرف باشد');
    setSaving(true);
    try {
      const res = await api.patch('/customers/profile', { name: name.trim() });
      updateUser({ name: res.data.user.name });
      setEditing(false);
      toast.success('نام با موفقیت ذخیره شد');
    } catch (err) {
      toast.error(err.response?.data?.error || 'خطا در ذخیره اطلاعات');
    } finally { setSaving(false); }
  };

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleAvatarChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) return toast.error('فقط فایل تصویری مجاز است');
    if (file.size > 2 * 1024 * 1024) return toast.error('حجم تصویر باید کمتر از ۲ مگابایت باشد');

    setUploadingAvatar(true);
    try {
      const formData = new FormData();
      formData.append('avatar', file);
      const res = await api.post('/customers/avatar', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      updateUser({ avatar: res.data.avatar });
      toast.success('عکس پروفایل آپدیت شد');
    } catch (err) {
      toast.error(err.response?.data?.error || 'خطا در آپلود تصویر');
    } finally {
      setUploadingAvatar(false);
      e.target.value = '';
    }
  };

  const avatarUrl = user?.avatar
    ? (user.avatar.startsWith('http') ? user.avatar : `${process.env.REACT_APP_API_URL?.replace('/api','')}${user.avatar}`)
    : null;

  return (
    <div className="page page-with-header animate-up">
      <div className="topbar topbar-white">
        <div className="tb-row">
          <div style={{ fontWeight:700 }}>پروفایل</div>
          {!editing ? (
            <button
              style={{ background:'none', border:'none', color:'var(--brand)', fontFamily:'Vazirmatn', fontSize:'.85rem', fontWeight:600, cursor:'pointer', padding:'4px 8px' }}
              onClick={() => { setEditing(true); setName(user?.name || ''); }}
            >
              ویرایش
            </button>
          ) : (
            <div style={{ display:'flex', gap:8 }}>
              <button
                style={{ background:'none', border:'none', color:'var(--t3)', fontFamily:'Vazirmatn', fontSize:'.85rem', cursor:'pointer', padding:'4px 8px' }}
                onClick={() => { setEditing(false); setName(user?.name || ''); }}
              >
                انصراف
              </button>
              <button
                style={{ background:'var(--brand)', border:'none', color:'#fff', fontFamily:'Vazirmatn', fontSize:'.85rem', fontWeight:600, cursor:'pointer', padding:'4px 12px', borderRadius:8 }}
                onClick={handleSaveName}
                disabled={saving}
              >
                {saving ? '...' : 'ذخیره'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Avatar */}
      <div style={{ padding:'24px 16px 16px', display:'flex', flexDirection:'column', alignItems:'center', gap:8 }}>
        <div style={{ position:'relative' }}>
          <div
            onClick={handleAvatarClick}
            style={{ width:80, height:80, borderRadius:'50%', background:'var(--brand)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.8rem', fontWeight:700, color:'#fff', cursor:'pointer', overflow:'hidden', border:'3px solid var(--brand-d)', position:'relative' }}
          >
            {uploadingAvatar ? (
              <div className="spinner" style={{ width:28, height:28 }} />
            ) : avatarUrl ? (
              <img src={avatarUrl} alt="avatar" style={{ width:'100%', height:'100%', objectFit:'cover' }} />
            ) : (
              user?.name?.slice(0,1) || '?'
            )}
          </div>
          <div
            onClick={handleAvatarClick}
            style={{ position:'absolute', bottom:0, right:0, width:24, height:24, background:'var(--brand)', borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontSize:12, cursor:'pointer', border:'2px solid #fff' }}
          >
            📷
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            style={{ display:'none' }}
            onChange={handleAvatarChange}
          />
        </div>

        {editing ? (
          <input
            style={{ border:'1.5px solid var(--brand)', borderRadius:10, padding:'8px 14px', fontFamily:'Vazirmatn', fontSize:'1rem', fontWeight:600, textAlign:'center', outline:'none', marginTop:4, width:200 }}
            value={name}
            onChange={e => setName(e.target.value)}
            autoFocus
            placeholder="نام و نام خانوادگی"
            onKeyDown={e => e.key === 'Enter' && handleSaveName()}
          />
        ) : (
          <div style={{ fontWeight:700, fontSize:'1.1rem' }}>{user?.name || 'کاربر'}</div>
        )}

        <div style={{ fontSize:'.82rem', color:'var(--t2)', direction:'ltr' }}>{user?.phone}</div>
        <span style={{ background:'var(--brand-d)', color:'var(--brand)', borderRadius:99, padding:'3px 12px', fontSize:'.72rem', fontWeight:600 }}>مشتری</span>
      </div>

      {/* Stats */}
      <div className="section" style={{ paddingTop:0 }}>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:8 }}>
          {[
            { label:'سفارشات', value:'—' },
            { label:'امتیاز', value:'—' },
            { label:'عضویت', value:'—' },
          ].map(s => (
            <div key={s.label} className="card" style={{ textAlign:'center', padding:12 }}>
              <div style={{ fontSize:'1.2rem', fontWeight:700 }}>{s.value}</div>
              <div style={{ fontSize:'.65rem', color:'var(--t2)', marginTop:2 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Menu */}
      <div className="section" style={{ paddingTop:0 }}>
        {[
          { icon:'📋', label:'سفارشات من', to:'/orders' },
          { icon:'💰', label:'کیف پول', to:'/wallet' },
          { icon:'💬', label:'پشتیبانی', to:'/chats' },
          { icon:'📍', label:'آدرس مرکز چاپ', to:'/map' },
        ].map(item => (
          <div key={item.to} style={{ display:'flex', alignItems:'center', gap:12, padding:'13px 0', borderBottom:'1px solid var(--border)', cursor:'pointer' }} onClick={() => navigate(item.to)}>
            <span style={{ fontSize:'1.2rem' }}>{item.icon}</span>
            <span style={{ flex:1, fontSize:'.88rem' }}>{item.label}</span>
            <span style={{ color:'var(--t3)', fontSize:'.9rem' }}>›</span>
          </div>
        ))}
      </div>

      <div className="section" style={{ paddingTop:8 }}>
        <button
          style={{ width:'100%', padding:13, background:'rgba(216,90,48,.08)', border:'1px solid rgba(216,90,48,.2)', borderRadius:12, color:'#D85A30', fontFamily:'Vazirmatn', fontSize:'.9rem', fontWeight:600, cursor:'pointer' }}
          onClick={handleLogout}
        >
          خروج از حساب کاربری
        </button>
      </div>
    </div>
  );
}
