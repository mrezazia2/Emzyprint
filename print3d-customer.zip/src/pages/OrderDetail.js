import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import api from '../services/api';

const getProgressColor = (p) => {
  if (p <= 0)  return '#F0614E';
  if (p <= 40) return '#F5A623';
  if (p < 100) return '#3DD68C';
  return '#22C55E';
};

export default function OrderDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const { data, isLoading } = useQuery({
    queryKey: ['order', id],
    queryFn: () => api.get(`/orders/${id}`).then(r => r.data.order),
  });

  const { data: statuses } = useQuery({
    queryKey: ['order-statuses'],
    queryFn: () => api.get('/admin/statuses').then(r => r.data.statuses),
  });

  if (isLoading) return (
    <div style={{ display:'flex', justifyContent:'center', alignItems:'center', height:'100vh' }}>
      <div className="spinner" />
    </div>
  );

  const order = data;
  const sortedStatuses = statuses?.filter(s => s.isActive).sort((a,b) => a.order - b.order) || [];
  const currentStatusObj = statuses?.find(s => s.key === order?.status);
  const progress = currentStatusObj?.progressPercent || 0;
  const barColor = getProgressColor(progress);

  const RESIN_COLORS = { wax:'#3B82F6', dark:'#374151', yellow:'#EAB308', vintage:'#22C55E' };
  const resinColor = RESIN_COLORS[order?.customFields?.get?.('resin_type') || order?.customFields?.resin_type] || '#534AB7';

  return (
    <div className="page animate-up" style={{ paddingTop:60 }}>
      {/* Header */}
      <div className="topbar topbar-white">
        <div className="tb-row">
          <button onClick={() => navigate(-1)} style={{ background:'none', border:'none', fontSize:'1.2rem', cursor:'pointer', color:'var(--t1)', padding:'0 8px 0 0' }}>←</button>
          <div style={{ fontFamily:'monospace', fontSize:'.9rem', fontWeight:700, color:'var(--brand)' }}>{order?.orderNumber}</div>
          <Link to="/chats" state={{ chatId: order?.chat }} style={{ background:'var(--brand-d)', color:'var(--brand)', borderRadius:10, padding:'6px 12px', textDecoration:'none', fontSize:'.78rem', fontWeight:600 }}>
            💬 چت
          </Link>
        </div>
      </div>

      {/* Progress */}
      <div className="section">
        <div className="card">
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
            <span style={{ fontSize:'.78rem', fontWeight:600, color:'var(--t2)' }}>پیشرفت سفارش</span>
            <div style={{ display:'flex', alignItems:'center', gap:6 }}>
              <span style={{ background:currentStatusObj?.bgColor||'#EEEDFE', color:currentStatusObj?.color||'#534AB7', fontSize:'.7rem', fontWeight:600, borderRadius:99, padding:'3px 9px' }}>
                {currentStatusObj?.label?.fa || order?.status}
              </span>
              <span style={{ fontSize:'.78rem', fontWeight:700, color:barColor }}>{progress}٪</span>
            </div>
          </div>
          <div className="progress-track" style={{ height:8, marginBottom:6 }}>
            <div className="progress-fill" style={{ width:`${progress}%`, background:`linear-gradient(90deg,#F0614E,${barColor})`, boxShadow:`0 0 8px ${barColor}60` }} />
          </div>
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:'.58rem', color:'var(--t3)' }}>
            {[0,25,50,75,100].map(m => (
              <span key={m} style={{ color: progress>=m ? barColor : 'var(--t3)', fontWeight: progress>=m ? 700 : 400 }}>{m}٪</span>
            ))}
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div className="section" style={{ paddingTop:0 }}>
        <div className="section-title">مسیر سفارش</div>
        <div style={{ display:'flex', flexDirection:'column', gap:0 }}>
          {sortedStatuses.map((s, i) => {
            const isDone = sortedStatuses.findIndex(x => x.key === order?.status) >= i;
            const isCurrent = s.key === order?.status;
            return (
              <div key={s.key} style={{ display:'flex', gap:12, alignItems:'flex-start' }}>
                <div style={{ display:'flex', flexDirection:'column', alignItems:'center' }}>
                  <div style={{ width:22, height:22, borderRadius:'50%', background: isDone ? s.color||'#534AB7' : 'var(--border)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'.65rem', color: isDone ? '#fff' : 'var(--t3)', fontWeight:700, flexShrink:0, border: isCurrent ? `2px solid ${s.color}` : 'none' }}>
                    {isDone ? '✓' : i+1}
                  </div>
                  {i < sortedStatuses.length-1 && (
                    <div style={{ width:2, height:24, background: isDone ? s.color||'#534AB7' : 'var(--border)', margin:'2px 0' }} />
                  )}
                </div>
                <div style={{ paddingBottom:8 }}>
                  <div style={{ fontSize:'.82rem', fontWeight: isCurrent ? 700 : 400, color: isCurrent ? s.color||'var(--brand)' : isDone ? 'var(--t1)' : 'var(--t3)' }}>
                    {s.icon} {s.label?.fa}
                  </div>
                  {isCurrent && order?.timeline?.slice(-1)[0]?.note && (
                    <div style={{ fontSize:'.7rem', color:'var(--t2)', marginTop:2 }}>{order.timeline.slice(-1)[0].note}</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Order Info */}
      <div className="section" style={{ paddingTop:0 }}>
        <div className="section-title">جزئیات سفارش</div>
        <div className="card" style={{ display:'flex', flexDirection:'column', gap:10 }}>
          <div style={{ display:'flex', justifyContent:'space-between' }}>
            <span style={{ fontSize:'.78rem', color:'var(--t2)' }}>ماده چاپ</span>
            <span style={{ fontSize:'.82rem', fontWeight:600 }}>{order?.printSettings?.material}</span>
          </div>
          <div className="divider" style={{ margin:'2px 0' }} />
          <div style={{ display:'flex', justifyContent:'space-between' }}>
            <span style={{ fontSize:'.78rem', color:'var(--t2)' }}>تعداد</span>
            <span style={{ fontSize:'.82rem', fontWeight:600 }}>×{order?.printSettings?.quantity}</span>
          </div>
          <div className="divider" style={{ margin:'2px 0' }} />
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <span style={{ fontSize:'.78rem', color:'var(--t2)' }}>نوع رزین</span>
            <div style={{ display:'flex', alignItems:'center', gap:5 }}>
              <div style={{ width:10, height:10, borderRadius:'50%', background:resinColor }} />
              <span style={{ fontSize:'.82rem', fontWeight:600 }}>{order?.customFields?.resin_type || '—'}</span>
            </div>
          </div>
          {order?.payment?.amount && (
            <>
              <div className="divider" style={{ margin:'2px 0' }} />
              <div style={{ display:'flex', justifyContent:'space-between' }}>
                <span style={{ fontSize:'.78rem', color:'var(--t2)' }}>مبلغ</span>
                <span style={{ fontSize:'.82rem', fontWeight:700, color:'var(--brand)' }}>
                  {order.payment.amount.toLocaleString()} {order.payment.currency === 'USD' ? '$' : 'ت'}
                </span>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Files */}
      {order?.files?.length > 0 && (
        <div className="section" style={{ paddingTop:0 }}>
          <div className="section-title">فایل‌های آپلود شده</div>
          {order.files.map(f => (
            <div key={f._id} className="card-sm" style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
              <div style={{ width:28, height:28, borderRadius:6, background:'var(--brand-d)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'.6rem', fontWeight:700, color:'var(--brand)' }}>
                .{f.format?.toUpperCase()}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:'.78rem', fontWeight:500 }}>{f.name}</div>
                <div style={{ fontSize:'.65rem', color:'var(--t2)' }}>{f.size ? `${(f.size/1024/1024).toFixed(1)} MB` : ''}</div>
              </div>
              <span style={{ fontSize:'.65rem', borderRadius:99, padding:'2px 7px', fontWeight:600,
                background: f.status==='approved'?'rgba(29,158,117,.12)':f.status==='rejected'?'rgba(216,90,48,.12)':'rgba(239,159,39,.12)',
                color: f.status==='approved'?'#1D9E75':f.status==='rejected'?'#8C2F0E':'#7A4F00',
              }}>
                {f.status==='approved'?'✅ تایید':f.status==='rejected'?'❌ رد':' ⏳ بررسی'}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Pay button if needed */}
      {order?.payment?.status === 'pending' && order?.status === 'ready' && (
        <div className="section" style={{ paddingTop:0 }}>
          <Link to={`/payment/${order._id}`} style={{ display:'block', padding:14, background:'var(--green)', color:'#fff', borderRadius:12, textAlign:'center', textDecoration:'none', fontWeight:700, fontSize:'.95rem' }}>
            💳 پرداخت و تحویل
          </Link>
        </div>
      )}
    </div>
  );
}
