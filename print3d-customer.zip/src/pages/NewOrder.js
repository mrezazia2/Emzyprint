import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import api from '../services/api';

const RESINS = [
  { key:'wax',     label:'Wax',     sub:'آبی',   color:'#3B82F6' },
  { key:'dark',    label:'Dark',    sub:'مشکی',  color:'#374151' },
  { key:'yellow',  label:'Yellow',  sub:'زرد',   color:'#EAB308' },
  { key:'vintage', label:'Vintage', sub:'سبز',   color:'#22C55E' },
];

export default function NewOrderPage() {
  const navigate = useNavigate();
  const fileRef = useRef();
  const [step, setStep] = useState(1);
  const [resinKey, setResinKey] = useState('');
  const [files, setFiles] = useState([]);
  const [uploads, setUploads] = useState({});
  const [printSettings, setPrintSettings] = useState({ material:'Resin', quality:'standard', quantity:1, notes:'' });
  const [orderId, setOrderId] = useState(null);

  const { data: customFields } = useQuery({
    queryKey: ['custom-fields'],
    queryFn: () => api.get('/admin/custom-fields').then(r => r.data.fields),
  });

  const createOrderMut = useMutation({
    mutationFn: () => api.post('/orders', {
      printSettings: { ...printSettings, material: `Resin-${resinKey}` },
      customFields: { resin_type: resinKey },
    }),
    onSuccess: (res) => {
      setOrderId(res.data.order._id);
      setStep(2);
    },
    onError: err => toast.error(err.response?.data?.error || 'خطا در ثبت سفارش'),
  });

  const uploadFile = async (file) => {
    if (!orderId) return;
    const id = `${Date.now()}_${file.name}`;
    setUploads(u => ({ ...u, [id]: { name: file.name, percent: 0, status: 'uploading' } }));

    const formData = new FormData();
    formData.append('files', file);

    try {
      await api.post(`/files/upload/${orderId}`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (e) => {
          const pct = Math.round((e.loaded * 100) / e.total);
          setUploads(u => ({ ...u, [id]: { ...u[id], percent: pct } }));
        },
      });
      setUploads(u => ({ ...u, [id]: { ...u[id], percent: 100, status: 'done' } }));
    } catch {
      setUploads(u => ({ ...u, [id]: { ...u[id], status: 'error' } }));
      toast.error(`خطا در آپلود ${file.name}`);
    }
  };

  const handleFiles = async (selected) => {
    const arr = Array.from(selected);
    setFiles(f => [...f, ...arr]);
    for (const f of arr) await uploadFile(f);
  };

  const allUploaded = Object.values(uploads).length > 0 &&
    Object.values(uploads).every(u => u.status === 'done');

  return (
    <div className="page animate-up" style={{ paddingTop:60, paddingBottom:30 }}>
      <div className="topbar topbar-white">
        <div className="tb-row">
          <button onClick={() => step > 1 ? setStep(s=>s-1) : navigate(-1)} style={{ background:'none', border:'none', fontSize:'1.2rem', cursor:'pointer', color:'var(--t1)' }}>←</button>
          <div style={{ fontWeight:700, fontSize:'.95rem' }}>سفارش جدید</div>
          {/* Step indicator */}
          <div style={{ display:'flex', gap:4 }}>
            {[1,2,3].map(s => (
              <div key={s} style={{ width: step===s?18:8, height:8, borderRadius:99, background: s<=step?'var(--brand)':'var(--border)', transition:'all .2s' }} />
            ))}
          </div>
        </div>
      </div>

      {/* ── STEP 1: Resin ── */}
      {step === 1 && (
        <div className="section">
          <div style={{ marginBottom:20 }}>
            <div style={{ fontWeight:700, fontSize:'1.05rem', marginBottom:4 }}>نوع رزین چاپ</div>
            <div style={{ fontSize:'.8rem', color:'var(--t2)' }}>انتخاب رزین اجباری است</div>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:24 }}>
            {RESINS.map(r => (
              <div
                key={r.key}
                style={{ padding:16, borderRadius:14, border:`2px solid ${resinKey===r.key ? r.color : 'var(--border)'}`, background: resinKey===r.key ? r.color+'15' : 'var(--surface)', cursor:'pointer', textAlign:'center', transition:'all .15s' }}
                onClick={() => setResinKey(r.key)}
              >
                <div style={{ width:20, height:20, borderRadius:'50%', background:r.color, margin:'0 auto 8px' }} />
                <div style={{ fontWeight:700, fontSize:'.9rem', color: resinKey===r.key ? r.color : 'var(--t1)' }}>{r.label}</div>
                <div style={{ fontSize:'.72rem', color:'var(--t2)' }}>{r.sub}</div>
                {resinKey === r.key && <div style={{ fontSize:'.65rem', marginTop:5, color:r.color, fontWeight:600 }}>✓ انتخاب شده</div>}
              </div>
            ))}
          </div>

          {/* Quantity */}
          <div style={{ marginBottom:16 }}>
            <label className="label">تعداد</label>
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <button onClick={() => setPrintSettings(p => ({...p, quantity: Math.max(1, p.quantity-1)}))} style={{ width:36, height:36, borderRadius:10, border:'1.5px solid var(--border)', background:'var(--bg)', fontSize:'1.2rem', cursor:'pointer' }}>−</button>
              <div style={{ flex:1, textAlign:'center', fontSize:'1.1rem', fontWeight:700 }}>{printSettings.quantity}</div>
              <button onClick={() => setPrintSettings(p => ({...p, quantity: p.quantity+1}))} style={{ width:36, height:36, borderRadius:10, border:'1.5px solid var(--brand)', background:'var(--brand-d)', color:'var(--brand)', fontSize:'1.2rem', cursor:'pointer' }}>+</button>
            </div>
          </div>

          {/* Quality */}
          <div style={{ marginBottom:16 }}>
            <label className="label">کیفیت چاپ</label>
            <div style={{ display:'flex', gap:6 }}>
              {[{v:'draft',l:'سریع'},{v:'standard',l:'استاندارد'},{v:'high',l:'دقیق'}].map(q => (
                <button key={q.v} style={{ flex:1, padding:'8px 0', borderRadius:10, border:`1.5px solid ${printSettings.quality===q.v?'var(--brand)':'var(--border)'}`, background:printSettings.quality===q.v?'var(--brand-d)':'transparent', color:printSettings.quality===q.v?'var(--brand)':'var(--t2)', fontFamily:'Vazirmatn', fontSize:'.78rem', fontWeight:printSettings.quality===q.v?700:400, cursor:'pointer' }} onClick={() => setPrintSettings(p=>({...p,quality:q.v}))}>
                  {q.l}
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div style={{ marginBottom:24 }}>
            <label className="label">توضیحات (اختیاری)</label>
            <textarea className="input" rows={3} placeholder="رنگ دقیق، پوشش خاص..." value={printSettings.notes} onChange={e => setPrintSettings(p=>({...p,notes:e.target.value}))} style={{ resize:'none' }} />
          </div>

          <button
            className="btn btn-primary"
            disabled={!resinKey || createOrderMut.isPending}
            onClick={() => createOrderMut.mutate()}
          >
            {createOrderMut.isPending ? 'در حال ثبت...' : 'ثبت سفارش و آپلود فایل →'}
          </button>
        </div>
      )}

      {/* ── STEP 2: Upload ── */}
      {step === 2 && (
        <div className="section">
          <div style={{ marginBottom:16 }}>
            <div style={{ fontWeight:700, fontSize:'1.05rem', marginBottom:4 }}>آپلود فایل‌های ۳D</div>
            <div style={{ fontSize:'.8rem', color:'var(--t2)' }}>STL · OBJ · 3MF · GCODE</div>
          </div>

          {/* Upload zone */}
          <div
            style={{ border:'2px dashed var(--brand)', borderRadius:14, padding:'28px 20px', textAlign:'center', background:'var(--brand-d)', cursor:'pointer', marginBottom:16 }}
            onClick={() => fileRef.current?.click()}
          >
            <div style={{ fontSize:'2rem', marginBottom:8 }}>☁️</div>
            <div style={{ fontWeight:600, color:'var(--brand)', marginBottom:4 }}>فایل را انتخاب کنید</div>
            <div style={{ fontSize:'.72rem', color:'var(--t2)' }}>یا از تلگرام/واتس‌اپ Share کنید</div>
            <input ref={fileRef} type="file" multiple accept=".stl,.obj,.3mf,.gcode,.step,.stp,.zip" style={{ display:'none' }} onChange={e => handleFiles(e.target.files)} />
          </div>

          {/* File list */}
          {Object.entries(uploads).map(([id, u]) => (
            <div key={id} className="card-sm" style={{ marginBottom:8, display:'flex', flexDirection:'column', gap:6 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <span style={{ fontSize:'.78rem', fontWeight:500 }}>{u.name}</span>
                <span style={{ fontSize:'.65rem', color: u.status==='done'?'#1D9E75':u.status==='error'?'#D85A30':'var(--t2)' }}>
                  {u.status==='done'?'✅':u.status==='error'?'❌':`${u.percent}٪`}
                </span>
              </div>
              {u.status==='uploading' && (
                <div className="progress-track">
                  <div className="progress-fill" style={{ width:`${u.percent}%`, background:'var(--brand)' }} />
                </div>
              )}
            </div>
          ))}

          <div style={{ display:'flex', gap:8, marginTop:16 }}>
            <button className="btn btn-ghost" style={{ flex:1 }} onClick={() => fileRef.current?.click()}>+ افزودن فایل</button>
            <button
              className="btn btn-primary"
              style={{ flex:2 }}
              disabled={!allUploaded && Object.keys(uploads).length === 0}
              onClick={() => setStep(3)}
            >
              {Object.keys(uploads).length === 0 ? 'بدون فایل ادامه بده' : allUploaded ? 'ادامه →' : 'صبر کن...'}
            </button>
          </div>
        </div>
      )}

      {/* ── STEP 3: Done ── */}
      {step === 3 && (
        <div className="section" style={{ textAlign:'center', paddingTop:40 }}>
          <div style={{ fontSize:'3.5rem', marginBottom:16 }}>🎉</div>
          <div style={{ fontWeight:700, fontSize:'1.2rem', marginBottom:8 }}>سفارش ثبت شد!</div>
          <div style={{ fontSize:'.85rem', color:'var(--t2)', marginBottom:28 }}>
            سفارش شما در حال بررسی است. وضعیت را در صفحه سفارشات پیگیری کنید.
          </div>
          <button className="btn btn-primary" style={{ marginBottom:10 }} onClick={() => navigate(`/orders/${orderId}`)}>
            مشاهده سفارش
          </button>
          <button className="btn btn-ghost" onClick={() => navigate('/')}>
            بازگشت به خانه
          </button>
        </div>
      )}
    </div>
  );
}
