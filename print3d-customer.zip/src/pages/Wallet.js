import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import api from '../services/api';

const RESINS = [
  { key:'wax',    label:'Wax (آبی)',    color:'#3B82F6' },
  { key:'dark',   label:'Dark (مشکی)',  color:'#374151' },
  { key:'yellow', label:'Yellow (زرد)', color:'#EAB308' },
  { key:'vintage',label:'Vintage (سبز)',color:'#22C55E' },
];

export default function WalletPage() {
  const navigate = useNavigate();
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('IRR');
  const [resinKey, setResinKey] = useState('wax');
  const [calcResult, setCalcResult] = useState(null);
  const [calculating, setCalculating] = useState(false);

  const { data: walletData, refetch } = useQuery({
    queryKey: ['wallet'],
    queryFn: () => api.get('/wallet').then(r => r.data),
  });

  const wallet = walletData?.wallet;
  const rates = walletData?.rates;
  const selectedResin = rates?.resinRates?.find(r => r.resinKey === resinKey);

  const calc = async () => {
    if (!amount || parseFloat(amount) <= 0) return;
    setCalculating(true);
    try {
      const { data } = await api.post('/wallet/calc', { amount: parseFloat(amount), currency, resinKey });
      setCalcResult(data);
    } catch (err) {
      toast.error(err.response?.data?.error || 'خطا');
    } finally { setCalculating(false); }
  };

  const chargeMut = useMutation({
    mutationFn: () => api.post('/wallet/charge/zarinpal', { amount: parseFloat(amount), resinKey }),
    onSuccess: (res) => {
      if (res.data.redirectUrl) window.location.href = res.data.redirectUrl;
    },
    onError: err => toast.error(err.response?.data?.error || 'خطا'),
  });

  return (
    <div className="page page-with-header animate-up">
      <div className="topbar topbar-white">
        <div className="tb-row">
          <button onClick={() => navigate(-1)} style={{ background:'none', border:'none', fontSize:'1.2rem', cursor:'pointer', color:'var(--t1)' }}>←</button>
          <div style={{ fontWeight:700 }}>کیف پول</div>
          <div />
        </div>
      </div>

      {/* Balance card */}
      <div className="section">
        <div style={{ background:'linear-gradient(135deg,#534AB7,#7C6AF5)', borderRadius:16, padding:20, color:'#fff' }}>
          <div style={{ fontSize:'.78rem', opacity:.7, marginBottom:4 }}>موجودی کیف پول</div>
          <div style={{ fontSize:'2.2rem', fontWeight:700 }}>
            {wallet?.grams?.toFixed(2) || '0'}
            <span style={{ fontSize:'.85rem', opacity:.8, marginRight:6 }}>گرم رزین</span>
          </div>
          <div style={{ display:'flex', gap:16, marginTop:10 }}>
            <div style={{ fontSize:'.72rem', opacity:.7 }}>شارژ شده: {wallet?.totalCharged?.toFixed(1)||0}g</div>
            <div style={{ fontSize:'.72rem', opacity:.7 }}>مصرف: {wallet?.totalUsed?.toFixed(1)||0}g</div>
          </div>
        </div>
      </div>

      {/* Rate */}
      {rates?.usdToIrr && (
        <div style={{ margin:'0 16px 12px', background:'rgba(239,159,39,.1)', border:'1px solid rgba(239,159,39,.2)', borderRadius:10, padding:'9px 12px', textAlign:'center', fontSize:'.78rem', color:'#7A4F00', fontWeight:600 }}>
          💵 نرخ دلار: {rates.usdToIrr.toLocaleString()} ریال
        </div>
      )}

      {/* Charge section */}
      <div className="section" style={{ paddingTop:0 }}>
        <div className="section-title">شارژ کیف پول</div>

        {/* Resin */}
        <div style={{ marginBottom:12 }}>
          <label className="label">نوع رزین</label>
          <div style={{ display:'flex', gap:5, overflowX:'auto', paddingBottom:4 }}>
            {RESINS.map(r => (
              <button key={r.key} style={{ padding:'5px 12px', borderRadius:99, border:`1.5px solid ${resinKey===r.key?r.color:'var(--border)'}`, background:resinKey===r.key?r.color+'15':'transparent', color:resinKey===r.key?r.color:'var(--t2)', fontFamily:'Vazirmatn', fontSize:'.72rem', cursor:'pointer', whiteSpace:'nowrap', fontWeight:resinKey===r.key?700:400 }} onClick={() => { setResinKey(r.key); setCalcResult(null); }}>
                {r.label}
              </button>
            ))}
          </div>
          {selectedResin && <div style={{ fontSize:'.7rem', color:'var(--t2)', marginTop:4 }}>هر گرم: ${selectedResin.rateUSD}{rates?.usdToIrr ? ` ≈ ${(selectedResin.rateUSD*rates.usdToIrr).toLocaleString()} ریال` : ''}</div>}
        </div>

        {/* Currency */}
        <div style={{ marginBottom:12 }}>
          <label className="label">ارز</label>
          <div style={{ display:'flex', gap:6 }}>
            {[{v:'IRR',l:'🇮🇷 ریال'},{v:'USD',l:'🇺🇸 دلار'}].map(c => (
              <button key={c.v} style={{ flex:1, padding:10, borderRadius:10, border:`1.5px solid ${currency===c.v?'var(--brand)':'var(--border)'}`, background:currency===c.v?'var(--brand-d)':'transparent', color:currency===c.v?'var(--brand)':'var(--t2)', fontFamily:'Vazirmatn', fontSize:'.82rem', fontWeight:currency===c.v?700:400, cursor:'pointer' }} onClick={() => { setCurrency(c.v); setCalcResult(null); }}>
                {c.l}
              </button>
            ))}
          </div>
        </div>

        {/* Amount */}
        <div style={{ marginBottom:12 }}>
          <label className="label">مبلغ ({currency==='IRR'?'ریال':'دلار'})</label>
          <div style={{ display:'flex', gap:8 }}>
            <input className="input" type="number" style={{ flex:1 }} placeholder={currency==='IRR'?'1000000':'20'} value={amount} onChange={e => { setAmount(e.target.value); setCalcResult(null); }} dir="ltr" />
            <button style={{ padding:'0 16px', background:'var(--brand-d)', border:'1.5px solid var(--brand)', borderRadius:10, color:'var(--brand)', fontFamily:'Vazirmatn', fontSize:'.82rem', fontWeight:700, cursor:'pointer' }} onClick={calc} disabled={calculating}>
              {calculating ? '...' : 'محاسبه'}
            </button>
          </div>
        </div>

        {/* Result */}
        {calcResult && (
          <div style={{ background:'rgba(29,158,117,.08)', border:'1px solid rgba(29,158,117,.2)', borderRadius:12, padding:14, marginBottom:14 }}>
            <div style={{ fontSize:'.78rem', color:'var(--t2)', marginBottom:4 }}>نتیجه:</div>
            <div style={{ fontSize:'1.6rem', fontWeight:700, color:'#1D9E75' }}>
              {calcResult.grams} <span style={{ fontSize:'.85rem', color:'var(--t2)' }}>گرم رزین</span>
            </div>
            <div style={{ fontSize:'.7rem', color:'var(--t3)', marginTop:4 }}>
              نرخ هر گرم: ${calcResult.ratePerGram}
            </div>
            <button className="btn btn-green" style={{ marginTop:12 }} onClick={() => chargeMut.mutate()} disabled={chargeMut.isPending}>
              {chargeMut.isPending ? 'در حال اتصال...' : `💳 پرداخت ${currency==='IRR'?'با ریال':'با دلار'}`}
            </button>
          </div>
        )}
      </div>

      {/* Transactions */}
      {wallet?.transactions?.length > 0 && (
        <div className="section" style={{ paddingTop:0 }}>
          <div className="section-title">تاریخچه</div>
          {wallet.transactions.slice(-10).reverse().map((t,i) => (
            <div key={i} className="card-sm" style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6 }}>
              <div>
                <div style={{ fontSize:'.78rem', fontWeight:500 }}>{t.description?.fa || t.type}</div>
                <div style={{ fontSize:'.65rem', color:'var(--t3)', marginTop:1 }}>{t.createdAtJalali}</div>
              </div>
              <span style={{ fontSize:'.85rem', fontWeight:700, color: t.grams>0?'#1D9E75':'#D85A30' }}>
                {t.grams>0?'+':''}{t.grams?.toFixed(2)}g
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
