import { create } from 'zustand';
import api from '../services/api';

const useAuthStore = create((set, get) => ({
  user: null,
  token: localStorage.getItem('customer_token'),
  isLoading: true,
  requireName: false,
  tempToken: null,

  init: async () => {
    const token = localStorage.getItem('customer_token');
    if (!token) return set({ isLoading: false });
    try {
      const res = await api.get('/auth/me');
      set({ user: res.data.user, token });
    } catch {
      localStorage.removeItem('customer_token');
      set({ user: null, token: null });
    }
    set({ isLoading: false });
  },

  login: async (phone, otp) => {
    const res = await api.post('/auth/verify-otp', { phone, otp });
    if (res.data.requireName) {
      set({ requireName: true, tempToken: res.data.tempToken });
      return res.data;
    }
    const { accessToken, refreshToken, user } = res.data;
    localStorage.setItem('customer_token', accessToken);
    if (refreshToken) localStorage.setItem('customer_refresh_token', refreshToken);
    set({ user, token: accessToken, requireName: false, tempToken: null });
    return res.data;
  },

  submitName: async (name) => {
    const { tempToken } = get();
    const res = await api.post('/auth/set-name', { name }, {
      headers: { Authorization: `Bearer ${tempToken}` }
    });
    const { accessToken, refreshToken, user } = res.data;
    localStorage.setItem('customer_token', accessToken);
    if (refreshToken) localStorage.setItem('customer_refresh_token', refreshToken);
    api.defaults.headers.common['Authorization'] = `Bearer ${accessToken}`;
    set({ user, token: accessToken, requireName: false, tempToken: null });
    return res.data;
  },

  updateUser: (updates) => {
    const user = { ...get().user, ...updates };
    set({ user });
  },

  logout: () => {
    localStorage.removeItem('customer_token');
    localStorage.removeItem('customer_refresh_token');
    set({ user: null, token: null, requireName: false, tempToken: null });
  },
}));

export default useAuthStore;
