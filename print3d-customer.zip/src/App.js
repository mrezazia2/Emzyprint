﻿import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, NavLink, useLocation } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import useAuthStore from './store/authStore';
import { ChatProvider, useChatContext } from './context/ChatContext';
import './styles/global.css';
import api from './services/api';

const Login       = React.lazy(() => import('./pages/Login'));
const Home        = React.lazy(() => import('./pages/Home'));
const Orders      = React.lazy(() => import('./pages/Orders'));
const OrderDetail = React.lazy(() => import('./pages/OrderDetail'));
const NewOrder    = React.lazy(() => import('./pages/NewOrder'));
const Wallet      = React.lazy(() => import('./pages/Wallet'));
const Profile     = React.lazy(() => import('./pages/Profile'));
const Chat        = React.lazy(() => import('./pages/Chat'));

const qc = new QueryClient({ defaultOptions: { queries: { retry: 1, staleTime: 30000 } } });

function BottomNav() {
  const location = useLocation();
  const { unreadCount, markAllRead } = useChatContext();
  const hideOn = ['/login', '/new-order'];
  if (hideOn.some(p => location.pathname.startsWith(p))) return null;

  return (
    <nav className="bottom-nav">
      <NavLink to="/" end className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`}>
        <span className="nav-icon">🏠</span>
        <span>خانه</span>
      </NavLink>
      <NavLink to="/orders" className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`}>
        <span className="nav-icon">📋</span>
        <span>سفارشات</span>
      </NavLink>
      <NavLink to="/new-order" className="nav-fab">+</NavLink>
      <NavLink
        to="/chats"
        className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`}
        onClick={markAllRead}
      >
        <span style={{ position: 'relative', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
          <span className="nav-icon">💬</span>
          {unreadCount > 0 && (
            <span style={{
              position: 'absolute',
              top: -4,
              right: -8,
              background: '#ef4444',
              color: '#fff',
              fontSize: '0.55rem',
              fontWeight: 700,
              borderRadius: '999px',
              minWidth: 15,
              height: 15,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '0 3px',
              lineHeight: 1,
              boxShadow: '0 0 0 2px var(--surface)',
            }}>
              {unreadCount > 99 ? '99+' : unreadCount}
            </span>
          )}
        </span>
        <span>چت</span>
      </NavLink>
      <NavLink to="/profile" className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`}>
        <span className="nav-icon">👤</span>
        <span>پروفایل</span>
      </NavLink>
    </nav>
  );
}

function ProtectedRoute({ children }) {
  const { token } = useAuthStore();
  if (!token) return <Navigate to="/login" replace />;
  return children;
}

import { subscribeWebPush } from './utils/webPush';

function AppRoutes() {
  const { init, token } = useAuthStore();
  useEffect(() => { init(); }, []);
  useEffect(() => {
    if (token) subscribeWebPush(api);
  }, [token]);

  return (
    <div className="app">
      <React.Suspense fallback={<div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}><div className="spinner" /></div>}>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<ProtectedRoute><Home /></ProtectedRoute>} />
          <Route path="/orders" element={<ProtectedRoute><Orders /></ProtectedRoute>} />
          <Route path="/orders/:id" element={<ProtectedRoute><OrderDetail /></ProtectedRoute>} />
          <Route path="/new-order" element={<ProtectedRoute><NewOrder /></ProtectedRoute>} />
          <Route path="/wallet" element={<ProtectedRoute><Wallet /></ProtectedRoute>} />
          <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
          <Route path="/chats" element={<ProtectedRoute><Chat /></ProtectedRoute>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </React.Suspense>
      <BottomNav />
    </div>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={qc}>
      <BrowserRouter>
        <ChatProvider>
          <AppRoutes />
        </ChatProvider>
      </BrowserRouter>
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            fontFamily: 'Vazirmatn, sans-serif',
            fontSize: '.85rem',
            direction: 'rtl',
          },
        }}
      />
    </QueryClientProvider>
  );
}
